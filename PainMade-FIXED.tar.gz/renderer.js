const { ipcRenderer } = require('electron');

// Verify DOM is ready
console.log('Renderer.js loading...');

// State management
let vocalBuffer = null;
let vocalFilePath = null; // Store actual file path for analysis
let referenceBuffer = null;
let vocalAudioContext = null;
let referenceAudioContext = null;
let generatedSettings = null;
let vocalAnalysis = null;
let referenceAnalysis = null;
let referenceAnalyses = []; // Store multiple reference track analyses

// UI Elements
const loadVocalBtn = document.getElementById('loadVocal');
// Note: loadReferenceBtn removed - this app is for YOUR voice only!
const smartAnalyzeBtn = document.getElementById('smartAnalyzeBtn');
const applyToLogicBtn = document.getElementById('applyToLogicBtn');
const exportStudioVerseBtn = document.getElementById('exportStudioVerseBtn');
const exportMelodyneBtn = document.getElementById('exportMelodyneBtn');
const exportSettingsBtn = document.getElementById('exportSettingsBtn');
const copySettingsBtn = document.getElementById('copySettingsBtn');
const automateLogicBtn = document.getElementById('automateLogicBtn');
const statusBar = document.getElementById('statusBar');
const pluginSettingsContainer = document.getElementById('pluginSettingsContainer');

// Verify critical elements exist
console.log('Button elements:', {
    loadVocal: !!loadVocalBtn,
    smartAnalyze: !!smartAnalyzeBtn,
    applyToLogic: !!applyToLogicBtn,
    exportStudioVerse: !!exportStudioVerseBtn,
    exportMelodyne: !!exportMelodyneBtn
});

if (!loadVocalBtn) console.error('loadVocal button not found!');
if (!smartAnalyzeBtn) console.error('smartAnalyzeBtn button not found!');
if (!applyToLogicBtn) console.error('applyToLogicBtn button not found!');

// Track info elements
const vocalInfo = document.getElementById('vocalInfo');
const referenceInfo = document.getElementById('referenceInfo');

// Audio players
const vocalPlayer = document.getElementById('vocalPlayer');
const referencePlayer = document.getElementById('referencePlayer');

// Tab handling for new UI
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        // Remove active from all tabs
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        
        // Add active to clicked tab
        btn.classList.add('active');
        const tabId = 'tab-' + btn.dataset.tab;
        document.getElementById(tabId).classList.add('active');
    });
});

// Load Vocal Track
loadVocalBtn.addEventListener('click', async () => {
    console.log('Load Vocal button clicked!');
    try {
        updateStatus('Loading vocal track...');
        const filePath = await ipcRenderer.invoke('select-file', 'vocal');
        
        if (filePath) {
            // Store the file path for analysis
            vocalFilePath = filePath;
            
            const arrayBuffer = await ipcRenderer.invoke('read-file', filePath);
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            vocalAudioContext = audioContext;
            
            vocalBuffer = await audioContext.decodeAudioData(arrayBuffer.buffer);
            
            const fileName = filePath.split('\\').pop().split('/').pop();
            const duration = vocalBuffer.duration.toFixed(1);
            const sampleRate = vocalBuffer.sampleRate;
            
            // Compact, clean file info
            vocalInfo.innerHTML = `
                <div class="file-name">${fileName}</div>
                <div class="file-details">${duration}s • ${(sampleRate/1000).toFixed(1)}kHz</div>
            `;
            
            const blob = new Blob([arrayBuffer], { type: 'audio/wav' });
            vocalPlayer.src = URL.createObjectURL(blob);
            vocalPlayer.onerror = () => {
                // Suppress harmless blob range errors
                console.log('Audio player loaded (blob range warning is harmless)');
            };
            
            drawWaveform(vocalBuffer, 'vocalWaveform');
            
            updateStatus('Vocal loaded successfully!');
            
            // Enable smart analyze button
            if (typeof smartAnalyzeBtn !== 'undefined' && smartAnalyzeBtn) {
                smartAnalyzeBtn.disabled = false;
            }
        }
    } catch (error) {
        console.error('Error loading vocal:', error);
        updateStatus('Error loading vocal track');
    }
});

// Reference track handling disabled - this app is built for YOUR voice only!
/*
loadReferenceBtn.addEventListener('click', async () => {
    console.log('Load Reference button clicked!');
    try {
        updateStatus('Loading reference track...');
        const filePath = await ipcRenderer.invoke('select-file', 'reference');
        
        if (filePath) {
            const arrayBuffer = await ipcRenderer.invoke('read-file', filePath);
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            referenceAudioContext = audioContext;
            
            referenceBuffer = await audioContext.decodeAudioData(arrayBuffer.buffer);
            
            const fileName = filePath.split('\\').pop().split('/').pop();
            const duration = referenceBuffer.duration.toFixed(2);
            const sampleRate = referenceBuffer.sampleRate;
            
            // Analyze this reference immediately
            updateStatus('Analyzing reference track...');
            const refAnalysis = await analyzeAudio(referenceBuffer);
            referenceAnalyses.push({
                fileName,
                analysis: refAnalysis,
                buffer: referenceBuffer
            });
            
            // Store as main reference (for playback/waveform)
            referenceAnalysis = refAnalysis;
            
            // Update reference counter with cleaner message
            const referenceCount = document.getElementById('referenceCount');
            referenceCount.textContent = `${referenceAnalyses.length} reference${referenceAnalyses.length > 1 ? 's' : ''} loaded`;
            
            // Compact, clean file info
            referenceInfo.innerHTML = `
                <div class="file-name">${fileName}</div>
                <div class="file-details">${duration}s • ${(sampleRate/1000).toFixed(1)}kHz</div>
            `;
            
            const blob = new Blob([arrayBuffer], { type: 'audio/wav' });
            referencePlayer.src = URL.createObjectURL(blob);
            referencePlayer.onerror = () => {
                // Suppress harmless blob range errors
                console.log('Audio player loaded (blob range warning is harmless)');
            };
            
            drawWaveform(referenceBuffer, 'referenceWaveform');
            
            updateStatus(`Reference ${referenceAnalyses.length} loaded and analyzed successfully!`);
            
            // Enable analyze button if vocal is also loaded
            if (vocalBuffer) {
                analyzeBtn.disabled = false;
            }
            
            // Disable button if 5 references loaded
            if (referenceAnalyses.length >= 5) {
                loadReferenceBtn.disabled = true;
                loadReferenceBtn.textContent = 'Maximum References Loaded';
            }
        }
    } catch (error) {
        console.error('Error loading reference:', error);
        updateStatus('Error loading reference track');
    }
});
*/

// Old Analyze button code - REMOVED (now using smartAnalyzeBtn)
/*
// Analyze and Generate Settings
analyzeBtn.addEventListener('click', async () => {
    if (!vocalBuffer) {
        updateStatus('Please load a vocal track first');
        return;
    }
    
    const hasReference = referenceBuffer || referenceAnalyses.length > 0;
    
    try {
        updateStatus(hasReference ? 'Analyzing vocal against reference...' : 'Analyzing vocal (no reference - using pro engineer standards)...');
        analyzeBtn.disabled = true;
        
        // Analyze vocal
        vocalAnalysis = await analyzeAudio(vocalBuffer);
        
        // Handle reference analysis
        if (hasReference) {
            // Average multiple references if available
            if (referenceAnalyses.length > 1) {
                updateStatus(`Averaging ${referenceAnalyses.length} reference tracks for optimal analysis...`);
                referenceAnalysis = averageReferenceAnalyses(referenceAnalyses.map(r => r.analysis));
                console.log(`Using averaged analysis from ${referenceAnalyses.length} references`);
            } else if (referenceAnalyses.length === 1) {
                referenceAnalysis = referenceAnalyses[0].analysis;
            } else {
                // Fallback: analyze current reference buffer
                referenceAnalysis = await analyzeAudio(referenceBuffer);
            }
            
            // Display basic analysis results (vocal vs reference)
            displayAnalysis(vocalAnalysis, referenceAnalysis);
            
            updateStatus('Generating plugin settings based on reference...');
            
            // Generate comprehensive plugin settings
            generatedSettings = generatePluginSettings(vocalAnalysis, referenceAnalysis);
        } else {
            // NO REFERENCE - Use professional standards
            updateStatus('Generating professional plugin settings (no reference)...');
            
            // Display vocal-only analysis
            displayVocalOnlyAnalysis(vocalAnalysis);
            
            // Generate settings based on professional standards
            generatedSettings = generatePluginSettingsNoReference(vocalAnalysis);
        }
        
        // Display the settings
        displayPluginSettings(generatedSettings);
        
        // Display plugin chain preview in Chain tab
        displayPluginChainPreview(generatedSettings);
        
        // Display professional engineer advice
        displayEngineerAdvice(vocalAnalysis, referenceAnalysis, hasReference);
        
        // Show settings container and enable export buttons
        pluginSettingsContainer.style.display = 'block';
        exportStudioVerseBtn.disabled = false; // Always enable - works with or without reference
        exportMelodyneBtn.disabled = false; // Always enable - works with or without reference
        if (automateLogicBtn) automateLogicBtn.disabled = false; // Enable automation button
        exportSettingsBtn.disabled = false;
        copySettingsBtn.disabled = false;
        
        const statusMsg = hasReference 
            ? `Plugin settings generated using ${referenceAnalyses.length > 0 ? referenceAnalyses.length + ' reference(s)' : '1 reference'}! Review and apply in your DAW`
            : 'Professional plugin settings generated! Check the Engineer Advice section. Export as StudioVerse or Melodyne presets.';
        updateStatus(statusMsg);
        analyzeBtn.disabled = false;
        
        // Scroll to settings
        pluginSettingsContainer.scrollIntoView({ behavior: 'smooth' });
    } catch (error) {
        console.error('Error analyzing:', error);
        updateStatus('Error during analysis');
        analyzeBtn.disabled = false;
    }
});
*/
// END of old analyzeBtn code - now using smartAnalyzeBtn instead

// Copy Settings to Clipboard
copySettingsBtn.addEventListener('click', () => {
    if (!generatedSettings) return;
    
    const settingsText = formatSettingsAsText(generatedSettings);
    
    navigator.clipboard.writeText(settingsText).then(() => {
        updateStatus('Settings copied to clipboard!');
        copySettingsBtn.textContent = '✓ Copied!';
        setTimeout(() => {
            copySettingsBtn.textContent = 'Copy All Settings';
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy:', err);
        updateStatus('Failed to copy settings');
    });
});

// Export StudioVerse Chain - AI analyzes and picks optimal plugins
exportStudioVerseBtn.addEventListener('click', async () => {
    if (!generatedSettings) return;
    
    try {
        const hasRef = referenceAnalysis !== null;
        updateStatus(hasRef 
            ? 'AI analyzing differences and building optimal chain...'
            : 'Building professional standard chain (no reference)...');
        
        // AI decides which plugins to use and in what order
        const aiChain = buildIntelligentChain(vocalAnalysis, referenceAnalysis, generatedSettings);
        
        // Generate comprehensive chain documentation as HTML (for manual reference)
        const chainHTML = convertToHTMLReport(aiChain);
        
        // Also save JSON for automation script
        const chainJSON = JSON.stringify(aiChain, null, 2);
        
        // Save HTML file
        const htmlBlob = new Blob([chainHTML], { type: 'text/html' });
        const htmlBuffer = await htmlBlob.arrayBuffer();
        
        const filePath = await ipcRenderer.invoke('save-studioverse-file', htmlBuffer);
        
        if (filePath) {
            // Also save JSON version for automation
            const jsonBlob = new Blob([chainJSON], { type: 'application/json' });
            const jsonBuffer = await jsonBlob.arrayBuffer();
            const jsonPath = filePath.replace('.html', '.json');
            
            try {
                await ipcRenderer.invoke('save-json-chain', jsonBuffer);
                updateStatus(`Chain exported! HTML report + JSON for automation script.`);
            } catch (err) {
                updateStatus(`HTML report exported! (${aiChain.plugins.length} plugins)`);
            }
            
            exportStudioVerseBtn.textContent = '✓ Exported!';
            
            setTimeout(() => {
                exportStudioVerseBtn.textContent = 'Export Plugin Chain';
            }, 2000);
        } else {
            updateStatus('Export cancelled');
        }
    } catch (error) {
        console.error('Export error:', error);
        updateStatus('Error exporting StudioVerse chain');
    }
});

// Auto-Edit in Melodyne - Analyzes reference pitch and corrects your vocal automatically
exportMelodyneBtn.addEventListener('click', async () => {
    if (!vocalBuffer || !vocalAnalysis) {
        updateStatus('⚠️ Vocal analysis required');
        return;
    }
    
    try {
        updateStatus('Analyzing pitch contours...');
        exportMelodyneBtn.disabled = true;
        
        // Detailed pitch analysis of vocal
        console.log('Starting vocal pitch analysis...');
        const vocalPitchMap = await analyzePitchContour(vocalBuffer);
        console.log('Vocal pitch map:', vocalPitchMap);
        
        if (!vocalPitchMap || vocalPitchMap.length === 0) {
            throw new Error('Failed to analyze vocal pitch');
        }
        
        let referencePitchMap;
        let melodyneScript;
        
        if (referenceBuffer || referenceAnalyses.length > 0) {
            // WITH REFERENCE: Match reference pitch
            updateStatus('Analyzing reference pitch contour...');
            console.log('Starting reference pitch analysis...');
            referencePitchMap = await analyzeReferencePitchContour(referenceBuffer, referenceAnalyses);
            console.log('Reference pitch map:', referencePitchMap);
            
            if (!referencePitchMap || referencePitchMap.length === 0) {
                console.warn('Reference pitch analysis failed, falling back to no-reference mode');
                updateStatus('Generating professional pitch correction script...');
                melodyneScript = generateMelodyneAutomationNoReference(vocalPitchMap, vocalAnalysis);
            } else {
                updateStatus('Generating Melodyne automation script...');
                melodyneScript = generateMelodyneAutomation(vocalPitchMap, referencePitchMap, vocalAnalysis, referenceAnalysis);
            }
        } else {
            // NO REFERENCE: Use professional pitch correction standards
            updateStatus('Generating professional pitch correction script...');
            melodyneScript = generateMelodyneAutomationNoReference(vocalPitchMap, vocalAnalysis);
        }
        
        console.log('Melodyne script generated:', melodyneScript);
        
        if (!melodyneScript) {
            throw new Error('Failed to generate Melodyne script');
        }
        
        // Export as MDD (Melodyne Document) or ARA script
        const scriptData = JSON.stringify(melodyneScript, null, 2);
        const blob = new Blob([scriptData], { type: 'application/json' });
        const buffer = await blob.arrayBuffer();
        
        const filePath = await ipcRenderer.invoke('save-melodyne-file', buffer);
        
        if (filePath) {
            updateStatus('✅ Melodyne automation script exported!');
            exportMelodyneBtn.textContent = '✓ Script Exported!';
            
            // Show instructions modal
            showMelodyneInstructions(melodyneScript);
            
            setTimeout(() => {
                exportMelodyneBtn.textContent = 'Melodyne Auto';
                exportMelodyneBtn.disabled = false;
            }, 3000);
        } else {
            updateStatus('Export cancelled');
            exportMelodyneBtn.disabled = false;
        }
    } catch (error) {
        console.error('Melodyne export error:', error);
        console.error('Error stack:', error.stack);
        updateStatus(`❌ Error: ${error.message || 'Unknown error'}`);
        exportMelodyneBtn.disabled = false;
        
        // Show error to user
        alert(`Melodyne Export Error:\n\n${error.message}\n\nCheck console for details (Cmd+Option+I)`);
    }
});

// Export Settings as PDF (placeholder - would need PDF library)
exportSettingsBtn.addEventListener('click', async () => {
    if (!generatedSettings) return;
    
    // For now, export as text file
    const settingsText = formatSettingsAsText(generatedSettings);
    const blob = new Blob([settingsText], { type: 'text/plain' });
    const buffer = await blob.arrayBuffer();
    
    const filePath = await ipcRenderer.invoke('save-file', buffer);
    
    if (filePath) {
        updateStatus('Settings exported successfully!');
    } else {
        updateStatus('Export cancelled');
    }
});

// 🤖 AUTOMATE IN LOGIC PRO - AI Vision automation
if (automateLogicBtn) {
    automateLogicBtn.addEventListener('click', async () => {
        if (!generatedSettings) {
            updateStatus('⚠️ Please analyze first');
            return;
        }
        
        try {
            updateStatus('🤖 Preparing Logic Pro automation...');
            automateLogicBtn.disabled = true;
            
            // Build the AI chain
            const aiChain = buildIntelligentChain(vocalAnalysis, referenceAnalysis, generatedSettings);
            
            // Check if user has API key
            const hasApiKey = await ipcRenderer.invoke('check-api-key');
            
            if (!hasApiKey) {
                // Show API key setup modal
                showApiKeySetup();
                automateLogicBtn.disabled = false;
                return;
            }
            
            // Save chain JSON temporarily
            const chainJSON = JSON.stringify(aiChain, null, 2);
            const tempPath = await ipcRenderer.invoke('save-temp-chain', chainJSON);
            
            if (!tempPath) {
                updateStatus('❌ Error saving automation data');
                automateLogicBtn.disabled = false;
                return;
            }
            
            // Show automation modal with instructions
            showAutomationModal(aiChain, tempPath);
            
            // Run automation
            const result = await ipcRenderer.invoke('run-logic-automation', tempPath);
            
            if (result.success) {
                updateStatus(`✅ ${result.message || 'Automation complete!'}`);
                automateLogicBtn.textContent = '✓ Automated!';
                setTimeout(() => {
                    automateLogicBtn.textContent = '🤖 Automate in Logic Pro';
                    automateLogicBtn.disabled = false;
                }, 3000);
            } else {
                updateStatus(`⚠️ ${result.error || 'Automation failed'}`);
                automateLogicBtn.disabled = false;
            }
            
        } catch (error) {
            console.error('Automation error:', error);
            updateStatus('❌ Automation error - check console');
            automateLogicBtn.disabled = false;
        }
    });
}

// Show API key setup modal
function showApiKeySetup() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 600px;">
            <h2>🔑 API Key Required</h2>
            <p>To use AI-powered automation, you need an Anthropic API key.</p>
            
            <div style="background: rgba(102, 126, 234, 0.1); padding: 15px; border-radius: 8px; margin: 20px 0;">
                <h3 style="margin-top: 0;">Get Your API Key:</h3>
                <ol style="margin: 10px 0; padding-left: 20px;">
                    <li>Go to <a href="https://console.anthropic.com/" target="_blank" style="color: #667eea;">console.anthropic.com</a></li>
                    <li>Create an account (if needed)</li>
                    <li>Go to API Keys section</li>
                    <li>Create new key</li>
                    <li>Copy the key</li>
                </ol>
            </div>
            
            <div style="margin: 20px 0;">
                <label style="display: block; margin-bottom: 8px; font-weight: bold;">
                    Paste Your API Key:
                </label>
                <input 
                    type="password" 
                    id="apiKeyInput" 
                    placeholder="sk-ant-api03-..." 
                    style="width: 100%; padding: 10px; border: 1px solid #667eea; border-radius: 5px; background: rgba(255,255,255,0.1); color: white;"
                />
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button onclick="this.closest('.modal-overlay').remove()" 
                        style="padding: 10px 20px; background: rgba(255,255,255,0.1); border: none; border-radius: 5px; color: white; cursor: pointer;">
                    Cancel
                </button>
                <button id="saveApiKey" 
                        style="padding: 10px 20px; background: linear-gradient(135deg, #667eea, #764ba2); border: none; border-radius: 5px; color: white; cursor: pointer; font-weight: bold;">
                    Save & Continue
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Focus input
    setTimeout(() => document.getElementById('apiKeyInput').focus(), 100);
    
    // Save button handler
    document.getElementById('saveApiKey').addEventListener('click', async () => {
        const apiKey = document.getElementById('apiKeyInput').value.trim();
        
        if (!apiKey || !apiKey.startsWith('sk-ant-')) {
            alert('❌ Invalid API key format. Should start with "sk-ant-"');
            return;
        }
        
        // Save API key
        const saved = await ipcRenderer.invoke('save-api-key', apiKey);
        
        if (saved) {
            modal.remove();
            updateStatus('✅ API key saved! Click Automate again.');
        } else {
            alert('❌ Error saving API key');
        }
    });
}

// Show automation modal with live progress
function showAutomationModal(aiChain, chainPath) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.id = 'automationModal';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 700px; max-height: 80vh; overflow-y: auto;">
            <h2>🤖 Logic Pro Automation</h2>
            
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 10px; margin: 20px 0; color: white;">
                <h3 style="margin: 0 0 10px 0;">Chain Ready:</h3>
                <p style="margin: 5px 0;"><strong>${aiChain.name}</strong></p>
                <p style="margin: 5px 0; opacity: 0.9;">${aiChain.plugins.length} plugins with AI parameter setting</p>
            </div>
            
            <div id="automationStatus" style="background: rgba(0,0,0,0.3); padding: 15px; border-radius: 8px; margin: 15px 0; font-family: monospace; max-height: 300px; overflow-y: auto;">
                <div>⏳ Starting automation...</div>
            </div>
            
            <div style="background: rgba(102, 126, 234, 0.1); padding: 15px; border-radius: 8px; margin: 15px 0;">
                <h4 style="margin-top: 0;">📋 Instructions:</h4>
                <ol style="margin: 10px 0; padding-left: 20px; line-height: 1.8;">
                    <li>Logic Pro will activate automatically</li>
                    <li><strong>Click on an empty plugin slot</strong> when prompted</li>
                    <li>Don't touch mouse/keyboard during automation</li>
                    <li>Watch AI load plugins and set parameters!</li>
                </ol>
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button id="stopAutomation" 
                        style="padding: 10px 20px; background: rgba(255, 87, 108, 0.8); border: none; border-radius: 5px; color: white; cursor: pointer; font-weight: bold;">
                    Emergency Stop
                </button>
                <button id="closeAutomationModal" 
                        style="padding: 10px 20px; background: rgba(255,255,255,0.2); border: none; border-radius: 5px; color: white; cursor: pointer;">
                    Close (Keeps Running)
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close button
    document.getElementById('closeAutomationModal').addEventListener('click', () => {
        modal.remove();
    });
    
    // Stop button
    document.getElementById('stopAutomation').addEventListener('click', async () => {
        await ipcRenderer.invoke('stop-automation');
        updateStatus('⚠️ Automation stopped by user');
        modal.remove();
    });
    
    // Listen for automation progress updates
    ipcRenderer.on('automation-progress', (event, data) => {
        const statusDiv = document.getElementById('automationStatus');
        if (statusDiv) {
            const line = document.createElement('div');
            line.textContent = data.message;
            line.style.marginBottom = '5px';
            
            if (data.type === 'success') line.style.color = '#4ade80';
            if (data.type === 'error') line.style.color = '#f87171';
            if (data.type === 'warning') line.style.color = '#fbbf24';
            
            statusDiv.appendChild(line);
            statusDiv.scrollTop = statusDiv.scrollHeight;
        }
    });
}

// Average Multiple Reference Analyses for Better Accuracy
function averageReferenceAnalyses(analyses) {
    if (analyses.length === 0) return null;
    if (analyses.length === 1) return analyses[0];
    
    const avg = {};
    const keys = Object.keys(analyses[0]);
    
    keys.forEach(key => {
        if (typeof analyses[0][key] === 'number') {
            // Average numeric values
            avg[key] = analyses.reduce((sum, analysis) => sum + analysis[key], 0) / analyses.length;
        } else {
            // Keep first value for non-numeric
            avg[key] = analyses[0][key];
        }
    });
    
    console.log(`Averaged ${analyses.length} references:`, avg);
    return avg;
}

// Analyze Vocal Profile and Match to Artists
async function analyzeVocalProfile(audioBuffer) {
    const analysis = await analyzeAudio(audioBuffer);
    
    // Calculate vocal characteristics
    const vocalType = determineVocalType(analysis);
    const energyLevel = determineEnergyLevel(analysis);
    const tonalCharacter = determineTonalCharacter(analysis);
    
    console.log('=== VOCAL ANALYSIS ===');
    console.log('Pitch Variation:', analysis.pitchVariation);
    console.log('Vocal Type:', vocalType);
    console.log('Transients:', analysis.transientStrength);
    console.log('Crest Factor:', analysis.crestFactor);
    console.log('Energy Level:', energyLevel);
    console.log('Brightness:', analysis.brilliance + analysis.air);
    console.log('Warmth:', analysis.bass + analysis.lowMids);
    console.log('Tonal Character:', tonalCharacter);
    console.log('==================');
    
    const similarArtists = matchToArtists(vocalType, energyLevel, tonalCharacter, analysis);
    
    return {
        vocalType,
        energyLevel,
        tonalCharacter,
        pitchRange: analysis.pitchVariation,
        brightness: analysis.brilliance + analysis.air,
        warmth: analysis.bass + analysis.lowMids,
        aggression: analysis.transientStrength,
        similarArtists,
        rawAnalysis: analysis
    };
}

// Determine vocal type
function determineVocalType(analysis) {
    const pitchVar = analysis.pitchVariation;
    
    if (pitchVar < 10) return "Melodic/Sung";
    else if (pitchVar < 25) return "Melodic Rap";
    else if (pitchVar < 40) return "Rhythmic Rap";
    else return "Aggressive/Spoken";
}

// Determine energy level
function determineEnergyLevel(analysis) {
    const transients = analysis.transientStrength;
    const dynamics = analysis.crestFactor;
    
    const energyScore = (transients * 1000) + (dynamics * 2);
    
    if (energyScore > 15) return "High Energy/Aggressive";
    else if (energyScore > 8) return "Medium Energy";
    else return "Low Energy/Smooth";
}

// Determine tonal character
function determineTonalCharacter(analysis) {
    const brightness = analysis.brilliance + analysis.air;
    const warmth = analysis.bass + analysis.lowMids;
    const presence = analysis.presence + analysis.highMids;
    
    const ratio = brightness / (warmth + 0.001);
    
    if (ratio > 1.5 && presence > 0.01) return "Bright/Crisp";
    else if (ratio > 1.0) return "Balanced/Clear";
    else if (warmth > 0.015) return "Warm/Deep";
    else return "Dark/Mellow";
}

// Match to similar artists
function matchToArtists(vocalType, energyLevel, tonalCharacter, analysis) {
    // Artist database with characteristics
    const artistDatabase = [
        // Melodic Rap
        { name: "Drake", type: "Melodic Rap", energy: "Medium Energy", tone: "Warm/Deep", brightness: 0.012, warmth: 0.018 },
        { name: "Post Malone", type: "Melodic/Sung", energy: "Low Energy/Smooth", tone: "Warm/Deep", brightness: 0.011, warmth: 0.020 },
        { name: "Juice WRLD", type: "Melodic Rap", energy: "Medium Energy", tone: "Bright/Crisp", brightness: 0.016, warmth: 0.014 },
        { name: "Lil Uzi Vert", type: "Melodic Rap", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.018, warmth: 0.012 },
        { name: "The Kid LAROI", type: "Melodic/Sung", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.014, warmth: 0.015 },
        
        // Traditional Rap
        { name: "Kendrick Lamar", type: "Rhythmic Rap", energy: "High Energy/Aggressive", tone: "Balanced/Clear", brightness: 0.015, warmth: 0.014 },
        { name: "J. Cole", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Warm/Deep", brightness: 0.012, warmth: 0.017 },
        { name: "Travis Scott", type: "Melodic Rap", energy: "High Energy/Aggressive", tone: "Dark/Mellow", brightness: 0.010, warmth: 0.019 },
        { name: "Future", type: "Melodic Rap", energy: "Medium Energy", tone: "Dark/Mellow", brightness: 0.011, warmth: 0.018 },
        { name: "21 Savage", type: "Rhythmic Rap", energy: "Low Energy/Smooth", tone: "Dark/Mellow", brightness: 0.009, warmth: 0.020 },
        
        // Aggressive Rap
        { name: "Eminem", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.017, warmth: 0.012 },
        { name: "Pop Smoke", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Dark/Mellow", brightness: 0.010, warmth: 0.021 },
        { name: "DaBaby", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Balanced/Clear", brightness: 0.014, warmth: 0.014 },
        { name: "Megan Thee Stallion", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.016, warmth: 0.013 },
        
        // Smooth/Melodic
        { name: "6LACK", type: "Melodic/Sung", energy: "Low Energy/Smooth", tone: "Dark/Mellow", brightness: 0.009, warmth: 0.019 },
        { name: "Bryson Tiller", type: "Melodic/Sung", energy: "Low Energy/Smooth", tone: "Warm/Deep", brightness: 0.011, warmth: 0.018 },
        { name: "PartyNextDoor", type: "Melodic/Sung", energy: "Low Energy/Smooth", tone: "Dark/Mellow", brightness: 0.010, warmth: 0.019 },
        { name: "Roy Woods", type: "Melodic Rap", energy: "Low Energy/Smooth", tone: "Warm/Deep", brightness: 0.012, warmth: 0.017 },
        
        // Modern Trap
        { name: "Lil Baby", type: "Melodic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.015 },
        { name: "Gunna", type: "Melodic Rap", energy: "Low Energy/Smooth", tone: "Warm/Deep", brightness: 0.011, warmth: 0.017 },
        { name: "Young Thug", type: "Melodic Rap", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.016, warmth: 0.013 },
        { name: "Playboi Carti", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.017, warmth: 0.011 },
        
        // Classic Hip-Hop
        { name: "Jay-Z", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Warm/Deep", brightness: 0.012, warmth: 0.016 },
        { name: "Nas", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.015 },
        { name: "Biggie", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Dark/Mellow", brightness: 0.010, warmth: 0.018 },
        { name: "Tupac", type: "Rhythmic Rap", energy: "High Energy/Aggressive", tone: "Balanced/Clear", brightness: 0.014, warmth: 0.015 },
        
        // Alternative/Experimental
        { name: "Tyler, The Creator", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Warm/Deep", brightness: 0.012, warmth: 0.017 },
        { name: "Frank Ocean", type: "Melodic/Sung", energy: "Low Energy/Smooth", tone: "Warm/Deep", brightness: 0.011, warmth: 0.018 },
        { name: "Kid Cudi", type: "Melodic/Sung", energy: "Medium Energy", tone: "Dark/Mellow", brightness: 0.010, warmth: 0.017 },
        { name: "A$AP Rocky", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.015 },
        
        // UK DRILL
        { name: "Headie One", type: "Rhythmic Rap", energy: "Low Energy/Smooth", tone: "Dark/Mellow", brightness: 0.009, warmth: 0.020 },
        { name: "Digga D", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Dark/Mellow", brightness: 0.011, warmth: 0.020 },
        { name: "Central Cee", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.016 },
        { name: "Dave (Santan Dave)", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Warm/Deep", brightness: 0.012, warmth: 0.017 },
        { name: "AJ Tracey", type: "Melodic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.014, warmth: 0.015 },
        { name: "Fivio Foreign", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Dark/Mellow", brightness: 0.010, warmth: 0.019 },
        { name: "Unknown T", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Dark/Mellow", brightness: 0.011, warmth: 0.019 },
        { name: "Abra Cadabra", type: "Rhythmic Rap", energy: "Low Energy/Smooth", tone: "Dark/Mellow", brightness: 0.009, warmth: 0.021 },
        
        // UK GRIME
        { name: "Skepta", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.016, warmth: 0.013 },
        { name: "Stormzy", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Balanced/Clear", brightness: 0.015, warmth: 0.014 },
        { name: "Giggs", type: "Rhythmic Rap", energy: "Low Energy/Smooth", tone: "Dark/Mellow", brightness: 0.008, warmth: 0.021 },
        { name: "Kano", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.016 },
        { name: "Ghetts", type: "Rhythmic Rap", energy: "High Energy/Aggressive", tone: "Balanced/Clear", brightness: 0.015, warmth: 0.015 },
        { name: "JME", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.015 },
        { name: "Wiley", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.016, warmth: 0.012 },
        
        // UK RAP/HIP-HOP
        { name: "J Hus", type: "Melodic Rap", energy: "Medium Energy", tone: "Warm/Deep", brightness: 0.012, warmth: 0.018 },
        { name: "Aitch", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.015 },
        { name: "M Huncho", type: "Melodic Rap", energy: "Low Energy/Smooth", tone: "Dark/Mellow", brightness: 0.010, warmth: 0.019 },
        { name: "NSG", type: "Melodic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.016 },
        { name: "D-Block Europe", type: "Melodic Rap", energy: "Low Energy/Smooth", tone: "Warm/Deep", brightness: 0.011, warmth: 0.018 },
        { name: "Russ Millions", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.016, warmth: 0.013 },
        { name: "Tion Wayne", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.014, warmth: 0.015 },
        { name: "Potter Payper", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Dark/Mellow", brightness: 0.011, warmth: 0.018 },
        { name: "Nines", type: "Rhythmic Rap", energy: "Low Energy/Smooth", tone: "Dark/Mellow", brightness: 0.010, warmth: 0.019 },
        { name: "Krept & Konan", type: "Rhythmic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.016 },
        
        // UK AFROSWING/MELODIC
        { name: "Not3s", type: "Melodic Rap", energy: "Medium Energy", tone: "Warm/Deep", brightness: 0.012, warmth: 0.017 },
        { name: "Kojo Funds", type: "Melodic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.016 },
        { name: "Fredo", type: "Melodic Rap", energy: "Low Energy/Smooth", tone: "Warm/Deep", brightness: 0.011, warmth: 0.018 },
        { name: "Dutchavelli", type: "Melodic Rap", energy: "Medium Energy", tone: "Balanced/Clear", brightness: 0.013, warmth: 0.016 },
        { name: "Adekunle Gold", type: "Melodic/Sung", energy: "Low Energy/Smooth", tone: "Warm/Deep", brightness: 0.011, warmth: 0.017 },
        
        // UK LEGENDS/CLASSICS
        { name: "Dizzee Rascal", type: "Aggressive/Spoken", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.017, warmth: 0.012 },
        { name: "Tinie Tempah", type: "Rhythmic Rap", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.015, warmth: 0.013 },
        { name: "Chip", type: "Rhythmic Rap", energy: "High Energy/Aggressive", tone: "Balanced/Clear", brightness: 0.015, warmth: 0.014 },
        { name: "Example", type: "Melodic/Sung", energy: "High Energy/Aggressive", tone: "Bright/Crisp", brightness: 0.016, warmth: 0.013 }
    ];
    
    // Calculate user's characteristics
    const userBrightness = analysis.brilliance + analysis.air;
    const userWarmth = analysis.bass + analysis.lowMids;
    
    // Score each artist
    const scoredArtists = artistDatabase.map(artist => {
        let score = 0; // Start at 0, not 100!
        
        // Match vocal type (40 points)
        if (artist.type === vocalType) score += 40;
        else if (
            (vocalType === "Melodic Rap" && artist.type === "Melodic/Sung") ||
            (vocalType === "Rhythmic Rap" && artist.type === "Melodic Rap")
        ) score += 20;
        
        // Match energy (30 points)
        if (artist.energy === energyLevel) score += 30;
        else if (
            (energyLevel === "Medium Energy" && artist.energy !== "High Energy/Aggressive") ||
            (energyLevel === "Low Energy/Smooth" && artist.energy === "Medium Energy")
        ) score += 15;
        
        // Match tone (20 points)
        if (artist.tone === tonalCharacter) score += 20;
        else if (
            (tonalCharacter === "Balanced/Clear" && artist.tone !== "Bright/Crisp") ||
            (tonalCharacter === "Warm/Deep" && artist.tone === "Dark/Mellow")
        ) score += 10;
        
        // Match brightness/warmth (10 points)
        const brightnessDiff = Math.abs(artist.brightness - userBrightness);
        const warmthDiff = Math.abs(artist.warmth - userWarmth);
        const spectralScore = Math.max(0, 10 - ((brightnessDiff + warmthDiff) * 200));
        score += spectralScore;
        
        // Cap at 100 and round
        return { ...artist, matchScore: Math.min(100, Math.round(score)) };
    });
    
    // Sort by score and return top 5
    return scoredArtists
        .sort((a, b) => b.matchScore - a.matchScore)
        .slice(0, 5);
}

// Display vocal profile
function displayVocalProfile(profile) {
    // Remove any existing profile
    const existingProfile = document.querySelector('.vocal-profile-card');
    if (existingProfile) {
        existingProfile.remove();
    }
    
    const analysis = profile.rawAnalysis;
    
    const profileHTML = `
        <div class="vocal-profile-card" style="background: linear-gradient(135deg, rgba(0, 255, 136, 0.15) 0%, rgba(0, 212, 255, 0.15) 100%); border: 2px solid rgba(0, 255, 136, 0.4); padding: 25px; border-radius: 12px; margin: 20px 0; box-shadow: 0 4px 15px rgba(0, 255, 136, 0.2);">
            
            <!-- Header -->
            <div style="text-align: center; margin-bottom: 25px; padding-bottom: 20px; border-bottom: 1px solid rgba(255, 255, 255, 0.2);">
                <h2 style="color: #00ff88; margin: 0 0 8px 0; font-size: 1.8em;">📊 PROFESSIONAL VOCAL ANALYSIS</h2>
                <p style="color: #aaa; margin: 0; font-size: 0.95em;">Detailed Spectral & Dynamic Measurements</p>
            </div>
            
            <!-- Technical Measurements -->
            <div style="background: rgba(0, 0, 0, 0.3); padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h3 style="color: #00d4ff; margin: 0 0 15px 0; font-size: 1.2em;">🔬 Technical Specifications</h3>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 12px; border-radius: 6px; border-left: 3px solid #00d4ff;">
                        <div style="color: #888; font-size: 0.85em; margin-bottom: 4px;">RMS Level</div>
                        <div style="color: #00ff88; font-size: 1.3em; font-weight: bold;">${(analysis.rms * 100).toFixed(2)}%</div>
                        <div style="color: #aaa; font-size: 0.75em; margin-top: 2px;">${getRMSRating(analysis.rms)}</div>
                    </div>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 12px; border-radius: 6px; border-left: 3px solid #7b2ff7;">
                        <div style="color: #888; font-size: 0.85em; margin-bottom: 4px;">Peak Level</div>
                        <div style="color: #00ff88; font-size: 1.3em; font-weight: bold;">${(analysis.peak * 100).toFixed(2)}%</div>
                        <div style="color: #aaa; font-size: 0.75em; margin-top: 2px;">${getPeakRating(analysis.peak)}</div>
                    </div>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 12px; border-radius: 6px; border-left: 3px solid #ff6b6b;">
                        <div style="color: #888; font-size: 0.85em; margin-bottom: 4px;">Crest Factor</div>
                        <div style="color: #00ff88; font-size: 1.3em; font-weight: bold;">${analysis.crestFactor.toFixed(2)} dB</div>
                        <div style="color: #aaa; font-size: 0.75em; margin-top: 2px;">${getCrestRating(analysis.crestFactor)}</div>
                    </div>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 12px; border-radius: 6px; border-left: 3px solid #ffaa00;">
                        <div style="color: #888; font-size: 0.85em; margin-bottom: 4px;">Pitch Variation</div>
                        <div style="color: #00ff88; font-size: 1.3em; font-weight: bold;">${analysis.pitchVariation.toFixed(1)} Hz</div>
                        <div style="color: #aaa; font-size: 0.75em; margin-top: 2px;">${profile.vocalType}</div>
                    </div>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 12px; border-radius: 6px; border-left: 3px solid #00ffff;">
                        <div style="color: #888; font-size: 0.85em; margin-bottom: 4px;">Transient Density</div>
                        <div style="color: #00ff88; font-size: 1.3em; font-weight: bold;">${(analysis.transientStrength * 1000).toFixed(1)}</div>
                        <div style="color: #aaa; font-size: 0.75em; margin-top: 2px;">${profile.energyLevel}</div>
                    </div>
                    <div style="background: rgba(255, 255, 255, 0.05); padding: 12px; border-radius: 6px; border-left: 3px solid #ff00ff;">
                        <div style="color: #888; font-size: 0.85em; margin-bottom: 4px;">Sibilance (5-9kHz)</div>
                        <div style="color: #00ff88; font-size: 1.3em; font-weight: bold;">${(analysis.sibilance * 1000).toFixed(2)}</div>
                        <div style="color: #aaa; font-size: 0.75em; margin-top: 2px;">${getSibilanceRating(analysis.sibilance)}</div>
                    </div>
                </div>
            </div>
            
            <!-- Frequency Spectrum Analysis -->
            <div style="background: rgba(0, 0, 0, 0.3); padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h3 style="color: #00d4ff; margin: 0 0 15px 0; font-size: 1.2em;">📈 Frequency Spectrum Analysis</h3>
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px;">
                    ${createFrequencyBar('Sub-Bass', '20-60 Hz', analysis.subBass, '#ff0066')}
                    ${createFrequencyBar('Bass', '60-250 Hz', analysis.bass, '#ff6600')}
                    ${createFrequencyBar('Low-Mids', '250-500 Hz', analysis.lowMids, '#ffaa00')}
                    ${createFrequencyBar('Mids', '500-2k Hz', analysis.mids, '#ffff00')}
                    ${createFrequencyBar('High-Mids', '2-4 kHz', analysis.highMids, '#00ff88')}
                    ${createFrequencyBar('Presence', '4-6 kHz', analysis.presence, '#00d4ff')}
                    ${createFrequencyBar('Brilliance', '6-12 kHz', analysis.brilliance, '#0088ff')}
                    ${createFrequencyBar('Air', '12-20 kHz', analysis.air, '#7b2ff7')}
                </div>
                <div style="margin-top: 15px; padding: 12px; background: rgba(123, 47, 247, 0.1); border-radius: 6px;">
                    <strong style="color: #7b2ff7;">Tonal Character:</strong> 
                    <span style="color: #00ff88; font-size: 1.1em; font-weight: bold;">${profile.tonalCharacter}</span>
                    <span style="color: #aaa; margin-left: 15px;">
                        (Brightness: ${(profile.brightness * 1000).toFixed(1)} | Warmth: ${(profile.warmth * 1000).toFixed(1)})
                    </span>
                </div>
            </div>
            
            <!-- Best Artist Matches -->
            <div style="background: rgba(0, 0, 0, 0.3); padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h3 style="color: #00d4ff; margin: 0 0 15px 0; font-size: 1.2em;">🎯 Best Artist Matches (Top 5)</h3>
                ${profile.similarArtists.map((artist, index) => `
                    <div style="background: linear-gradient(90deg, rgba(0, 212, 255, 0.1) 0%, rgba(123, 47, 247, 0.1) 100%); padding: 15px; border-radius: 8px; margin-bottom: 12px; border: 1px solid rgba(0, 212, 255, 0.3); display: flex; justify-content: space-between; align-items: center;">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; margin-bottom: 8px;">
                                <span style="background: linear-gradient(45deg, #00d4ff, #7b2ff7); color: white; font-weight: bold; padding: 4px 10px; border-radius: 4px; margin-right: 12px; font-size: 0.9em;">#{index + 1}</span>
                                <strong style="color: #00ff88; font-size: 1.3em;">${artist.name}</strong>
                            </div>
                            <div style="color: #aaa; font-size: 0.9em; margin-left: 44px;">
                                ${artist.type} • ${artist.energy} • ${artist.tone}
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="background: linear-gradient(45deg, #00d4ff, #7b2ff7); padding: 10px 20px; border-radius: 8px; font-weight: bold; color: white; font-size: 1.4em; box-shadow: 0 4px 10px rgba(0, 212, 255, 0.3);">
                                ${artist.matchScore}%
                            </div>
                            <div style="color: #00ff88; font-size: 0.8em; margin-top: 4px;">${getMatchRating(artist.matchScore)}</div>
                        </div>
                    </div>
                `).join('')}
                <div style="margin-top: 15px; padding: 12px; background: rgba(0, 255, 136, 0.1); border-radius: 6px; border: 1px solid rgba(0, 255, 136, 0.3);">
                    <strong style="color: #00ff88;">💡 Next Step:</strong> 
                    <span style="color: #e0e0e0;">Use <strong style="color: #00d4ff;">${profile.similarArtists[0].name}</strong> songs as your reference track for optimal plugin settings!</span>
                </div>
            </div>
            
            <!-- Actionable Roadmap -->
            <div style="background: linear-gradient(135deg, rgba(255, 107, 107, 0.15) 0%, rgba(255, 170, 0, 0.15) 100%); padding: 20px; border-radius: 8px; border: 2px solid rgba(255, 170, 0, 0.4);">
                <h3 style="color: #ffaa00; margin: 0 0 15px 0; font-size: 1.3em;">🎯 ROADMAP: How To Match Your Reference Exactly</h3>
                
                <div style="background: rgba(0, 0, 0, 0.4); padding: 15px; border-radius: 6px; margin-bottom: 12px;">
                    <div style="color: #00ff88; font-weight: bold; margin-bottom: 8px;">STEP 1: Load Reference Track</div>
                    <div style="color: #ccc; font-size: 0.95em;">
                        • Click "Load Reference Track" button above<br>
                        • Choose a song from <strong>${profile.similarArtists[0].name}</strong> or similar artist<br>
                        • App will compare YOUR measurements vs. THEIRS
                    </div>
                </div>
                
                <div style="background: rgba(0, 0, 0, 0.4); padding: 15px; border-radius: 6px; margin-bottom: 12px;">
                    <div style="color: #00ff88; font-weight: bold; margin-bottom: 8px;">STEP 2: Get Exact Plugin Settings</div>
                    <div style="color: #ccc; font-size: 0.95em;">
                        • Click "Analyze & Generate Settings" button<br>
                        • App calculates EXACT differences in frequency, dynamics, pitch<br>
                        • Outputs specific EQ frequencies, compression ratios, de-esser settings, etc.
                    </div>
                </div>
                
                <div style="background: rgba(0, 0, 0, 0.4); padding: 15px; border-radius: 6px; margin-bottom: 12px;">
                    <div style="color: #00ff88; font-weight: bold; margin-bottom: 8px;">STEP 3: Apply Settings In Order</div>
                    <div style="color: #ccc; font-size: 0.95em;">
                        • Follow the "Full Chain" tab for correct plugin order<br>
                        • Use exact frequencies and values provided<br>
                        • A/B compare your result with the reference track
                    </div>
                </div>
                
                <div style="background: rgba(0, 0, 0, 0.4); padding: 15px; border-radius: 6px;">
                    <div style="color: #00ff88; font-weight: bold; margin-bottom: 8px;">STEP 4: Fine-Tune By Ear</div>
                    <div style="color: #ccc; font-size: 0.95em;">
                        • Start with 70% of recommended settings<br>
                        • Adjust each plugin while comparing to reference<br>
                        • Trust your ears - match the VIBE, not just the numbers
                    </div>
                </div>
                
                <div style="margin-top: 15px; padding: 12px; background: rgba(255, 107, 107, 0.2); border-radius: 6px; border: 1px solid rgba(255, 107, 107, 0.5);">
                    <strong style="color: #ff6b6b;">⚠️ Important:</strong> 
                    <span style="color: #e0e0e0;">The app gives you the ROADMAP and EXACT NUMBERS. You apply them to achieve the reference sound!</span>
                </div>
            </div>
            
        </div>
    `;
    
    // Insert after vocal info
    vocalInfo.insertAdjacentHTML('afterend', profileHTML);
}

// Helper functions for ratings
function getRMSRating(rms) {
    if (rms < 0.02) return "Very Quiet";
    if (rms < 0.05) return "Quiet";
    if (rms < 0.08) return "Good Level";
    if (rms < 0.12) return "Loud";
    return "Very Loud";
}

function getPeakRating(peak) {
    if (peak < 0.3) return "Low Peak";
    if (peak < 0.6) return "Moderate";
    if (peak < 0.8) return "Good Headroom";
    if (peak < 0.95) return "Near Clipping";
    return "Clipping!";
}

function getCrestRating(crest) {
    if (crest < 3) return "Heavily Compressed";
    if (crest < 5) return "Compressed";
    if (crest < 7) return "Natural Dynamics";
    if (crest < 10) return "Very Dynamic";
    return "Needs Compression";
}

function getSibilanceRating(sibilance) {
    if (sibilance < 0.008) return "Minimal";
    if (sibilance < 0.012) return "Normal";
    if (sibilance < 0.018) return "Noticeable";
    return "Excessive";
}

function getMatchRating(score) {
    if (score >= 90) return "Perfect Match";
    if (score >= 80) return "Excellent Match";
    if (score >= 70) return "Good Match";
    if (score >= 60) return "Fair Match";
    return "Poor Match";
}

function createFrequencyBar(label, range, value, color) {
    const percentage = Math.min(100, (value * 5000)); // Scale for visualization
    return `
        <div style="background: rgba(255, 255, 255, 0.05); padding: 10px; border-radius: 6px; text-align: center;">
            <div style="color: #888; font-size: 0.8em; margin-bottom: 4px;">${label}</div>
            <div style="color: #aaa; font-size: 0.7em; margin-bottom: 6px;">${range}</div>
            <div style="background: rgba(0, 0, 0, 0.3); height: 80px; border-radius: 4px; position: relative; overflow: hidden;">
                <div style="position: absolute; bottom: 0; left: 0; right: 0; height: ${percentage}%; background: linear-gradient(180deg, ${color} 0%, ${color}88 100%); transition: height 0.3s ease;"></div>
            </div>
            <div style="color: ${color}; font-weight: bold; font-size: 0.9em; margin-top: 6px;">${(value * 1000).toFixed(2)}</div>
        </div>
    `;
}

// Audio Analysis Function
async function analyzeAudio(audioBuffer) {
    const channelData = audioBuffer.getChannelData(0);
    const sampleRate = audioBuffer.sampleRate;
    
    // RMS and Peak Analysis
    let sumSquares = 0;
    let peak = 0;
    for (let i = 0; i < channelData.length; i++) {
        const absValue = Math.abs(channelData[i]);
        sumSquares += channelData[i] * channelData[i];
        if (absValue > peak) peak = absValue;
    }
    const rms = Math.sqrt(sumSquares / channelData.length);
    const crestFactor = peak / (rms + 0.0001);
    
    // Frequency analysis
    const fftSize = 8192;
    const frequencyData = performFFT(channelData, fftSize, sampleRate);
    
    // Frequency bands
    const subBass = averageFrequencyBand(frequencyData, 20, 60, sampleRate, fftSize);
    const bass = averageFrequencyBand(frequencyData, 60, 250, sampleRate, fftSize);
    const lowMids = averageFrequencyBand(frequencyData, 250, 500, sampleRate, fftSize);
    const mids = averageFrequencyBand(frequencyData, 500, 2000, sampleRate, fftSize);
    const highMids = averageFrequencyBand(frequencyData, 2000, 4000, sampleRate, fftSize);
    const presence = averageFrequencyBand(frequencyData, 4000, 6000, sampleRate, fftSize);
    const brilliance = averageFrequencyBand(frequencyData, 6000, 12000, sampleRate, fftSize);
    const air = averageFrequencyBand(frequencyData, 12000, 20000, sampleRate, fftSize);
    
    // Sibilance detection (harsh S sounds)
    const sibilance = averageFrequencyBand(frequencyData, 5000, 9000, sampleRate, fftSize);
    
    // Analyze pitch variation (simplified)
    const pitchVariation = analyzePitchVariation(channelData, sampleRate);
    
    // Transient analysis
    const transientStrength = analyzeTransients(channelData);
    
    // Calculate spectral centroid (brightness measure)
    let weightedSum = 0;
    let magnitudeSum = 0;
    for (let k = 0; k < frequencyData.length; k++) {
        const freq = (k * sampleRate) / fftSize;
        weightedSum += freq * frequencyData[k];
        magnitudeSum += frequencyData[k];
    }
    const spectralCentroid = magnitudeSum > 0 ? weightedSum / magnitudeSum : 2000;
    
    return {
        rms,
        peak,
        crestFactor,
        subBass,
        bass,
        lowMids,
        mids,
        highMids,
        presence,
        brilliance,
        air,
        sibilance,
        pitchVariation,
        transientStrength,
        spectralCentroid,
        frequencyData,
        sampleRate
    };
}

// FFT Implementation
function performFFT(audioData, fftSize, sampleRate) {
    const fftData = new Array(fftSize / 2).fill(0);
    
    for (let k = 0; k < fftSize / 2; k++) {
        let real = 0;
        let imag = 0;
        
        for (let n = 0; n < Math.min(fftSize, audioData.length); n++) {
            const angle = (2 * Math.PI * k * n) / fftSize;
            real += audioData[n] * Math.cos(angle);
            imag -= audioData[n] * Math.sin(angle);
        }
        
        fftData[k] = Math.sqrt(real * real + imag * imag) / fftSize;
    }
    
    return fftData;
}

// Average frequency band
function averageFrequencyBand(fftData, freqStart, freqEnd, sampleRate, fftSize) {
    const binStart = Math.floor((freqStart / sampleRate) * fftSize);
    const binEnd = Math.floor((freqEnd / sampleRate) * fftSize);
    
    let sum = 0;
    let count = 0;
    
    for (let i = binStart; i < binEnd && i < fftData.length; i++) {
        sum += fftData[i];
        count++;
    }
    
    return count > 0 ? sum / count : 0;
}

// Analyze pitch variation (simplified autocorrelation)
function analyzePitchVariation(audioData, sampleRate) {
    const windowSize = Math.floor(sampleRate * 0.05); // 50ms windows
    const hopSize = Math.floor(windowSize / 2);
    let totalVariation = 0;
    let count = 0;
    
    for (let i = 0; i < audioData.length - windowSize; i += hopSize) {
        const window = audioData.slice(i, i + windowSize);
        const pitch = estimatePitch(window, sampleRate);
        if (pitch > 0) {
            totalVariation += Math.abs(pitch - 200); // Assuming ~200Hz baseline
            count++;
        }
    }
    
    return count > 0 ? totalVariation / count : 0;
}

// Simple pitch estimation
function estimatePitch(window, sampleRate) {
    const minPeriod = Math.floor(sampleRate / 500); // Max 500Hz
    const maxPeriod = Math.floor(sampleRate / 80);  // Min 80Hz
    
    let bestPeriod = 0;
    let bestCorrelation = 0;
    
    for (let period = minPeriod; period < maxPeriod; period++) {
        let correlation = 0;
        for (let i = 0; i < window.length - period; i++) {
            correlation += window[i] * window[i + period];
        }
        if (correlation > bestCorrelation) {
            bestCorrelation = correlation;
            bestPeriod = period;
        }
    }
    
    return bestPeriod > 0 ? sampleRate / bestPeriod : 0;
}

// Analyze transients
function analyzeTransients(audioData) {
    let transientCount = 0;
    const threshold = 0.1;
    
    for (let i = 1; i < audioData.length; i++) {
        const diff = Math.abs(audioData[i] - audioData[i - 1]);
        if (diff > threshold) {
            transientCount++;
        }
    }
    
    return transientCount / audioData.length;
}

// Display Analysis Results
function displayAnalysis(vocal, reference) {
    const pitchScore = 100 - Math.min(100, vocal.pitchVariation * 2);
    const dynamicScore = 100 - Math.abs((vocal.crestFactor - reference.crestFactor) * 10);
    const tonalScore = calculateMatch(
        [vocal.bass, vocal.mids, vocal.presence, vocal.brilliance],
        [reference.bass, reference.mids, reference.presence, reference.brilliance]
    );
    const brightnessScore = calculateMatch([vocal.brilliance, vocal.air], [reference.brilliance, reference.air]);
    
    document.getElementById('pitchAccuracy').textContent = Math.round(Math.max(0, pitchScore)) + '%';
    document.getElementById('dynamicRange').textContent = Math.round(Math.max(0, dynamicScore)) + '%';
    document.getElementById('tonalBalance').textContent = Math.round(tonalScore) + '%';
    document.getElementById('brightness').textContent = Math.round(brightnessScore) + '%';
}

// Display Vocal-Only Analysis (No Reference)
function displayVocalOnlyAnalysis(vocal) {
    // Instead of comparing to reference, rate against professional standards
    const pitchStability = vocal.pitchVariation < 20 ? 90 : vocal.pitchVariation < 40 ? 70 : 50;
    const dynamicControl = vocal.crestFactor > 10 ? 40 : vocal.crestFactor > 7 ? 60 : vocal.crestFactor > 4 ? 80 : 90;
    
    // Rate tonal balance based on typical vocal ranges
    const hasGoodLows = vocal.bass > 0.012 && vocal.lowMids > 0.015;
    const hasGoodMids = vocal.mids > 0.015 && vocal.highMids > 0.012;
    const hasGoodHighs = vocal.presence > 0.010 && vocal.brilliance > 0.008;
    const tonalBalance = (hasGoodLows ? 30 : 20) + (hasGoodMids ? 40 : 20) + (hasGoodHighs ? 30 : 20);
    
    const brightnessRating = vocal.brilliance + vocal.air > 0.020 ? 85 : vocal.brilliance + vocal.air > 0.015 ? 70 : 55;
    
    document.getElementById('pitchAccuracy').textContent = Math.round(pitchStability) + '%';
    document.getElementById('dynamicRange').textContent = Math.round(dynamicControl) + '%';
    document.getElementById('tonalBalance').textContent = Math.round(tonalBalance) + '%';
    document.getElementById('brightness').textContent = Math.round(brightnessRating) + '%';
}

// Calculate match percentage
function calculateMatch(vocalValues, refValues) {
    let totalDiff = 0;
    
    for (let i = 0; i < vocalValues.length; i++) {
        const diff = Math.abs(vocalValues[i] - refValues[i]);
        const max = Math.max(vocalValues[i], refValues[i], 0.0001);
        totalDiff += diff / max;
    }
    
    const avgDiff = totalDiff / vocalValues.length;
    return Math.max(0, 100 - (avgDiff * 100));
}

// Generate Comprehensive Plugin Settings
function generatePluginSettings(vocal, reference) {
    const settings = {
        pitchCorrection: generatePitchCorrectionSettings(vocal, reference),
        eq: generateEQSettings(vocal, reference),
        compression: generateCompressionSettings(vocal, reference),
        deesser: generateDeEsserSettings(vocal, reference),
        saturation: generateSaturationSettings(vocal, reference),
        reverb: generateReverbSettings(vocal, reference),
        melodyne: generateMelodyneSettings(vocal, reference),
        processingChain: generateProcessingChain()
    };
    
    return settings;
}

// Generate Plugin Settings WITHOUT Reference (Pro Standards)
function generatePluginSettingsNoReference(vocal) {
    // Create an "ideal" reference based on professional standards
    const professionalStandard = {
        pitchVariation: 15, // Stable but natural
        crestFactor: 6, // Well-controlled dynamics
        rms: 0.08, // Good average level
        sibilance: 0.010, // Moderate sibilance
        bass: 0.015,
        lowMids: 0.018,
        mids: 0.020,
        highMids: 0.015,
        presence: 0.012,
        brilliance: 0.010,
        air: 0.008,
        transientStrength: 0.008,
        spectralCentroid: 2500,
        harmonicContent: 0.015
    };
    
    // Use the same generation functions but with professional standard as "reference"
    const settings = {
        pitchCorrection: generatePitchCorrectionSettings(vocal, professionalStandard),
        eq: generateEQSettings(vocal, professionalStandard),
        compression: generateCompressionSettings(vocal, professionalStandard),
        deesser: generateDeEsserSettings(vocal, professionalStandard),
        saturation: generateSaturationSettings(vocal, professionalStandard),
        reverb: generateReverbSettingsNoRef(vocal),
        melodyne: generateMelodyneSettings(vocal, professionalStandard),
        processingChain: generateProcessingChain(),
        isProStandard: true // Flag to indicate this is based on pro standards
    };
    
    return settings;
}

// Generate Reverb Settings without reference
function generateReverbSettingsNoRef(vocal) {
    // Base on vocal type and energy
    const isHighEnergy = vocal.transientStrength > 0.010;
    const isBright = vocal.brilliance + vocal.air > 0.020;
    
    return {
        valhalla: {
            plugin: "Valhalla Room / VintageVerb",
            decay: isHighEnergy ? "0.8-1.2s" : "1.2-1.8s",
            predelay: "25-35ms",
            mix: isHighEnergy ? "10-15%" : "12-18%",
            damping: isBright ? "7-9 kHz" : "5-7 kHz",
            earlyReflections: "Medium",
            note: "Adjust decay time to song tempo"
        },
        wavesHDelay: {
            plugin: "Waves H-Delay",
            time: "1/4 or 1/8 note to song tempo",
            feedback: "20-30%",
            mix: "15-25%",
            locut: "200 Hz",
            hicut: "6 kHz",
            note: "Use delay sparingly for rap vocals"
        },
        description: "Add space without washing out clarity. Keep mix levels conservative for rap/hip-hop."
    };
}

// Generate Pitch Correction Settings
function generatePitchCorrectionSettings(vocal, reference) {
    const needsPitchCorrection = vocal.pitchVariation > 15;
    const correctionStrength = Math.min(100, vocal.pitchVariation * 3);
    
    return {
        // Auto-Tune / Melodyne / Waves Tune
        autoTune: {
            plugin: "Antares Auto-Tune Pro",
            retune: Math.round(20 + (correctionStrength / 2)), // 20-70ms
            humanize: Math.round(30 - (correctionStrength / 10)), // More humanize if less correction needed
            naturalVibrato: Math.round(40 - (correctionStrength / 5)),
            targetNotes: "Chromatic (or set to song key)",
            formantCorrection: correctionStrength > 50 ? "On" : "Off"
        },
        wavesTune: {
            plugin: "Waves Tune Real-Time",
            speed: Math.round(15 + (correctionStrength / 3)),
            note: 100,
            cents: 50,
            transition: correctionStrength > 60 ? 200 : 400
        },
        description: needsPitchCorrection 
            ? "Moderate pitch correction needed. Apply before other processing."
            : "Minimal pitch correction needed. Use light touch to preserve natural performance."
    };
}

// Generate EQ Settings
function generateEQSettings(vocal, reference) {
    const lowCutFreq = vocal.subBass > reference.subBass * 1.5 ? 100 : 80;
    const bassAdjust = ((reference.bass - vocal.bass) / Math.max(reference.bass, 0.001)) * 6;
    const midAdjust = ((reference.mids - vocal.mids) / Math.max(reference.mids, 0.001)) * 4;
    const presenceAdjust = ((reference.presence - vocal.presence) / Math.max(reference.presence, 0.001)) * 5;
    const brillianceAdjust = ((reference.brilliance - vocal.brilliance) / Math.max(reference.brilliance, 0.001)) * 4;
    const airAdjust = ((reference.air - vocal.air) / Math.max(reference.air, 0.001)) * 3;
    
    return {
        fabirFQ: {
            plugin: "FabFilter Pro-Q 3",
            bands: [
                {
                    freq: `${lowCutFreq}Hz`,
                    type: "High Pass",
                    slope: "24 dB/oct",
                    gain: "N/A"
                },
                {
                    freq: "200Hz",
                    type: "Bell",
                    q: 1.2,
                    gain: `${Math.round(Math.max(-6, Math.min(6, bassAdjust)))} dB`
                },
                {
                    freq: "800Hz",
                    type: "Bell",
                    q: 1.5,
                    gain: `${Math.round(Math.max(-4, Math.min(4, midAdjust)))} dB`
                },
                {
                    freq: "3kHz",
                    type: "Bell",
                    q: 2.0,
                    gain: `${Math.round(Math.max(-5, Math.min(5, presenceAdjust)))} dB`
                },
                {
                    freq: "8kHz",
                    type: "Bell",
                    q: 1.5,
                    gain: `${Math.round(Math.max(-4, Math.min(4, brillianceAdjust)))} dB`
                },
                {
                    freq: "12kHz",
                    type: "High Shelf",
                    q: 0.7,
                    gain: `${Math.round(Math.max(-3, Math.min(3, airAdjust)))} dB`
                }
            ]
        },
        wavesREQ: {
            plugin: "Waves Renaissance EQ",
            settings: `Similar to above - HPF at ${lowCutFreq}Hz, adjust bands accordingly`
        },
        description: "Apply EQ after pitch correction but before compression for most natural results."
    };
}

// Generate Compression Settings
function generateCompressionSettings(vocal, reference) {
    const dynamicDiff = Math.abs(vocal.crestFactor - reference.crestFactor);
    const needsCompression = vocal.crestFactor > reference.crestFactor * 1.2;
    const ratio = needsCompression ? Math.min(8, 3 + dynamicDiff) : 3;
    const threshold = vocal.rms > reference.rms ? -16 : -20;
    
    return {
        cla76: {
            plugin: "Waves CLA-76 (1176 style)",
            input: "+2 to +6 dB",
            output: "Adjust to unity gain",
            attack: "Fastest (7)",
            release: "Fastest (7)",
            ratio: needsCompression ? "8:1 or 4:1" : "4:1",
            note: "Use for adding aggression and character to rap vocals"
        },
        cla2a: {
            plugin: "Waves CLA-2A (LA-2A style)",
            peakReduction: `${Math.round(4 + (dynamicDiff * 2))} (clock position)`,
            gain: "Compensate for reduction",
            compress: "Normal",
            note: "Use for smooth, transparent compression. Good for melodic sections."
        },
        fabfilterProC: {
            plugin: "FabFilter Pro-C 2",
            threshold: `${threshold} dB`,
            ratio: `${Math.round(ratio)}:1`,
            attack: needsCompression ? "10ms" : "30ms",
            release: "Auto (or 100-150ms)",
            knee: "Medium",
            style: "Vocal",
            lookahead: "On (10ms)"
        },
        ssl: {
            plugin: "Waves SSL G-Master Buss Compressor",
            threshold: "-10 to -15 dB",
            ratio: "2:1",
            attack: "30ms",
            release: "Auto",
            note: "Optional: Use on vocal bus for glue"
        },
        description: "Two-stage compression recommended: CLA-76 for character, then Pro-C 2 for control."
    };
}

// Generate De-Esser Settings
function generateDeEsserSettings(vocal, reference) {
    const sibilanceLevel = vocal.sibilance / Math.max(reference.sibilance, 0.001);
    const needsDeessing = sibilanceLevel > 1.2;
    const reductionAmount = Math.min(12, (sibilanceLevel - 1) * 6);
    
    return {
        fabfilterDS: {
            plugin: "FabFilter Pro-DS",
            range: `${Math.round(reductionAmount)} dB`,
            threshold: "Adjust so only sibilance triggers (typically -20 to -30 dB)",
            frequency: "6-8 kHz (use lookahead feature)",
            audition: "Use to find exact frequency",
            stereoLink: "100%"
        },
        wavesDESSER: {
            plugin: "Waves Renaissance DeEsser",
            frequency: "6500 Hz",
            threshold: "-30 dB",
            attenuation: `${Math.round(reductionAmount)} dB`
        },
        description: needsDeessing 
            ? "Strong de-essing needed. Apply after EQ and compression."
            : "Light de-essing. Only reduce harsh S sounds, don't remove all high end."
    };
}

// Generate Saturation Settings
function generateSaturationSettings(vocal, reference) {
    const needsWarmth = vocal.bass < reference.bass * 0.8;
    const needsAggression = reference.transientStrength > vocal.transientStrength * 1.2;
    
    return {
        decapitator: {
            plugin: "Soundtoys Decapitator",
            drive: needsAggression ? "4-6" : "2-4",
            style: needsAggression ? "A (Ampex)" : "E (Even Harmonics)",
            mix: "20-40%",
            thump: needsWarmth ? "+3 to +5" : "0",
            steep: "Off (unless you want filter)"
        },
        wavesJPuigChild: {
            plugin: "Waves J37 Tape",
            tape: "Medium",
            speed: "15 IPS",
            formula: needsWarmth ? "815" : "900",
            wow: "15-20%",
            flutter: "20-25%",
            note: "Use for vintage tape warmth"
        },
        description: "Subtle saturation adds harmonics and glue. Less is more - mix at 20-40%."
    };
}

// Generate Reverb/Delay Settings
function generateReverbSettings(vocal, reference) {
    return {
        valhalla: {
            plugin: "Valhalla Room / VintageVerb",
            decay: "0.8-1.5s (adjust to song tempo)",
            predelay: "20-40ms",
            mix: "10-20% (or use send/return)",
            damping: "6-8 kHz",
            earlyReflections: "Medium",
            note: "For ambience and space"
        },
        wavesHDelay: {
            plugin: "Waves H-Delay",
            time: "Quarter note or eighth note to song tempo",
            feedback: "20-30%",
            mix: "15-25%",
            locut: "200 Hz",
            hicut: "6 kHz",
            note: "Slapback delay for depth"
        },
        description: "Apply reverb and delay on sends/returns. Keep subtle for rap vocals - clarity is key."
    };
}

// Generate Melodyne Settings
function generateMelodyneSettings(vocal, reference) {
    const pitchIssues = vocal.pitchVariation > 20;
    const timingIssues = vocal.transientStrength < reference.transientStrength * 0.8;
    
    return {
        workflow: {
            step1: "Transfer audio to Melodyne (use ARA if available)",
            step2: "Select algorithm: 'Melodic' for pitched vocals, 'Percussive' for rhythmic rap",
            step3: "Analyze audio - wait for blob detection"
        },
        pitchCorrection: {
            tool: "Pitch Tool",
            correctPitch: pitchIssues ? "Moderate to Strong" : "Light",
            method: "Snap to scale or manual adjustment",
            preserveFormant: "Yes",
            pitchModulation: "Reduce by 30-50% if too much vibrato",
            pitchDrift: "Correct long notes that drift flat/sharp"
        },
        timingCorrection: {
            tool: "Time Tool",
            quantize: timingIssues ? "Moderate" : "Light",
            method: "Align to grid or manually shift",
            preserveLength: "Adjust as needed",
            note: "Don't over-quantize rap - pocket is important"
        },
        formantCorrection: {
            tool: "Formant Tool",
            adjust: "Only if pitch correction sounds unnatural",
            amount: "-10% to +10%",
            note: "Compensates for 'chipmunk' or 'demonic' effects"
        },
        advancedTechniques: {
            separateNotesBlob: "Split blobs that should be separate notes",
            levelingTool: "Reduce volume of loud syllables",
            sibilanceControl: "Lower level of harsh S sounds",
            breathControl: "Reduce or remove loud breaths"
        },
        description: pitchIssues 
            ? "Significant pitch correction needed. Use Melodyne for surgical control."
            : "Minor tuning only. Preserve the natural performance character."
    };
}

// Generate Processing Chain
function generateProcessingChain() {
    return {
        order: [
            { step: 1, plugin: "Melodyne", purpose: "Pitch and timing correction" },
            { step: 2, plugin: "Auto-Tune / Waves Tune", purpose: "Real-time pitch correction" },
            { step: 3, plugin: "EQ (Subtractive)", purpose: "Remove problem frequencies, high-pass filter" },
            { step: 4, plugin: "Compression (CLA-76)", purpose: "Add character and initial control" },
            { step: 5, plugin: "EQ (Additive)", purpose: "Shape tone to match reference" },
            { step: 6, plugin: "Compression (Pro-C 2)", purpose: "Final dynamic control" },
            { step: 7, plugin: "De-Esser", purpose: "Tame sibilance" },
            { step: 8, plugin: "Saturation", purpose: "Add warmth and harmonics" },
            { step: 9, plugin: "Reverb (Send)", purpose: "Add space and depth" },
            { step: 10, plugin: "Delay (Send)", purpose: "Add dimension" }
        ],
        notes: [
            "This is a typical vocal chain - adjust based on your needs",
            "Use sends/returns for reverb and delay",
            "Monitor levels at each stage - don't let signal clip",
            "A/B compare with bypass to ensure you're improving the sound",
            "Less is often more - don't over-process"
        ]
    };
}

// Display Plugin Settings in UI
// Display plugin chain preview in Chain tab
function displayPluginChainPreview(settings) {
    const chainPreview = document.getElementById('pluginChainPreview');
    
    if (!chainPreview) {
        console.error('pluginChainPreview element not found!');
        return;
    }
    
    if (!settings) {
        console.warn('No settings provided to displayPluginChainPreview');
        return;
    }
    
    // Use the processingChain that's already generated
    if (settings.processingChain && settings.processingChain.order) {
        chainPreview.innerHTML = settings.processingChain.order.map((step) => `
            <div class="plugin-item">
                <div class="plugin-header">
                    <span class="plugin-name">${step.step}. ${step.plugin}</span>
                    <span class="plugin-category">Step ${step.step}</span>
                </div>
                <div class="plugin-reason">${step.purpose}</div>
            </div>
        `).join('');
    } else {
        // Fallback: Build simple chain from available settings
        const plugins = [];
        
        if (settings.pitchCorrection) {
            plugins.push({ name: 'Pitch Correction', category: 'Tuning', reason: settings.pitchCorrection.description || 'Fix pitch issues' });
        }
        
        if (settings.eq) {
            plugins.push({ name: 'EQ', category: 'Tone', reason: 'Shape frequency response' });
        }
        
        if (settings.compression) {
            plugins.push({ name: 'Compression', category: 'Dynamics', reason: 'Control dynamics' });
        }
        
        if (settings.deesser) {
            plugins.push({ name: 'De-Esser', category: 'Dynamics', reason: 'Reduce sibilance' });
        }
        
        if (settings.saturation) {
            plugins.push({ name: 'Saturation', category: 'Color', reason: 'Add warmth and harmonics' });
        }
        
        if (settings.reverb) {
            plugins.push({ name: 'Reverb', category: 'Space', reason: 'Add depth and ambience' });
        }
        
        chainPreview.innerHTML = plugins.map((plugin, index) => `
            <div class="plugin-item">
                <div class="plugin-header">
                    <span class="plugin-name">${index + 1}. ${plugin.name}</span>
                    <span class="plugin-category">${plugin.category}</span>
                </div>
                <div class="plugin-reason">${plugin.reason}</div>
            </div>
        `).join('');
    }
}

function displayPluginSettings(settings) {
    const container = document.getElementById('pluginSettingsContainer');
    
    if (!container) {
        console.error('Plugin settings container not found!');
        return;
    }
    
    // Create simple settings display for new UI
    let html = '';
    
    // Pitch Correction
    if (settings.pitchCorrection) {
        html += `
            <div class="settings-plugin">
                <h3>🎯 Pitch Correction</h3>
                <div class="setting-row">
                    <span class="setting-label">Plugin</span>
                    <span class="setting-value">Auto-Tune Pro / Waves Tune</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Speed</span>
                    <span class="setting-value">${settings.pitchCorrection.autoTune?.retune || '40'}ms</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Humanize</span>
                    <span class="setting-value">${settings.pitchCorrection.autoTune?.humanize || '20'}</span>
                </div>
            </div>
        `;
    }
    
    // EQ
    if (settings.eq) {
        const eqBands = settings.eq.fabirFQ?.bands || [];
        html += `
            <div class="settings-plugin">
                <h3>🎚️ EQ (FabFilter Pro-Q 3)</h3>
                <div class="setting-row">
                    <span class="setting-label">High Pass</span>
                    <span class="setting-value">${eqBands[0]?.freq || '80Hz'}</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Total Bands</span>
                    <span class="setting-value">${eqBands.length} bands configured</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Description</span>
                    <span class="setting-value">${settings.eq.description || 'Frequency shaping'}</span>
                </div>
            </div>
        `;
    }
    
    // Compression
    if (settings.compression) {
        const cla76 = settings.compression.cla76 || {};
        const proC = settings.compression.fabfilterProC || {};
        html += `
            <div class="settings-plugin">
                <h3>📊 Compression</h3>
                <div class="setting-row">
                    <span class="setting-label">Plugin</span>
                    <span class="setting-value">Waves CLA-76 / Pro-C 2</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Ratio</span>
                    <span class="setting-value">${proC.ratio || cla76.ratio || '4:1'}</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Attack</span>
                    <span class="setting-value">${proC.attack || cla76.attack || '10'}ms</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Release</span>
                    <span class="setting-value">${proC.release || cla76.release || 'Auto'}</span>
                </div>
            </div>
        `;
    }
    
    // De-Esser
    if (settings.deesser) {
        const deesser = settings.deesser.wavesDESSER || settings.deesser.fabfilterDS || {};
        html += `
            <div class="settings-plugin">
                <h3>🔇 De-Esser</h3>
                <div class="setting-row">
                    <span class="setting-label">Frequency</span>
                    <span class="setting-value">${deesser.frequency || '6500 Hz'}</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Threshold</span>
                    <span class="setting-value">${deesser.threshold || '-30 dB'}</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Attenuation</span>
                    <span class="setting-value">${deesser.attenuation || deesser.range || '6 dB'}</span>
                </div>
            </div>
        `;
    }
    
    // Saturation
    if (settings.saturation) {
        const saturation = settings.saturation.decapitator || settings.saturation.wavesJPuigChild || {};
        html += `
            <div class="settings-plugin">
                <h3>🔥 Saturation</h3>
                <div class="setting-row">
                    <span class="setting-label">Plugin</span>
                    <span class="setting-value">Decapitator / J37 Tape</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Drive/Amount</span>
                    <span class="setting-value">${saturation.drive || saturation.tape || 'Medium'}</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Mix</span>
                    <span class="setting-value">${saturation.mix || '30'}%</span>
                </div>
            </div>
        `;
    }
    
    // Reverb
    if (settings.reverb) {
        const reverb = settings.reverb.valhalla || {};
        html += `
            <div class="settings-plugin">
                <h3>✨ Reverb</h3>
                <div class="setting-row">
                    <span class="setting-label">Type</span>
                    <span class="setting-value">Room / Plate</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Decay</span>
                    <span class="setting-value">${reverb.decay || '1.2'}s</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Mix</span>
                    <span class="setting-value">${reverb.mix || '15'}%</span>
                </div>
            </div>
        `;
    }
    
    // Melodyne
    if (settings.melodyne) {
        html += `
            <div class="settings-plugin">
                <h3>🎵 Melodyne</h3>
                <div class="setting-row">
                    <span class="setting-label">Algorithm</span>
                    <span class="setting-value">${settings.melodyne.workflow?.step2 || 'Melodic'}</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Pitch Correction</span>
                    <span class="setting-value">${settings.melodyne.pitchCorrection?.correctPitch || 'Moderate'}</span>
                </div>
                <div class="setting-row">
                    <span class="setting-label">Description</span>
                    <span class="setting-value">${settings.melodyne.description || 'Advanced pitch editing'}</span>
                </div>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

// Create Plugin Card HTML
function createPluginCard(name, type, settingsObj, description = '') {
    let settingsHTML = '';
    
    for (const [key, value] of Object.entries(settingsObj)) {
        if (key === 'plugin' || key === 'note' || key === 'bands') continue;
        settingsHTML += `
            <div class="setting-item">
                <span class="setting-label">${formatLabel(key)}</span>
                <span class="setting-value">${value}</span>
            </div>
        `;
    }
    
    const note = settingsObj.note ? `<div class="tip-box"><strong>Note:</strong> ${settingsObj.note}</div>` : '';
    const desc = description ? `<p class="plugin-description">${description}</p>` : '';
    
    return `
        <div class="plugin-card">
            <div class="plugin-header">
                <span class="plugin-name">${name}</span>
                <span class="plugin-type">${type}</span>
            </div>
            ${desc}
            <div class="settings-grid">
                ${settingsHTML}
            </div>
            ${note}
        </div>
    `;
}

// Create EQ Card HTML
function createEQCard(eqData, description) {
    const bandsHTML = eqData.bands.map((band, index) => `
        <div class="setting-item">
            <span class="setting-label">Band ${index + 1}: ${band.freq}</span>
            <span class="setting-value">${band.type} | Q: ${band.q || 'N/A'} | Gain: ${band.gain || band.slope}</span>
        </div>
    `).join('');
    
    return `
        <div class="plugin-card">
            <div class="plugin-header">
                <span class="plugin-name">FabFilter Pro-Q 3</span>
                <span class="plugin-type">Equalizer</span>
            </div>
            <p class="plugin-description">${description}</p>
            <div class="settings-grid">
                ${bandsHTML}
            </div>
            <div class="tip-box">
                <strong>Tip:</strong> Make small adjustments (±3dB) and sweep to find problem frequencies. Use the spectrum analyzer to visualize changes.
            </div>
        </div>
    `;
}

// Create Melodyne Card HTML
function createMelodyneCard(melodyne) {
    return `
        <div class="plugin-card">
            <div class="plugin-header">
                <span class="plugin-name">Celemony Melodyne</span>
                <span class="plugin-type">Advanced Pitch & Timing Correction</span>
            </div>
            <p class="plugin-description">${melodyne.description}</p>
            
            <h3 style="color: #00d4ff; margin: 20px 0 10px 0;">Workflow</h3>
            <div class="chain-step">
                <div class="step-number">1</div>
                <div class="step-info">
                    <div class="step-name">${melodyne.workflow.step1}</div>
                </div>
            </div>
            <div class="chain-step">
                <div class="step-number">2</div>
                <div class="step-info">
                    <div class="step-name">${melodyne.workflow.step2}</div>
                </div>
            </div>
            <div class="chain-step">
                <div class="step-number">3</div>
                <div class="step-info">
                    <div class="step-name">${melodyne.workflow.step3}</div>
                </div>
            </div>

            <h3 style="color: #00d4ff; margin: 20px 0 10px 0;">Pitch Correction</h3>
            <div class="settings-grid">
                ${Object.entries(melodyne.pitchCorrection).map(([key, value]) => `
                    <div class="setting-item">
                        <span class="setting-label">${formatLabel(key)}</span>
                        <span class="setting-value">${value}</span>
                    </div>
                `).join('')}
            </div>

            <h3 style="color: #00d4ff; margin: 20px 0 10px 0;">Timing Correction</h3>
            <div class="settings-grid">
                ${Object.entries(melodyne.timingCorrection).map(([key, value]) => `
                    <div class="setting-item">
                        <span class="setting-label">${formatLabel(key)}</span>
                        <span class="setting-value">${value}</span>
                    </div>
                `).join('')}
            </div>

            <h3 style="color: #00d4ff; margin: 20px 0 10px 0;">Advanced Techniques</h3>
            <div class="settings-grid">
                ${Object.entries(melodyne.advancedTechniques).map(([key, value]) => `
                    <div class="setting-item">
                        <span class="setting-label">${formatLabel(key)}</span>
                        <span class="setting-value">${value}</span>
                    </div>
                `).join('')}
            </div>

            <div class="warning-box">
                <strong>Warning:</strong> Over-correction destroys the natural feel. Aim for 70-80% correction, not 100%.
            </div>
        </div>
    `;
}

// Create Chain Card HTML
function createChainCard(chain) {
    const stepsHTML = chain.order.map(step => `
        <div class="chain-step">
            <div class="step-number">${step.step}</div>
            <div class="step-info">
                <div class="step-name">${step.plugin}</div>
                <div class="step-purpose">${step.purpose}</div>
            </div>
        </div>
    `).join('');
    
    const notesHTML = chain.notes.map(note => `<li>${note}</li>`).join('');
    
    return `
        <div class="chain-overview">
            <h3>Complete Processing Chain</h3>
            <p>Apply plugins in this order for optimal results:</p>
            ${stepsHTML}
        </div>
        
        <div class="tip-box">
            <strong>Important Notes:</strong>
            <ul style="margin: 10px 0 0 20px; line-height: 1.8;">
                ${notesHTML}
            </ul>
        </div>
    `;
}

// Format label helper
function formatLabel(key) {
    return key
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, str => str.toUpperCase())
        .trim();
}

// ============================================================================
// MELODYNE AUTOMATIC PITCH CORRECTION
// Analyzes reference pitch contour and generates automation to match
// ============================================================================

// Analyze pitch contour of vocal with high precision
async function analyzePitchContour(audioBuffer) {
    const channelData = audioBuffer.getChannelData(0);
    const sampleRate = audioBuffer.sampleRate;
    const windowSize = 2048; // High precision
    const hopSize = 512;
    const pitchMap = [];
    
    console.log('Analyzing vocal pitch contour...');
    
    // Analyze in small windows for detailed pitch tracking
    for (let i = 0; i < channelData.length - windowSize; i += hopSize) {
        const window = channelData.slice(i, i + windowSize);
        const timeStamp = i / sampleRate;
        
        // Detect pitch using autocorrelation
        const pitch = detectPitchYIN(window, sampleRate);
        
        if (pitch && pitch > 50 && pitch < 1000) { // Valid vocal range
            const note = frequencyToNote(pitch);
            const cents = frequencyToCents(pitch, note.frequency);
            
            pitchMap.push({
                time: timeStamp,
                frequency: pitch,
                note: note.name,
                midiNote: note.midi,
                cents: cents,
                amplitude: calculateRMS(window),
                confidence: calculatePitchConfidence(window, pitch, sampleRate)
            });
        }
    }
    
    console.log(`Detected ${pitchMap.length} pitch points`);
    return pitchMap;
}

// Analyze reference pitch contour (averaged if multiple references)
async function analyzeReferencePitchContour(audioBuffer, referenceAnalyses) {
    if (referenceAnalyses && referenceAnalyses.length > 1) {
        console.log(`Analyzing and averaging ${referenceAnalyses.length} reference pitch contours...`);
        
        // Analyze each reference
        const allPitchMaps = [];
        for (const ref of referenceAnalyses) {
            if (ref && ref.buffer) {
                const pitchMap = await analyzePitchContour(ref.buffer);
                allPitchMaps.push(pitchMap);
            }
        }
        
        if (allPitchMaps.length === 0) {
            throw new Error('No valid reference buffers found');
        }
        
        // Average the pitch contours
        return averagePitchContours(allPitchMaps);
    } else if (audioBuffer) {
        // Single reference with audioBuffer
        return await analyzePitchContour(audioBuffer);
    } else if (referenceAnalyses && referenceAnalyses.length === 1 && referenceAnalyses[0].buffer) {
        // Single reference in array
        return await analyzePitchContour(referenceAnalyses[0].buffer);
    } else {
        throw new Error('No reference audio available for pitch analysis');
    }
}

// Average multiple pitch contours for more accurate target
function averagePitchContours(pitchMaps) {
    // Find time-aligned average
    const averaged = [];
    const maxLength = Math.max(...pitchMaps.map(pm => pm.length));
    
    for (let i = 0; i < maxLength; i++) {
        const validPitches = pitchMaps
            .map(pm => pm[i])
            .filter(p => p && p.frequency);
        
        if (validPitches.length > 0) {
            averaged.push({
                time: validPitches[0].time,
                frequency: validPitches.reduce((sum, p) => sum + p.frequency, 0) / validPitches.length,
                note: validPitches[0].note,
                midiNote: Math.round(validPitches.reduce((sum, p) => sum + p.midiNote, 0) / validPitches.length),
                cents: validPitches.reduce((sum, p) => sum + p.cents, 0) / validPitches.length,
                amplitude: validPitches.reduce((sum, p) => sum + p.amplitude, 0) / validPitches.length,
                confidence: validPitches.reduce((sum, p) => sum + p.confidence, 0) / validPitches.length
            });
        }
    }
    
    console.log(`Averaged pitch contour: ${averaged.length} points`);
    return averaged;
}

// YIN pitch detection algorithm (high accuracy)
function detectPitchYIN(buffer, sampleRate) {
    const threshold = 0.1;
    const bufferSize = buffer.length;
    const yinBuffer = new Float32Array(bufferSize / 2);
    
    // Step 1: Calculate difference function
    for (let tau = 0; tau < bufferSize / 2; tau++) {
        let sum = 0;
        for (let i = 0; i < bufferSize / 2; i++) {
            const delta = buffer[i] - buffer[i + tau];
            sum += delta * delta;
        }
        yinBuffer[tau] = sum;
    }
    
    // Step 2: Cumulative mean normalized difference
    yinBuffer[0] = 1;
    let runningSum = 0;
    for (let tau = 1; tau < bufferSize / 2; tau++) {
        runningSum += yinBuffer[tau];
        yinBuffer[tau] *= tau / runningSum;
    }
    
    // Step 3: Absolute threshold
    let tau = -1;
    for (let i = 2; i < bufferSize / 2; i++) {
        if (yinBuffer[i] < threshold) {
            while (i + 1 < bufferSize / 2 && yinBuffer[i + 1] < yinBuffer[i]) {
                i++;
            }
            tau = i;
            break;
        }
    }
    
    if (tau === -1) return null;
    
    // Step 4: Parabolic interpolation
    let betterTau = tau;
    if (tau > 0 && tau < bufferSize / 2 - 1) {
        const s0 = yinBuffer[tau - 1];
        const s1 = yinBuffer[tau];
        const s2 = yinBuffer[tau + 1];
        betterTau = tau + (s2 - s0) / (2 * (2 * s1 - s2 - s0));
    }
    
    return sampleRate / betterTau;
}

// Convert frequency to note
function frequencyToNote(frequency) {
    const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const midiNote = Math.round(12 * Math.log2(frequency / 440) + 69);
    const noteName = noteNames[midiNote % 12];
    const octave = Math.floor(midiNote / 12) - 1;
    const noteFreq = 440 * Math.pow(2, (midiNote - 69) / 12);
    
    return {
        name: `${noteName}${octave}`,
        midi: midiNote,
        frequency: noteFreq
    };
}

// Convert frequency to cents deviation from nearest note
function frequencyToCents(frequency, targetFrequency) {
    return 1200 * Math.log2(frequency / targetFrequency);
}

// Calculate pitch detection confidence
function calculatePitchConfidence(buffer, pitch, sampleRate) {
    const period = sampleRate / pitch;
    let correlation = 0;
    let norm = 0;
    
    for (let i = 0; i < buffer.length - period; i++) {
        correlation += buffer[i] * buffer[i + Math.round(period)];
        norm += buffer[i] * buffer[i];
    }
    
    return Math.abs(correlation / (norm + 0.0001));
}

// Generate Melodyne automation script
function generateMelodyneAutomation(vocalPitchMap, referencePitchMap, vocalAnalysis, referenceAnalysis) {
    console.log('Generating Melodyne automation...');
    
    const corrections = [];
    let totalCorrection = 0;
    let correctionCount = 0;
    
    // Match vocal pitch points to reference
    for (let i = 0; i < vocalPitchMap.length; i++) {
        const vocalPoint = vocalPitchMap[i];
        
        // Find closest reference point in time
        const refIndex = Math.min(i, referencePitchMap.length - 1);
        const refPoint = referencePitchMap[refIndex];
        
        if (!refPoint) continue;
        
        // Calculate correction needed
        const pitchDiff = refPoint.frequency - vocalPoint.frequency;
        const centsDiff = 1200 * Math.log2(refPoint.frequency / vocalPoint.frequency);
        
        // Only correct if significant difference and high confidence
        if (Math.abs(centsDiff) > 5 && vocalPoint.confidence > 0.7) {
            corrections.push({
                time: vocalPoint.time,
                originalPitch: vocalPoint.frequency,
                originalNote: vocalPoint.note,
                targetPitch: refPoint.frequency,
                targetNote: refPoint.note,
                centsCorrection: centsDiff,
                pitchShiftRatio: refPoint.frequency / vocalPoint.frequency,
                amplitude: vocalPoint.amplitude,
                confidence: vocalPoint.confidence,
                action: Math.abs(centsDiff) > 50 ? "MAJOR_CORRECTION" : "MINOR_CORRECTION"
            });
            
            totalCorrection += Math.abs(centsDiff);
            correctionCount++;
        }
    }
    
    const avgCorrection = correctionCount > 0 ? totalCorrection / correctionCount : 0;
    
    const script = {
        version: "1.0",
        application: "Melodyne 5 Studio",
        description: "AI-generated pitch correction to match reference",
        statistics: {
            totalPoints: vocalPitchMap.length,
            correctionsNeeded: corrections.length,
            averageCorrection: avgCorrection.toFixed(1) + " cents",
            maxCorrection: corrections.length > 0 ? Math.max(...corrections.map(c => Math.abs(c.centsCorrection))).toFixed(1) + " cents" : "0 cents"
        },
        referenceAnalysis: {
            averagePitch: (referencePitchMap.reduce((sum, p) => sum + p.frequency, 0) / referencePitchMap.length).toFixed(1) + " Hz",
            pitchRange: {
                min: Math.min(...referencePitchMap.map(p => p.frequency)).toFixed(1) + " Hz",
                max: Math.max(...referencePitchMap.map(p => p.frequency)).toFixed(1) + " Hz"
            }
        },
        corrections: corrections,
        instructions: generateMelodyneInstructions(corrections, avgCorrection)
    };
    
    console.log(`Generated ${corrections.length} pitch corrections (avg: ${avgCorrection.toFixed(1)} cents)`);
    
    return script;
}

// Generate Melodyne automation script WITHOUT reference (professional standards)
function generateMelodyneAutomationNoReference(vocalPitchMap, vocalAnalysis) {
    console.log('Generating Melodyne automation (no reference - using professional standards)...');
    
    const corrections = [];
    let totalCorrection = 0;
    let correctionCount = 0;
    
    // Calculate average pitch to determine key center
    const avgFreq = vocalPitchMap.reduce((sum, p) => sum + p.frequency, 0) / vocalPitchMap.length;
    
    // For each pitch point, correct to nearest note with professional tuning
    for (let i = 0; i < vocalPitchMap.length; i++) {
        const vocalPoint = vocalPitchMap[i];
        
        // Find nearest musical note
        const nearestNote = frequencyToNote(vocalPoint.frequency);
        const targetFrequency = nearestNote.frequency;
        const centsDiff = frequencyToCents(vocalPoint.frequency, targetFrequency);
        
        // Correct if off by more than 5 cents and confidence is high
        // Professional standard: keep natural vibrato but fix pitch drift
        if (Math.abs(centsDiff) > 5 && vocalPoint.confidence > 0.7) {
            // Don't overcorrect - preserve natural feel
            const correctionStrength = Math.abs(centsDiff) > 30 ? 0.8 : 0.6; // 80% or 60% correction
            const correctedCents = centsDiff * correctionStrength;
            
            corrections.push({
                time: vocalPoint.time,
                originalPitch: vocalPoint.frequency,
                originalNote: vocalPoint.note,
                targetPitch: targetFrequency,
                targetNote: nearestNote.name,
                centsCorrection: correctedCents,
                pitchShiftRatio: Math.pow(2, correctedCents / 1200),
                amplitude: vocalPoint.amplitude,
                confidence: vocalPoint.confidence,
                action: Math.abs(centsDiff) > 50 ? "MAJOR_CORRECTION" : "MINOR_CORRECTION",
                originalCentsOff: centsDiff
            });
            
            totalCorrection += Math.abs(correctedCents);
            correctionCount++;
        }
    }
    
    const avgCorrection = correctionCount > 0 ? totalCorrection / correctionCount : 0;
    
    const script = {
        version: "1.0",
        application: "Melodyne 5 Studio",
        description: "AI-generated pitch correction based on professional standards (no reference track)",
        mode: "PROFESSIONAL_STANDARD",
        statistics: {
            totalPoints: vocalPitchMap.length,
            correctionsNeeded: corrections.length,
            averageCorrection: avgCorrection.toFixed(1) + " cents",
            maxCorrection: corrections.length > 0 ? Math.max(...corrections.map(c => Math.abs(c.centsCorrection))).toFixed(1) + " cents" : "0 cents",
            pitchVariation: vocalAnalysis.pitchVariation.toFixed(1) + " Hz"
        },
        professionalStandard: {
            approach: "Natural pitch correction - preserves vibrato and emotion",
            correctionStrength: "60-80% (not 100% to maintain natural feel)",
            targetAccuracy: "+/- 5 cents from perfect pitch",
            note: "Professional rap vocals are tight but not robotically perfect"
        },
        corrections: corrections,
        instructions: generateMelodyneInstructionsNoRef(corrections, avgCorrection, vocalAnalysis)
    };
    
    console.log(`Generated ${corrections.length} professional pitch corrections (avg: ${avgCorrection.toFixed(1)} cents)`);
    
    return script;
}

// Generate instructions for no-reference Melodyne
function generateMelodyneInstructionsNoRef(corrections, avgCorrection, vocalAnalysis) {
    const severity = vocalAnalysis.pitchVariation > 40 ? "heavy" : vocalAnalysis.pitchVariation > 20 ? "moderate" : "light";
    
    return {
        step1: "Open your vocal in Melodyne 5 Studio",
        step2: `Select '${vocalAnalysis.pitchVariation > 40 ? 'Percussive' : 'Melodic'}' algorithm`,
        step3: "Wait for blob detection to complete",
        step4: "PROFESSIONAL CORRECTION MODE - Not matching a reference, fixing pitch issues",
        step5: `Your vocal needs ${severity} correction (${vocalAnalysis.pitchVariation.toFixed(1)}Hz variation)`,
        step6: `Average correction: ${avgCorrection.toFixed(1)} cents per note`,
        step7: `Total corrections: ${corrections.length} pitch points`,
        
        approach: "Professional Standard Tuning",
        method: severity === "heavy" 
            ? "Use Pitch Macro at 80% correction (preserve 20% natural drift)"
            : "Use Pitch Macro at 60% correction (preserve 40% natural feel)",
        
        quickMethod: `Pitch Macro: Set to ${severity === "heavy" ? '80%' : '60%'} toward nearest note`,
        preciseMethod: "Manually adjust each note using the JSON correction data below",
        
        tips: [
            "Don't aim for 100% perfect pitch - it sounds robotic",
            "Preserve natural vibrato by using lower correction percentages",
            "Focus on fixing pitch drift (long notes that sag flat/sharp)",
            "Keep short notes and transitions more natural",
            "A/B test with bypass to ensure you're improving, not destroying"
        ],
        
        automation: corrections.slice(0, 10).map((c, i) => ({
            point: i + 1,
            time: c.time.toFixed(3) + "s",
            from: c.originalNote,
            to: c.targetNote,
            centsOff: c.originalCentsOff.toFixed(1),
            correctionApplied: c.centsCorrection.toFixed(1)
        }))
    };
}

// Generate human-readable instructions
function generateMelodyneInstructions(corrections, avgCorrection) {
    return {
        step1: "Open your vocal in Melodyne 5 Studio",
        step2: "Select 'Melodic' algorithm (or 'Percussive' for rap)",
        step3: "Wait for blob detection to complete",
        step4: "OPTION A - Use JSON data below to manually correct each note",
        step5: "OPTION B - Use Melodyne's ARA scripting (if supported by your DAW)",
        step6: `Average correction needed: ${avgCorrection.toFixed(1)} cents`,
        step7: `Total corrections: ${corrections.length} pitch points`,
        
        quickMethod: "Use Pitch Macro: Set to " + (avgCorrection > 50 ? "100% correction" : (100 - avgCorrection).toFixed(0) + "% preservation"),
        
        preciseMethod: "Manually adjust each note using the JSON correction data below",
        
        automation: corrections.slice(0, 10).map((c, i) => ({
            point: i + 1,
            time: c.time.toFixed(3) + "s",
            from: c.originalNote,
            to: c.targetNote,
            cents: c.centsCorrection.toFixed(1)
        }))
    };
}

// Show Melodyne instructions modal
function showMelodyneInstructions(script) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.95);
        z-index: 10000;
        overflow-y: auto;
        padding: 40px;
        display: flex;
        justify-content: center;
        align-items: flex-start;
    `;
    
    modal.innerHTML = `
        <div style="background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); border: 2px solid #00ff88; border-radius: 15px; padding: 40px; max-width: 900px; width: 100%;">
            <h2 style="color: #00ff88; margin: 0 0 20px 0; text-align: center;">🎵 Melodyne Auto-Correction Ready!</h2>
            
            <div style="background: rgba(0, 255, 136, 0.1); padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                <h3 style="color: #00d4ff; margin: 0 0 15px 0;">📊 Analysis Results:</h3>
                <div style="color: #fff; line-height: 1.8;">
                    <strong>Total Pitch Points:</strong> ${script.statistics.totalPoints}<br>
                    <strong>Corrections Needed:</strong> ${script.statistics.correctionsNeeded}<br>
                    <strong>Average Correction:</strong> ${script.statistics.averageCorrection}<br>
                    <strong>Max Correction:</strong> ${script.statistics.maxCorrection}
                </div>
            </div>
            
            <div style="background: rgba(255, 170, 0, 0.1); padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                <h3 style="color: #ffaa00; margin: 0 0 15px 0;">🎯 How To Use:</h3>
                <ol style="color: #fff; line-height: 2; margin: 0; padding-left: 20px;">
                    <li>Open your vocal track in <strong>Melodyne 5 Studio</strong></li>
                    <li>Select algorithm: <strong>Melodic</strong> (or Percussive for rap)</li>
                    <li>Wait for blob detection</li>
                    <li><strong>OPTION A:</strong> Use JSON file to manually correct (most precise)</li>
                    <li><strong>OPTION B:</strong> Use Pitch Macro at ${parseFloat(script.statistics.averageCorrection) > 50 ? '100%' : '70%'} correction</li>
                </ol>
            </div>
            
            <div style="background: rgba(0, 212, 255, 0.1); padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                <h3 style="color: #00d4ff; margin: 0 0 15px 0;">📝 Sample Corrections (First 10):</h3>
                <div style="font-family: monospace; font-size: 0.9em; color: #fff; line-height: 1.6;">
                    ${script.instructions.automation.map(a => 
                        `<div>${a.point}. Time: ${a.time} | ${a.from} → ${a.to} | ${a.cents} cents</div>`
                    ).join('')}
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <button onclick="this.parentElement.parentElement.parentElement.remove()" style="background: linear-gradient(45deg, #00ff88, #00d4ff); color: #000; border: none; padding: 15px 40px; font-size: 1.1em; font-weight: bold; border-radius: 8px; cursor: pointer;">
                    Got It! Close
                </button>
            </div>
            
            <div style="margin-top: 20px; padding: 15px; background: rgba(123, 47, 247, 0.1); border-radius: 8px; text-align: center; color: #aaa; font-size: 0.9em;">
                💡 The JSON file contains ALL ${script.corrections.length} corrections with exact pitch values
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// ============================================================================
// INTELLIGENT AI CHAIN BUILDER
// Analyzes vocal vs reference and builds optimal plugin chain
// ============================================================================

// Convert AI chain to Studio One FX Chain XML format
function convertToStudioOneFXChain(aiChain) {
    let xml = `<?xml version="1.0" encoding="UTF-8"?>
<AudioPluginChain version="1" name="${aiChain.name}" description="${aiChain.description}">
    <MetaData>
        <Generator>AI Vocal Plugin Analyzer v${aiChain.version}</Generator>
        <Created>${new Date().toISOString()}</Created>
        <TotalPlugins>${aiChain.plugins.length}</TotalPlugins>
        <Description>${escapeXml(aiChain.description)}</Description>
    </MetaData>
    
    <AnalysisReport>`;
    
    // Add analysis stats
    if (aiChain.analysisReport) {
        xml += `
        <VocalStats>
            <PitchVariation>${aiChain.analysisReport.vocalStats.pitchVariation}</PitchVariation>
            <CrestFactor>${aiChain.analysisReport.vocalStats.crestFactor}</CrestFactor>
            <RMS>${aiChain.analysisReport.vocalStats.rms}</RMS>
            <Sibilance>${aiChain.analysisReport.vocalStats.sibilance}</Sibilance>
        </VocalStats>`;
        
        if (aiChain.analysisReport.referenceStats) {
            xml += `
        <ReferenceStats>
            <PitchVariation>${aiChain.analysisReport.referenceStats.pitchVariation}</PitchVariation>
            <CrestFactor>${aiChain.analysisReport.referenceStats.crestFactor}</CrestFactor>
            <RMS>${aiChain.analysisReport.referenceStats.rms}</RMS>
            <Sibilance>${aiChain.analysisReport.referenceStats.sibilance}</Sibilance>
        </ReferenceStats>`;
        }
        
        if (aiChain.analysisReport.note) {
            xml += `
        <Note>${escapeXml(aiChain.analysisReport.note)}</Note>`;
        }
    }
    
    xml += `
    </AnalysisReport>
    
    <Plugins>`;
    
    // Add each plugin
    aiChain.plugins.forEach((plugin, index) => {
        xml += `
        <Plugin slot="${index + 1}">
            <Name>${escapeXml(plugin.name)}</Name>
            <PluginId>${escapeXml(plugin.pluginId || 'unknown')}</PluginId>
            <Category>${escapeXml(plugin.category)}</Category>
            <Reason>${escapeXml(plugin.reason)}</Reason>
            <Bypass>${plugin.bypass || false}</Bypass>`;
        
        // Add parameters
        if (plugin.parameters) {
            xml += `
            <Parameters>`;
            
            Object.entries(plugin.parameters).forEach(([key, value]) => {
                if (typeof value === 'object' && !Array.isArray(value)) {
                    // Nested parameter object (like EQ bands)
                    xml += `
                <Parameter name="${escapeXml(key)}">`;
                    Object.entries(value).forEach(([subKey, subValue]) => {
                        xml += `
                    <${escapeXml(subKey)}>${escapeXml(String(subValue))}</${escapeXml(subKey)}>`;
                    });
                    xml += `
                </Parameter>`;
                } else if (Array.isArray(value)) {
                    // Array of values (like EQ bands)
                    xml += `
                <Parameter name="${escapeXml(key)}" type="array">`;
                    value.forEach((item, i) => {
                        if (typeof item === 'object') {
                            xml += `
                    <Item index="${i}">`;
                            Object.entries(item).forEach(([itemKey, itemValue]) => {
                                xml += `
                        <${escapeXml(itemKey)}>${escapeXml(String(itemValue))}</${escapeXml(itemKey)}>`;
                            });
                            xml += `
                    </Item>`;
                        } else {
                            xml += `
                    <Item index="${i}">${escapeXml(String(item))}</Item>`;
                        }
                    });
                    xml += `
                </Parameter>`;
                } else {
                    // Simple parameter
                    xml += `
                <Parameter name="${escapeXml(key)}" value="${escapeXml(String(value))}" />`;
                }
            });
            
            xml += `
            </Parameters>`;
        }
        
        xml += `
        </Plugin>`;
    });
    
    xml += `
    </Plugins>
    
    <Instructions>
        <Step>1. In Studio One, go to Effects → FX Chains → Import</Step>
        <Step>2. Select this .fxchain file</Step>
        <Step>3. The entire ${aiChain.plugins.length}-plugin chain will load on your track</Step>
        <Step>4. All parameters are pre-configured based on AI analysis</Step>
        <Step>5. Fine-tune individual plugins as needed</Step>
        <Step>6. Bypass any plugin you don't want to use</Step>
    </Instructions>
    
</AudioPluginChain>`;
    
    return xml;
}

// Helper: Escape XML special characters
function escapeXml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

// Convert AI chain to Apple AudioUnit Preset format (.aupreset) for Logic Pro
function convertToAUPreset(aiChain) {
    // Create Waves StudioVerse preset XML data
    const presetName = aiChain.name.substring(0, 50); // Limit name length
    const pluginCount = aiChain.plugins.length;
    
    // Build the internal preset XML (this will be base64 encoded)
    let presetXML = `<PresetChunkXMLTree version="3">
 <Preset Name="${escapeXml(presetName)}" GenericType="WSCR">
  <PresetHeader>
   <Group></Group>
   <PluginName>StudioVerse Audio Effects</PluginName>
   <PluginSubComp>WRHM</PluginSubComp>
   <PluginVersion>16.0.30.31</PluginVersion>
   <ActiveSetup>SETUP_A</ActiveSetup>
   <LoadMenuCategory>User</LoadMenuCategory>
   <ReadOnly>false</ReadOnly>
  </PresetHeader>
  <VST24SideChainActive>true</VST24SideChainActive>
  <PresetData Setup="SETUP_A" SetupName="${escapeXml(presetName)}">
   <Parameters Type="RealWorld">
`;

    // Add plugin chain data as parameters
    // Format: space-separated numbers representing plugin slots and settings
    presetXML += ` ${pluginCount}`;
    
    // Add basic parameters for each plugin slot
    aiChain.plugins.forEach((plugin, idx) => {
        presetXML += ` ${idx}`;
    });
    
    presetXML += `
   </Parameters>
   <PluginSpecificXMLData>
    <PresetID>${generateUUID()}</PresetID>
    <ChainInfo>
     <TotalPlugins>${pluginCount}</TotalPlugins>
     <ChainDescription>${escapeXml(aiChain.description)}</ChainDescription>
    </ChainInfo>
`;

    // Add each plugin's information
    aiChain.plugins.forEach((plugin, idx) => {
        presetXML += `    <Plugin slot="${idx}">
     <Name>${escapeXml(plugin.name)}</Name>
     <Category>${escapeXml(plugin.category)}</Category>
     <Purpose>${escapeXml(plugin.reason)}</Purpose>
    </Plugin>
`;
    });

    presetXML += `   </PluginSpecificXMLData>
  </PresetData>
 </Preset>
</PresetChunkXMLTree>`;

    // Base64 encode the preset XML
    const base64Data = btoa(presetXML);
    
    // Create the .aupreset plist structure
    const auPreset = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
\t<key>Waves_XPst</key>
\t<data>
\t${base64Data}
\t</data>
\t<key>element-name</key>
\t<dict>
\t\t<key>1</key>
\t\t<dict>
\t\t\t<key>0</key>
\t\t\t<string>Main Input Bus</string>
\t\t\t<key>1</key>
\t\t\t<string>Side-Chain Input Bus</string>
\t\t</dict>
\t\t<key>2</key>
\t\t<dict>
\t\t\t<key>0</key>
\t\t\t<string>Main Output Bus</string>
\t\t</dict>
\t</dict>
\t<key>manufacturer</key>
\t<integer>1802721110</integer>
\t<key>name</key>
\t<string>${escapeXml(presetName)}</string>
\t<key>subtype</key>
\t<integer>1465010253</integer>
\t<key>type</key>
\t<integer>1635085670</integer>
\t<key>version</key>
\t<integer>0</integer>
</dict>
</plist>`;

    return auPreset;
}

// Generate a UUID for preset identification
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Convert AI chain to readable Waves Plugin Chain text format
function convertToWavesChainList(aiChain) {
    let text = `═══════════════════════════════════════════════════════════════
                 WAVES PLUGIN CHAIN
        ${aiChain.name}
═══════════════════════════════════════════════════════════════

Generated by: AI Vocal Plugin Analyzer v${aiChain.version}
Date: ${new Date().toISOString().split('T')[0]}
Total Plugins: ${aiChain.plugins.length}

Description:
${aiChain.description}

`;

    // Add analysis report if available
    if (aiChain.analysisReport && aiChain.analysisReport.vocalStats) {
        text += `
═══════════════════════════════════════════════════════════════
                    ANALYSIS REPORT
═══════════════════════════════════════════════════════════════

VOCAL STATISTICS:
  • Pitch Variation: ${aiChain.analysisReport.vocalStats.pitchVariation}
  • Dynamics (Crest Factor): ${aiChain.analysisReport.vocalStats.crestFactor}
  • RMS Level: ${aiChain.analysisReport.vocalStats.rms}
  • Sibilance: ${aiChain.analysisReport.vocalStats.sibilance}
`;

        if (aiChain.analysisReport.referenceStats) {
            text += `
REFERENCE STATISTICS:
  • Pitch Variation: ${aiChain.analysisReport.referenceStats.pitchVariation}
  • Dynamics (Crest Factor): ${aiChain.analysisReport.referenceStats.crestFactor}
  • RMS Level: ${aiChain.analysisReport.referenceStats.rms}
  • Sibilance: ${aiChain.analysisReport.referenceStats.sibilance}
`;
        }
    }

    text += `
═══════════════════════════════════════════════════════════════
              COMPLETE PLUGIN CHAIN (${aiChain.plugins.length} PLUGINS)
═══════════════════════════════════════════════════════════════

Load these plugins in order on your vocal track:

`;

    // List each plugin with full details
    aiChain.plugins.forEach((plugin, index) => {
        text += `
┌─────────────────────────────────────────────────────────────┐
│ PLUGIN ${index + 1}: ${plugin.name}
├─────────────────────────────────────────────────────────────┤
│ Category: ${plugin.category}
│ Purpose: ${plugin.reason}
│
│ SETTINGS:
`;

        // Add parameters
        if (plugin.parameters && Object.keys(plugin.parameters).length > 0) {
            Object.entries(plugin.parameters).forEach(([key, value]) => {
                if (typeof value === 'object' && !Array.isArray(value)) {
                    text += `│   ${key}:\n`;
                    Object.entries(value).forEach(([subKey, subValue]) => {
                        text += `│     - ${subKey}: ${subValue}\n`;
                    });
                } else if (Array.isArray(value)) {
                    text += `│   ${key}:\n`;
                    value.forEach((item, i) => {
                        if (typeof item === 'object') {
                            text += `│     [${i}]:\n`;
                            Object.entries(item).forEach(([itemKey, itemValue]) => {
                                text += `│       - ${itemKey}: ${itemValue}\n`;
                            });
                        } else {
                            text += `│     [${i}]: ${item}\n`;
                        }
                    });
                } else {
                    text += `│   ${key}: ${value}\n`;
                }
            });
        } else {
            text += `│   (Default settings)\n`;
        }

        text += `└─────────────────────────────────────────────────────────────┘
`;
    });

    text += `
═══════════════════════════════════════════════════════════════
                   HOW TO USE THIS CHAIN
═══════════════════════════════════════════════════════════════

LOAD PLUGINS: Open your DAW → Load each plugin in order above
COPY SETTINGS: Match the parameter values for each plugin
FINE-TUNE: Adjust to taste, A/B test, trust your ears!

═══════════════════════════════════════════════════════════════
`;

    return text;
}

// Convert AI chain to HTML report for easy viewing and reference
function convertToHTMLReport(aiChain) {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${aiChain.name} - AI Vocal Chain</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #e0e0e0;
            padding: 20px;
            line-height: 1.6;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 40px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .header h1 { font-size: 2.5em; margin-bottom: 10px; color: white; }
        .header p { font-size: 1.2em; color: rgba(255,255,255,0.9); }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: rgba(255,255,255,0.05);
            padding: 20px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .stat-card h3 { color: #667eea; font-size: 0.9em; margin-bottom: 10px; }
        .stat-card p { font-size: 1.5em; font-weight: bold; }
        .plugin {
            background: rgba(255,255,255,0.05);
            border: 2px solid rgba(102, 126, 234, 0.3);
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        .plugin:hover {
            border-color: #667eea;
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.2);
        }
        .plugin-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
        }
        .plugin-number {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2em;
        }
        .plugin-name { font-size: 1.5em; color: white; flex: 1; }
        .plugin-category {
            background: rgba(102, 126, 234, 0.2);
            color: #667eea;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9em;
        }
        .plugin-purpose {
            background: rgba(255,255,255,0.03);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 3px solid #667eea;
        }
        .parameters {
            background: rgba(0,0,0,0.2);
            padding: 15px;
            border-radius: 8px;
        }
        .parameters h4 {
            color: #667eea;
            margin-bottom: 10px;
            font-size: 1.1em;
        }
        .param-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
        }
        .param {
            background: rgba(255,255,255,0.05);
            padding: 10px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
        }
        .param-name { color: #aaa; }
        .param-value { color: white; font-weight: bold; }
        .instructions {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            padding: 30px;
            border-radius: 15px;
            margin-top: 30px;
            color: white;
        }
        .instructions h2 { margin-bottom: 15px; }
        .instructions ol { margin-left: 20px; margin-top: 15px; }
        .instructions li { margin-bottom: 10px; font-size: 1.1em; }
        @media print {
            body { background: white; color: black; }
            .plugin { border-color: #333; page-break-inside: avoid; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎤 ${aiChain.name}</h1>
            <p>${aiChain.description}</p>
        </div>

        ${aiChain.analysisReport ? `
        <div class="stats">
            <div class="stat-card">
                <h3>VOCAL PITCH</h3>
                <p>${aiChain.analysisReport.vocalStats.pitchVariation}</p>
            </div>
            <div class="stat-card">
                <h3>DYNAMICS</h3>
                <p>${aiChain.analysisReport.vocalStats.crestFactor}</p>
            </div>
            <div class="stat-card">
                <h3>TOTAL PLUGINS</h3>
                <p>${aiChain.plugins.length}</p>
            </div>
            ${aiChain.analysisReport.referenceStats ? `
            <div class="stat-card">
                <h3>TARGET PITCH</h3>
                <p>${aiChain.analysisReport.referenceStats.pitchVariation}</p>
            </div>
            ` : ''}
        </div>
        ` : ''}

        <h2 style="color: white; margin-bottom: 20px; font-size: 2em;">Plugin Chain (${aiChain.plugins.length} Plugins)</h2>

        ${aiChain.plugins.map((plugin, idx) => `
        <div class="plugin">
            <div class="plugin-header">
                <div class="plugin-number">${idx + 1}</div>
                <div class="plugin-name">${plugin.name}</div>
                <div class="plugin-category">${plugin.category}</div>
            </div>
            
            <div class="plugin-purpose">
                <strong>Purpose:</strong> ${plugin.reason}
            </div>

            ${plugin.parameters && Object.keys(plugin.parameters).length > 0 ? `
            <div class="parameters">
                <h4>⚙️ Settings</h4>
                <div class="param-grid">
                    ${Object.entries(plugin.parameters).map(([key, value]) => {
                        if (typeof value === 'object' && !Array.isArray(value)) {
                            return Object.entries(value).map(([k, v]) => 
                                `<div class="param"><span class="param-name">${key} ${k}:</span><span class="param-value">${v}</span></div>`
                            ).join('');
                        } else if (Array.isArray(value)) {
                            return value.map((item, i) => 
                                typeof item === 'object' 
                                    ? Object.entries(item).map(([k, v]) => 
                                        `<div class="param"><span class="param-name">${key}[${i}] ${k}:</span><span class="param-value">${v}</span></div>`
                                    ).join('')
                                    : `<div class="param"><span class="param-name">${key}[${i}]:</span><span class="param-value">${item}</span></div>`
                            ).join('');
                        } else {
                            return `<div class="param"><span class="param-name">${key}:</span><span class="param-value">${value}</span></div>`;
                        }
                    }).join('')}
                </div>
            </div>
            ` : ''}
        </div>
        `).join('')}

        <div class="instructions">
            <h2>📋 How To Use This Chain</h2>
            <ol>
                <li><strong>Open Logic Pro</strong> and load your vocal track</li>
                <li><strong>Load each plugin above</strong> in order on your track</li>
                <li><strong>Copy the settings</strong> from each plugin's parameters section</li>
                <li><strong>Fine-tune by ear</strong> - these are starting points!</li>
                <li><strong>Save as preset</strong> in StudioVerse once configured</li>
            </ol>
            <p style="margin-top: 20px; font-size: 0.9em; opacity: 0.9;">
                💡 <strong>Tip:</strong> Print this page or keep it open while mixing. Work in phases: pitch → EQ → compression → effects.
            </p>
        </div>
    </div>
</body>
</html>`;
}

function buildIntelligentChain(vocal, reference, settings) {
    console.log('=== AI CHAIN BUILDER STARTING ===');
    
    // If no reference, use professional standards
    if (!reference) {
        console.log('NO REFERENCE MODE: Building chain based on professional standards');
        
        // Create professional standard "reference"
        const professionalStandard = {
            pitchVariation: 15,
            crestFactor: 6,
            rms: 0.08,
            sibilance: 0.010,
            bass: 0.015,
            lowMids: 0.018,
            mids: 0.020,
            highMids: 0.015,
            presence: 0.012,
            brilliance: 0.010,
            air: 0.008,
            transientStrength: 0.008,
            spectralCentroid: 2500, // Balanced brightness
            harmonicContent: 0.015
        };
        
        const chain = {
            name: "AI Professional Standard Vocal Chain",
            description: "Chain built to meet professional industry standards (no reference track used)",
            version: "3.0-PRO-STANDARD",
            analysisReport: generateAnalysisReport(vocal, null),
            plugins: []
        };
        
        // Calculate differences from professional standard
        const differences = calculateDifferences(vocal, professionalStandard);
        console.log('Differences from pro standard:', differences);
        
        // Build COMPREHENSIVE chain - ALL phases, no skipping
        console.log('Building comprehensive chain with ALL necessary plugins...');
        
        // PHASE 1: PITCH CORRECTION - Always check and add if any pitch issues
        console.log('Phase 1: Pitch Correction');
        chain.plugins.push(...buildPitchCorrectionChain(vocal, professionalStandard, differences));
        
        // PHASE 2: TIMING/FORMANT - Always check
        console.log('Phase 2: Formant/Timing');
        chain.plugins.push(...buildFormantTimingChain(vocal, professionalStandard, differences));
        
        // PHASE 3: TONE SHAPING - Always needed
        console.log('Phase 3: Tone Shaping (EQ)');
        chain.plugins.push(...buildToneShapingChain(vocal, professionalStandard, differences));
        
        // PHASE 4: DYNAMICS CONTROL - Always needed
        console.log('Phase 4: Dynamics Control');
        chain.plugins.push(...buildDynamicsChain(vocal, professionalStandard, differences));
        
        // PHASE 5: PROBLEM SOLVING - Always check for sibilance, harshness
        console.log('Phase 5: Problem Solving');
        chain.plugins.push(...buildProblemSolvingChain(vocal, professionalStandard, differences));
        
        // PHASE 6: CHARACTER & COLOR - Always check
        console.log('Phase 6: Character & Color');
        chain.plugins.push(...buildCharacterChain(vocal, professionalStandard, differences));
        
        // PHASE 7: SPATIAL EFFECTS - Always add
        console.log('Phase 7: Spatial Effects');
        chain.plugins.push(...buildSpatialChain(vocal, professionalStandard, differences));
        
        // PHASE 8: FINAL POLISH - Always check
        console.log('Phase 8: Final Polish');
        chain.plugins.push(...buildFinalPolishChain(vocal, professionalStandard, differences));
        
        console.log(`=== AI BUILT ${chain.plugins.length}-PLUGIN COMPREHENSIVE PROFESSIONAL CHAIN ===`);
        chain.plugins.forEach((p, i) => console.log(`${i + 1}. ${p.name} (${p.category})`));
        return chain;
    }
    
    // Original reference-based logic
    console.log('TRANSFORMATIVE MODE: Building chain to COMPLETELY match reference');
    console.log('Analyzing differences between vocal and reference...');
    
    const chain = {
        name: "AI TRANSFORMATIVE Vocal Chain",
        description: `EXTREME transformation chain - ${referenceAnalyses.length > 0 ? referenceAnalyses.length + 1 : 1} reference(s) analyzed - Will completely change your vocal to match reference`,
        version: "3.0-EXTREME",
        analysisReport: generateAnalysisReport(vocal, reference),
        plugins: []
    };
    
    // Calculate exact differences
    const differences = calculateDifferences(vocal, reference);
    console.log('Differences calculated:', differences);
    
    // Build COMPREHENSIVE chain - ALL phases, maximum transformation
    console.log('Building comprehensive transformation chain with ALL necessary plugins...');
    
    // PHASE 1: PITCH CORRECTION - Always check
    console.log('Phase 1: Pitch Correction');
    chain.plugins.push(...buildPitchCorrectionChain(vocal, reference, differences));
    
    // PHASE 2: TIMING/FORMANT - Always check
    console.log('Phase 2: Formant/Timing');
    chain.plugins.push(...buildFormantTimingChain(vocal, reference, differences));
    
    // PHASE 3: TONE SHAPING - Always needed
    console.log('Phase 3: Tone Shaping (EQ)');
    chain.plugins.push(...buildToneShapingChain(vocal, reference, differences));
    
    // PHASE 4: DYNAMICS CONTROL - Always needed
    console.log('Phase 4: Dynamics Control');
    chain.plugins.push(...buildDynamicsChain(vocal, reference, differences));
    
    // PHASE 5: PROBLEM SOLVING - Always check
    console.log('Phase 5: Problem Solving');
    chain.plugins.push(...buildProblemSolvingChain(vocal, reference, differences));
    
    // PHASE 6: CHARACTER & COLOR - Always check
    console.log('Phase 6: Character & Color');
    chain.plugins.push(...buildCharacterChain(vocal, reference, differences));
    
    // PHASE 7: SPATIAL EFFECTS - Always add
    console.log('Phase 7: Spatial Effects');
    chain.plugins.push(...buildSpatialChain(vocal, reference, differences));
    
    // PHASE 8: FINAL POLISH - Always check
    console.log('Phase 8: Final Polish');
    chain.plugins.push(...buildFinalPolishChain(vocal, reference, differences));
    
    console.log(`=== AI BUILT ${chain.plugins.length}-PLUGIN COMPREHENSIVE TRANSFORMATION CHAIN ===`);
    chain.plugins.forEach((p, i) => console.log(`${i + 1}. ${p.name} (${p.category})`));
    
    return chain;
}

// Calculate all differences between vocal and reference
function calculateDifferences(vocal, reference) {
    const diffs = {
        // EXTREME PITCH TRANSFORMATION
        pitchVariationDiff: Math.abs(vocal.pitchVariation - reference.pitchVariation),
        pitchIssues: vocal.pitchVariation !== reference.pitchVariation, // ANY difference needs correction
        needsHeavyTuning: Math.abs(vocal.pitchVariation - reference.pitchVariation) > 5, // Very sensitive
        needsMelodyne: Math.abs(vocal.pitchVariation - reference.pitchVariation) > 10,
        needsFormantShift: true, // ALWAYS adjust formant to match reference character
        
        // EXTREME FORMANT/TIMBRE TRANSFORMATION
        formantIssues: true, // Always shift formant to match reference
        needsVocalSynth: Math.abs(vocal.spectralCentroid - reference.spectralCentroid) > 100, // Voice morphing
        
        // Timing
        timingIssues: Math.abs(vocal.transientStrength - reference.transientStrength) > 0.005,
        
        // EXTREME FREQUENCY TRANSFORMATION - Force EXACT match
        subBassDiff: reference.subBass - vocal.subBass,
        bassDiff: reference.bass - vocal.bass,
        lowMidsDiff: reference.lowMids - vocal.lowMids,
        midsDiff: reference.mids - vocal.mids,
        highMidsDiff: reference.highMids - vocal.highMids,
        presenceDiff: reference.presence - vocal.presence,
        brillianceDiff: reference.brilliance - vocal.brilliance,
        airDiff: reference.air - vocal.air,
        
        // ANY frequency difference needs correction (not just large ones)
        needsSubBassBoost: reference.subBass > vocal.subBass * 1.01,
        needsBassBoost: reference.bass > vocal.bass * 1.01,
        needsLowMidsBoost: reference.lowMids > vocal.lowMids * 1.01,
        needsMidsBoost: reference.mids > vocal.mids * 1.01,
        needsHighMidsBoost: reference.highMids > vocal.highMids * 1.01,
        needsPresenceBoost: reference.presence > vocal.presence * 1.01,
        needsBrillianceBoost: reference.brilliance > vocal.brilliance * 1.01,
        needsAirBoost: reference.air > vocal.air * 1.01,
        
        needsSubBassCut: reference.subBass < vocal.subBass * 0.99,
        needsBassCut: reference.bass < vocal.bass * 0.99,
        needsLowMidsCut: reference.lowMids < vocal.lowMids * 0.99,
        needsMidsCut: reference.mids < vocal.mids * 0.99,
        needsHighMidsCut: reference.highMids < vocal.highMids * 0.99,
        needsPresenceCut: reference.presence < vocal.presence * 0.99,
        needsBrillianceCut: reference.brilliance < vocal.brilliance * 0.99,
        needsAirCut: reference.air < vocal.air * 0.99,
        
        // EXTREME DYNAMICS TRANSFORMATION
        crestDiff: vocal.crestFactor - reference.crestFactor,
        needsHeavyCompression: true, // ALWAYS compress aggressively
        needsParallelCompression: Math.abs(vocal.crestFactor - reference.crestFactor) > 2,
        needsMultibandComp: true, // ALWAYS use multiband for precise control
        needsUpwardCompression: reference.rms > vocal.rms * 1.1, // Bring up quiet parts
        
        // EXTREME SIBILANCE CONTROL
        sibilanceDiff: vocal.sibilance - reference.sibilance,
        sibilanceIssue: Math.abs(vocal.sibilance - reference.sibilance) > 0.001, // Very sensitive
        needsMultipleDeessers: Math.abs(vocal.sibilance - reference.sibilance) > 0.003,
        needsSpectralDeess: Math.abs(vocal.sibilance - reference.sibilance) > 0.005,
        
        // EXTREME HARSH FREQUENCY CORRECTION
        harshFrequencies: detectHarshFrequencies(vocal, reference),
        needsDynamicEQ: true, // ALWAYS use dynamic EQ for precise control
        
        // EXTREME TONAL TRANSFORMATION
        needsWarmth: reference.bass + reference.lowMids > vocal.bass + vocal.lowMids,
        needsBrightness: reference.brilliance + reference.air > vocal.brilliance + vocal.air,
        needsPresence: reference.presence > vocal.presence,
        needsAir: reference.air > vocal.air,
        needsDarkening: reference.brilliance + reference.air < vocal.brilliance + vocal.air,
        
        // EXTREME HARMONIC TRANSFORMATION
        needsHarmonics: true, // ALWAYS add/shape harmonics
        needsTapeWarmth: reference.bass > vocal.bass || reference.lowMids > vocal.lowMids,
        needsTubeWarmth: reference.lowMids > vocal.lowMids || reference.mids > vocal.mids,
        needsTransformer: reference.presence > vocal.presence, // Add transformer coloration
        needsDistortion: reference.harmonicContent > vocal.harmonicContent * 1.1, // Add controlled distortion
        
        // VOICE CHARACTER TRANSFORMATION
        needsVocalDoubler: reference.channels > 1 || reference.stereoWidth > vocal.stereoWidth,
        needsVocalRider: true, // ALWAYS use vocal rider for consistency
        needsBreathControl: true, // Remove/add breaths to match reference
        
        // EXTREME SPATIAL TRANSFORMATION
        needsReverb: true, // ALWAYS match reverb exactly
        needsDelay: true, // ALWAYS match delay exactly
        needsStereoWidth: true, // ALWAYS match stereo width
        
        // FINAL TRANSFORMATION
        needsFinalLimiting: true, // ALWAYS limit to exact loudness
        needsExciter: Math.abs(reference.presence - vocal.presence) > 0.002,
        needsVintageProcessor: reference.harmonicContent > vocal.harmonicContent,
        needsTransientDesigner: Math.abs(vocal.transientStrength - reference.transientStrength) > 0.003
    };
    
    return diffs;
}

// Detect ALL frequency differences (not just harsh ones)
function detectHarshFrequencies(vocal, reference) {
    const issues = [];
    
    // Check EVERY frequency band for ANY mismatch
    const bands = [
        { name: 'Sub-bass', freq: 50, vocalVal: vocal.subBass, refVal: reference.subBass },
        { name: 'Bass', freq: 150, vocalVal: vocal.bass, refVal: reference.bass },
        { name: 'Low-mids', freq: 350, vocalVal: vocal.lowMids, refVal: reference.lowMids },
        { name: 'Mids', freq: 1000, vocalVal: vocal.mids, refVal: reference.mids },
        { name: 'High-mids', freq: 3000, vocalVal: vocal.highMids, refVal: reference.highMids },
        { name: 'Presence', freq: 5000, vocalVal: vocal.presence, refVal: reference.presence },
        { name: 'Brilliance', freq: 8000, vocalVal: vocal.brilliance, refVal: reference.brilliance },
        { name: 'Air', freq: 14000, vocalVal: vocal.air, refVal: reference.air }
    ];
    
    bands.forEach(band => {
        const ratio = band.vocalVal / (band.refVal + 0.0001);
        if (ratio > 1.05 || ratio < 0.95) { // ANY 5% difference
            issues.push({
                name: band.name,
                freq: band.freq,
                severity: Math.abs(ratio - 1) * 100,
                needsCut: ratio > 1,
                needsBoost: ratio < 1,
                amount: band.refVal - band.vocalVal
            });
        }
    });
    
    return issues.sort((a, b) => b.severity - a.severity);
}

// PHASE 1: Pitch Correction Chain
function buildPitchCorrectionChain(vocal, reference, diffs) {
    const plugins = [];
    
    // Use Melodyne for heavy issues
    if (diffs.needsMelodyne) {
        plugins.push({
            name: "Melodyne 5 Studio",
            pluginId: "celemony.melodyne.studio",
            category: "Pitch Correction",
            reason: `Severe pitch issues detected (${vocal.pitchVariation.toFixed(1)}Hz variation vs ${reference.pitchVariation.toFixed(1)}Hz target)`,
            bypass: false,
            parameters: {
                algorithm: vocal.pitchVariation > 40 ? "Percussive" : "Melodic",
                pitchCorrection: "Heavy",
                pitchModulation: diffs.needsHeavyTuning ? 20 : 40,
                driftCorrection: true,
                vibratoIntensity: 30,
                formantCorrection: diffs.formantIssues
            }
        });
    }
    
    // Always use Waves Tune Real-Time or Auto-Tune
    const tuneSpeed = diffs.needsHeavyTuning ? 10 : (diffs.pitchIssues ? 25 : 40);
    const tuneNote = diffs.needsHeavyTuning ? 100 : 85;
    
    plugins.push({
        name: "Waves Tune Real-Time",
        pluginId: "waves.tune.realtime",
        category: "Pitch Correction",
        reason: `Pitch stabilization needed (Speed: ${tuneSpeed}ms for ${diffs.needsHeavyTuning ? 'heavy' : diffs.pitchIssues ? 'moderate' : 'light'} correction)`,
        bypass: false,
        parameters: {
            speed: tuneSpeed,
            note: tuneNote,
            cents: 50,
            transition: diffs.needsHeavyTuning ? 150 : 200,
            scale: "Chromatic",
            formant: false
        }
    });
    
    return plugins;
}

// PHASE 2: EXTREME Formant/Timing/Voice Character Chain
function buildFormantTimingChain(vocal, reference, diffs) {
    const plugins = [];
    
    // ALWAYS adjust formant to match reference character
    const formantShift = (reference.spectralCentroid - vocal.spectralCentroid) / 100;
    
    plugins.push({
        name: "Little AlterBoy",
        pluginId: "soundtoys.alterboy",
        category: "Formant Transformation",
        reason: `Transform voice character (${Math.abs(vocal.spectralCentroid - reference.spectralCentroid).toFixed(0)}Hz formant shift needed)`,
        bypass: false,
        parameters: {
            formant: Math.max(-2, Math.min(2, formantShift)), // AGGRESSIVE formant shift
            pitch: 0,
            mix: 70, // High mix for transformation
            mode: "Transpose"
        }
    });
    
    // Add vocal synth if EXTREME transformation needed
    if (diffs.needsVocalSynth) {
        plugins.push({
            name: "iZotope VocalSynth 2",
            pluginId: "izotope.vocalsynth2",
            category: "Voice Morphing",
            reason: "EXTREME voice character transformation needed",
            bypass: false,
            parameters: {
                vocode: 40,
                compuvox: 30,
                polyvox: 20,
                mix: 50 // Blend morphed with original
            }
        });
    }
    
    // Add breath control
    plugins.push({
        name: "Waves DeBreath",
        pluginId: "waves.debreath",
        category: "Breath Control",
        reason: "Remove/control breaths to match reference",
        bypass: false,
        parameters: {
            sensitivity: 70,
            reduction: -12
        }
    });
    
    return plugins;
}

// PHASE 3: EXTREME Tone Shaping (EQ Chain)
function buildToneShapingChain(vocal, reference, diffs) {
    const plugins = [];
    
    // ALWAYS use subtractive EQ - cut EVERYTHING that's wrong
    plugins.push({
        name: "FabFilter Pro-Q 3",
        pluginId: "fabfilter.proq3",
        category: "Surgical Subtractive EQ",
        reason: `Remove ALL problem frequencies (${diffs.harshFrequencies.length} bands need correction)`,
        bypass: false,
        mode: "Zero Latency",
        parameters: {
            bands: buildAggressiveSubtractiveEQBands(vocal, reference, diffs)
        }
    });
    
    // ALWAYS use additive EQ - shape tone to EXACT reference
    plugins.push({
        name: diffs.needsWarmth ? "Waves API 550" : "Waves Renaissance EQ",
        pluginId: diffs.needsWarmth ? "waves.api550" : "waves.req",
        category: "Additive EQ (Transformation)",
        reason: "Transform frequency spectrum to MATCH reference exactly",
        bypass: false,
        parameters: {
            bands: buildAggressiveAdditiveEQBands(vocal, reference, diffs)
        }
    });
    
    // ALWAYS use dynamic EQ for precise frequency control
    plugins.push({
        name: "FabFilter Pro-Q 3",
        pluginId: "fabfilter.proq3",
        category: "Dynamic EQ (Adaptive Control)",
        reason: "Control frequency balance dynamically across performance",
        bypass: false,
        mode: "Dynamic",
        parameters: {
            bands: buildExtremeDynamicEQBands(vocal, reference, diffs)
        }
    });
    
    // Add match EQ if available (spectral matching)
    plugins.push({
        name: "iZotope Ozone EQ Match",
        pluginId: "izotope.ozone.eqmatch",
        category: "Spectral Matching",
        reason: "AI-powered spectral matching to reference",
        bypass: false,
        parameters: {
            learn: "reference_spectrum",
            amount: 80 // Aggressive matching
        }
    });
    
    return plugins;
}

// PHASE 4: Dynamics Chain
function buildDynamicsChain(vocal, reference, diffs) {
    const plugins = [];
    
    // Parallel compression for heavy dynamics
    if (diffs.needsParallelCompression) {
        plugins.push({
            name: "Waves CLA-76",
            pluginId: "waves.cla76",
            category: "Parallel Compression",
            reason: `Very dynamic source (${vocal.crestFactor.toFixed(1)}dB crest factor) needs parallel compression`,
            bypass: false,
            parallel: true,
            mix: 30,
            parameters: {
                input: 8,
                ratio: 8,
                attack: 7,
                release: 7,
                output: 0,
                analog: true
            }
        });
    }
    
    // Main character compression
    const ratio = Math.min(8, 3 + (diffs.crestDiff * 0.8));
    plugins.push({
        name: "Waves CLA-76",
        pluginId: "waves.cla76",
        category: "Character Compression",
        reason: `Add punch and character (${ratio.toFixed(1)}:1 ratio to reduce ${diffs.crestDiff.toFixed(1)}dB crest)`,
        bypass: false,
        parameters: {
            input: diffs.needsHeavyCompression ? 7 : 4,
            ratio: Math.round(ratio),
            attack: 7,
            release: 7,
            output: 0,
            analog: true
        }
    });
    
    // Control compression
    plugins.push({
        name: "FabFilter Pro-C 2",
        pluginId: "fabfilter.proc2",
        category: "Control Compression",
        reason: "Final dynamic control and consistency",
        bypass: false,
        parameters: {
            threshold: -18 + (diffs.crestDiff * 2),
            ratio: Math.min(6, 3 + (diffs.crestDiff * 0.5)),
            attack: diffs.timingIssues ? 5 : 10,
            release: "Auto",
            knee: 4,
            lookahead: 5,
            style: "Vocal"
        }
    });
    
    // Multiband if needed
    if (diffs.needsMultibandComp) {
        plugins.push({
            name: "Waves C6",
            pluginId: "waves.c6",
            category: "Multiband Compression",
            reason: "Balance frequency zones independently",
            bypass: false,
            parameters: buildMultibandCompSettings(vocal, reference, diffs)
        });
    }
    
    return plugins;
}

// PHASE 5: Problem Solving Chain
function buildProblemSolvingChain(vocal, reference, diffs) {
    const plugins = [];
    
    // De-essing
    if (diffs.sibilanceIssue) {
        const deessFreq = 6500 + (diffs.sibilanceDiff * 10000);
        const deessAmount = Math.min(12, 4 + (diffs.sibilanceDiff / reference.sibilance * 10));
        
        plugins.push({
            name: "Waves Renaissance DeEsser",
            pluginId: "waves.rdeesser",
            category: "De-Esser",
            reason: `High sibilance detected (${(vocal.sibilance * 1000).toFixed(2)} vs ${(reference.sibilance * 1000).toFixed(2)} target)`,
            bypass: false,
            parameters: {
                frequency: Math.round(deessFreq),
                threshold: -35,
                attenuation: Math.round(deessAmount),
                mode: "Split"
            }
        });
        
        // Second de-esser if severe
        if (diffs.needsMultipleDeessers) {
            plugins.push({
                name: "FabFilter Pro-DS",
                pluginId: "fabfilter.prods",
                category: "De-Esser (Secondary)",
                reason: "Severe sibilance needs multi-stage de-essing",
                bypass: false,
                parameters: {
                    frequency: deessFreq + 1000,
                    range: -6,
                    audition: false
                }
            });
        }
    }
    
    // Surgical EQ for harsh frequencies
    if (diffs.harshFrequencies.length > 0) {
        plugins.push({
            name: "FabFilter Pro-Q 3",
            pluginId: "fabfilter.proq3",
            category: "Surgical EQ",
            reason: `Remove harsh frequencies: ${diffs.harshFrequencies.map(h => h.freq + 'Hz').join(', ')}`,
            bypass: false,
            mode: "Zero Latency",
            parameters: {
                bands: diffs.harshFrequencies.map(harsh => ({
                    enabled: true,
                    frequency: harsh.freq,
                    gain: -3 - (harsh.severity / 20),
                    q: 3.5,
                    type: "Bell",
                    dynamic: true,
                    threshold: -20
                }))
            }
        });
    }
    
    return plugins;
}

// PHASE 6: Character & Color Chain
function buildCharacterChain(vocal, reference, diffs) {
    const plugins = [];
    
    // Tape saturation for warmth
    if (diffs.needsTapeWarmth) {
        plugins.push({
            name: "Waves J37 Tape",
            pluginId: "waves.j37",
            category: "Tape Saturation",
            reason: `Add low-end warmth (need ${((diffs.bassDiff) * 1000).toFixed(1)} more bass presence)`,
            bypass: false,
            parameters: {
                tape: diffs.bassDiff > 0.008 ? "Heavy" : "Medium",
                speed: "15 IPS",
                formula: "900",
                saturation: 60,
                wow: 25,
                flutter: 20
            }
        });
    }
    
    // Tube saturation for mid warmth
    if (diffs.needsTubeWarmth) {
        plugins.push({
            name: "Waves Puig Child Compressor",
            pluginId: "waves.puigchild",
            category: "Tube Saturation",
            reason: "Add tube harmonics and mid-range warmth",
            bypass: false,
            parameters: {
                inputGain: 4,
                threshold: -5,
                attackRelease: "Medium",
                mix: 40
            }
        });
    }
    
    // Harmonic exciter
    if (diffs.needsHarmonics) {
        plugins.push({
            name: "Waves Aphex Vintage Aural Exciter",
            pluginId: "waves.aphex",
            category: "Harmonic Exciter",
            reason: "Add high-frequency harmonics for presence",
            bypass: false,
            parameters: {
                harmonics: 40,
                bigBottom: diffs.needsWarmth ? 30 : 0,
                mix: 25
            }
        });
    }
    
    return plugins;
}

// PHASE 7: Spatial Effects Chain
function buildSpatialChain(vocal, reference, diffs) {
    const plugins = [];
    
    // Delay
    plugins.push({
        name: "Waves H-Delay",
        pluginId: "waves.hdelay",
        category: "Delay",
        reason: "Add depth and dimension",
        bypass: false,
        parameters: {
            delay: "1/4",
            feedback: 22,
            mix: 18,
            locut: 250,
            hicut: 6000,
            analog: true
        }
    });
    
    // Reverb
    plugins.push({
        name: "Valhalla Room",
        pluginId: "valhalla.room",
        category: "Reverb",
        reason: "Add space and natural ambience",
        bypass: false,
        parameters: {
            predelay: 25,
            decay: 1.2,
            mix: 12,
            damping: 6500,
            size: "Medium"
        }
    });
    
    return plugins;
}

// PHASE 8: Final Polish Chain
function buildFinalPolishChain(vocal, reference, diffs) {
    const plugins = [];
    
    // Stereo widener (if stereo)
    if (diffs.needsStereoWidth) {
        plugins.push({
            name: "Waves S1 Stereo Imager",
            pluginId: "waves.s1",
            category: "Stereo Width",
            reason: "Enhance stereo image",
            bypass: false,
            parameters: {
                width: 120,
                asymmetry: 0
            }
        });
    }
    
    // Final limiter
    if (diffs.needsFinalLimiting) {
        plugins.push({
            name: "Waves L2 Ultramaximizer",
            pluginId: "waves.l2",
            category: "Final Limiter",
            reason: "Control peaks and maximize loudness",
            bypass: false,
            parameters: {
                threshold: -2,
                ceiling: -0.3,
                release: "ARC"
            }
        });
    }
    
    return plugins;
}

// Helper: Build AGGRESSIVE subtractive EQ bands
function buildAggressiveSubtractiveEQBands(vocal, reference, diffs) {
    const bands = [];
    
    // High-pass - ALWAYS remove sub-frequencies
    bands.push({
        enabled: true,
        type: "HighPass",
        frequency: 70, // Aggressive
        slope: 36, // Steep
        q: 0.71
    });
    
    // Cut EVERY problem frequency aggressively
    diffs.harshFrequencies.forEach(issue => {
        if (issue.needsCut) {
            bands.push({
                enabled: true,
                type: "Bell",
                frequency: issue.freq,
                gain: Math.min(-12, -5 - (issue.severity / 10)), // AGGRESSIVE cuts
                q: 3.5, // Surgical
                dynamic: issue.severity > 30, // Make it dynamic if severe
                threshold: -20
            });
        }
    });
    
    return bands;
}

// Helper: Build AGGRESSIVE additive EQ bands
function buildAggressiveAdditiveEQBands(vocal, reference, diffs) {
    const bands = [];
    
    // Sub-bass - FORCE exact match
    if (Math.abs(diffs.subBassDiff) > 0.0001) {
        bands.push({
            enabled: true,
            type: "Bell",
            frequency: 60,
            gain: Math.max(-12, Math.min(12, diffs.subBassDiff * 600)), // AGGRESSIVE
            q: 1.0
        });
    }
    
    // Bass - FORCE exact match
    if (Math.abs(diffs.bassDiff) > 0.0001) {
        bands.push({
            enabled: true,
            type: "Bell",
            frequency: 150,
            gain: Math.max(-12, Math.min(12, diffs.bassDiff * 400)), // AGGRESSIVE
            q: 1.2
        });
    }
    
    // Low-mids - FORCE exact match
    if (Math.abs(diffs.lowMidsDiff) > 0.0001) {
        bands.push({
            enabled: true,
            type: "Bell",
            frequency: 350,
            gain: Math.max(-12, Math.min(12, diffs.lowMidsDiff * 400)),
            q: 1.2
        });
    }
    
    // Mids - FORCE exact match
    if (Math.abs(diffs.midsDiff) > 0.0001) {
        bands.push({
            enabled: true,
            type: "Bell",
            frequency: 1000,
            gain: Math.max(-12, Math.min(12, diffs.midsDiff * 500)),
            q: 1.5
        });
    }
    
    // High-mids - FORCE exact match
    if (Math.abs(diffs.highMidsDiff) > 0.0001) {
        bands.push({
            enabled: true,
            type: "Bell",
            frequency: 3000,
            gain: Math.max(-12, Math.min(12, diffs.highMidsDiff * 600)),
            q: 2.0
        });
    }
    
    // Presence - FORCE exact match
    if (Math.abs(diffs.presenceDiff) > 0.0001) {
        bands.push({
            enabled: true,
            type: "Bell",
            frequency: 5000,
            gain: Math.max(-12, Math.min(12, diffs.presenceDiff * 700)),
            q: 1.8
        });
    }
    
    // Brilliance - FORCE exact match
    if (Math.abs(diffs.brillianceDiff) > 0.0001) {
        bands.push({
            enabled: true,
            type: "Bell",
            frequency: 8000,
            gain: Math.max(-12, Math.min(12, diffs.brillianceDiff * 800)),
            q: 1.5
        });
    }
    
    // Air - FORCE exact match
    if (Math.abs(diffs.airDiff) > 0.0001) {
        bands.push({
            enabled: true,
            type: "HighShelf",
            frequency: 12000,
            gain: Math.max(-12, Math.min(12, diffs.airDiff * 1000)),
            q: 0.7
        });
    }
    
    return bands;
}

// Helper: Build EXTREME dynamic EQ bands
function buildExtremeDynamicEQBands(vocal, reference, diffs) {
    const bands = [];
    
    // Dynamically control EVERY frequency band
    const dynamicBands = [
        { freq: 200, diff: diffs.bassDiff, name: 'Bass' },
        { freq: 500, diff: diffs.lowMidsDiff, name: 'Low-Mids' },
        { freq: 2000, diff: diffs.midsDiff, name: 'Mids' },
        { freq: 4000, diff: diffs.highMidsDiff, name: 'High-Mids' },
        { freq: 7000, diff: diffs.presenceDiff, name: 'Presence' }
    ];
    
    dynamicBands.forEach(band => {
        if (Math.abs(band.diff) > 0.0001) {
            bands.push({
                enabled: true,
                type: "Bell",
                frequency: band.freq,
                gain: Math.max(-12, Math.min(12, band.diff * 400)),
                q: 2.0,
                dynamic: true,
                threshold: -20,
                range: -8,
                attack: 10,
                release: 50
            });
        }
    });
    
    return bands;
}

// Helper: Build subtractive EQ bands (OLD - keeping for compatibility)
function buildSubtractiveEQBands(vocal, reference, diffs) {
    return buildAggressiveSubtractiveEQBands(vocal, reference, diffs);
}

// Helper: Build additive EQ bands (OLD - keeping for compatibility)
function buildAdditiveEQBands(vocal, reference, diffs) {
    return buildAggressiveAdditiveEQBands(vocal, reference, diffs);
}

// Helper: Build dynamic EQ bands (OLD - keeping for compatibility)
function buildDynamicEQBands(vocal, reference, diffs) {
    return buildExtremeDynamicEQBands(vocal, reference, diffs);
}

// Helper: Build multiband comp settings
function buildMultibandCompSettings(vocal, reference, diffs) {
    return {
        band1: { threshold: -25, ratio: 3, frequency: 250 },
        band2: { threshold: -20, ratio: 4, frequency: 1000 },
        band3: { threshold: -18, ratio: 3.5, frequency: 4000 },
        band4: { threshold: -22, ratio: 3, frequency: 8000 }
    };
}

// Generate analysis report
function generateAnalysisReport(vocal, reference) {
    const report = {
        vocalStats: {
            pitchVariation: vocal.pitchVariation.toFixed(1),
            crestFactor: vocal.crestFactor.toFixed(2),
            rms: (vocal.rms * 100).toFixed(2) + '%',
            sibilance: (vocal.sibilance * 1000).toFixed(2)
        }
    };
    
    // Add reference stats only if reference exists
    if (reference) {
        report.referenceStats = {
            pitchVariation: reference.pitchVariation.toFixed(1),
            crestFactor: reference.crestFactor.toFixed(2),
            rms: (reference.rms * 100).toFixed(2),
            sibilance: (reference.sibilance * 1000).toFixed(2)
        };
        
        report.corrections = {
            pitchCorrection: Math.abs(vocal.pitchVariation - reference.pitchVariation).toFixed(1) + 'Hz',
            dynamicsReduction: Math.abs(vocal.crestFactor - reference.crestFactor).toFixed(2) + 'dB',
            sibilanceReduction: ((vocal.sibilance - reference.sibilance) * 1000).toFixed(2)
        };
    } else {
        report.note = "Analysis based on professional standards (no reference track)";
    }
    
    return report;
}

// Generate StudioVerse Chain JSON
function generateStudioVerseChain(settings) {
    const chain = {
        name: "AI Vocal Chain",
        description: "Generated by AI Vocal Plugin Analyzer",
        version: "1.0",
        plugins: []
    };
    
    // 1. Waves Tune Real-Time (Pitch Correction)
    chain.plugins.push({
        name: "Waves Tune Real-Time",
        pluginId: "waves.tune.realtime",
        bypass: false,
        parameters: {
            speed: settings.pitchCorrection.wavesTune.speed || 15,
            note: settings.pitchCorrection.wavesTune.note || 100,
            cents: settings.pitchCorrection.wavesTune.cents || 50,
            transition: settings.pitchCorrection.wavesTune.transition || 200,
            scale: "Chromatic",
            formant: false
        }
    });
    
    // 2. Waves Renaissance EQ (Subtractive)
    const eqBands = settings.eq.fabirFQ.bands;
    chain.plugins.push({
        name: "Waves Renaissance EQ",
        pluginId: "waves.req",
        bypass: false,
        parameters: {
            highpass: {
                enabled: true,
                frequency: parseFloat(eqBands[0].freq) || 80,
                slope: 24
            },
            band1: {
                enabled: Math.abs(parseFloat(eqBands[1].gain)) > 0.5,
                frequency: parseFloat(eqBands[1].freq) || 200,
                gain: parseFloat(eqBands[1].gain) || 0,
                q: eqBands[1].q || 1.2,
                type: "Bell"
            },
            band2: {
                enabled: Math.abs(parseFloat(eqBands[2].gain)) > 0.5,
                frequency: parseFloat(eqBands[2].freq) || 800,
                gain: parseFloat(eqBands[2].gain) || 0,
                q: eqBands[2].q || 1.5,
                type: "Bell"
            },
            band3: {
                enabled: Math.abs(parseFloat(eqBands[3].gain)) > 0.5,
                frequency: parseFloat(eqBands[3].freq) || 3000,
                gain: parseFloat(eqBands[3].gain) || 0,
                q: eqBands[3].q || 2.0,
                type: "Bell"
            },
            band4: {
                enabled: Math.abs(parseFloat(eqBands[4].gain)) > 0.5,
                frequency: parseFloat(eqBands[4].freq) || 8000,
                gain: parseFloat(eqBands[4].gain) || 0,
                q: eqBands[4].q || 1.5,
                type: "Bell"
            },
            highshelf: {
                enabled: Math.abs(parseFloat(eqBands[5].gain)) > 0.5,
                frequency: parseFloat(eqBands[5].freq) || 12000,
                gain: parseFloat(eqBands[5].gain) || 0,
                q: eqBands[5].q || 0.7
            }
        }
    });
    
    // 3. Waves CLA-76 (Character Compression)
    const cla76 = settings.compression.cla76;
    chain.plugins.push({
        name: "Waves CLA-76",
        pluginId: "waves.cla76",
        bypass: false,
        parameters: {
            input: parseInputValue(cla76.input),
            attack: 7, // Fastest
            release: 7, // Fastest
            ratio: cla76.ratio.includes("8:1") ? 8 : 4,
            output: 0, // Adjust to unity
            analog: true
        }
    });
    
    // 4. Waves Renaissance Compressor (Control)
    const proC = settings.compression.fabfilterProC;
    chain.plugins.push({
        name: "Waves Renaissance Compressor",
        pluginId: "waves.rcomp",
        bypass: false,
        parameters: {
            threshold: parseFloat(proC.threshold) || -18,
            ratio: parseRatio(proC.ratio),
            attack: parseFloat(proC.attack) || 10,
            release: proC.release === "Auto" ? "Auto" : parseFloat(proC.release) || 100,
            gain: 0, // Makeup gain - adjust as needed
            arc: "Warm" // Electro/Warm/Smooth
        }
    });
    
    // 5. Waves Renaissance DeEsser
    const deesser = settings.deesser.wavesDESSER;
    chain.plugins.push({
        name: "Waves Renaissance DeEsser",
        pluginId: "waves.rdeesser",
        bypass: false,
        parameters: {
            frequency: parseFloat(deesser.frequency) || 6500,
            threshold: parseFloat(deesser.threshold) || -30,
            attenuation: parseFloat(deesser.attenuation) || 6,
            mode: "Split"
        }
    });
    
    // 6. Waves J37 Tape (Saturation)
    const tape = settings.saturation.wavesJPuigChild;
    chain.plugins.push({
        name: "Waves J37 Tape",
        pluginId: "waves.j37",
        bypass: false,
        parameters: {
            tape: tape.tape || "Medium",
            speed: tape.speed || "15 IPS",
            formula: tape.formula || "900",
            wow: parseFloat(tape.wow) || 20,
            flutter: parseFloat(tape.flutter) || 22,
            saturation: 50,
            bias: 50,
            hf: 0 // High frequency adjust
        }
    });
    
    // 7. Waves H-Delay
    const delay = settings.reverb.wavesHDelay;
    chain.plugins.push({
        name: "Waves H-Delay",
        pluginId: "waves.hdelay",
        bypass: false,
        parameters: {
            delay: "1/4", // Quarter note - sync to tempo
            feedback: parseFloat(delay.feedback) || 25,
            mix: parseFloat(delay.mix) || 20,
            locut: parseFloat(delay.locut) || 200,
            hicut: parseFloat(delay.hicut) || 6000,
            pingpong: false,
            analog: true
        }
    });
    
    // 8. Waves H-Reverb (if you want reverb in chain)
    const reverb = settings.reverb.valhalla;
    chain.plugins.push({
        name: "Waves H-Reverb",
        pluginId: "waves.hreverb",
        bypass: false,
        parameters: {
            time: parseFloat(reverb.decay) || 1.2,
            predelay: parseFloat(reverb.predelay) || 30,
            mix: parseFloat(reverb.mix) || 15,
            damping: parseFloat(reverb.damping) || 7000,
            size: "Medium",
            density: 70,
            envelope: 0
        }
    });
    
    return chain;
}

// Helper functions for parsing settings
function parseInputValue(input) {
    // Parse "+2 to +6 dB" format
    const match = input.match(/\+(\d+)/);
    return match ? parseInt(match[1]) : 4;
}

function parseRatio(ratio) {
    // Parse "4:1" format
    const match = ratio.match(/(\d+):1/);
    return match ? parseFloat(match[1]) : 4;
}

// Format settings as text for export
function formatSettingsAsText(settings) {
    let text = '=== AI VOCAL PLUGIN ANALYZER - SETTINGS REPORT ===\n\n';
    
    text += '1. PITCH CORRECTION\n';
    text += '-------------------\n';
    text += `Plugin: ${settings.pitchCorrection.autoTune.plugin}\n`;
    for (const [key, value] of Object.entries(settings.pitchCorrection.autoTune)) {
        if (key !== 'plugin') text += `  ${formatLabel(key)}: ${value}\n`;
    }
    text += `\nDescription: ${settings.pitchCorrection.description}\n\n`;
    
    text += '2. EQ SETTINGS\n';
    text += '--------------\n';
    text += `Plugin: ${settings.eq.fabirFQ.plugin}\n`;
    settings.eq.fabirFQ.bands.forEach((band, i) => {
        text += `  Band ${i + 1}: ${band.freq} - ${band.type} - Q: ${band.q || 'N/A'} - Gain: ${band.gain || band.slope}\n`;
    });
    text += `\nDescription: ${settings.eq.description}\n\n`;
    
    text += '3. COMPRESSION\n';
    text += '--------------\n';
    text += `Plugin: ${settings.compression.cla76.plugin}\n`;
    for (const [key, value] of Object.entries(settings.compression.cla76)) {
        if (key !== 'plugin') text += `  ${formatLabel(key)}: ${value}\n`;
    }
    text += `\nDescription: ${settings.compression.description}\n\n`;
    
    // Add more sections...
    
    text += '\n=== PROCESSING CHAIN ===\n';
    settings.processingChain.order.forEach(step => {
        text += `${step.step}. ${step.plugin} - ${step.purpose}\n`;
    });
    
    return text;
}

// Draw waveform
function drawWaveform(buffer, canvasId) {
    const canvas = document.getElementById(canvasId);
    const ctx = canvas.getContext('2d');
    const width = canvas.width = canvas.offsetWidth;
    const height = canvas.height = canvas.offsetHeight;
    
    ctx.clearRect(0, 0, width, height);
    
    const data = buffer.getChannelData(0);
    const step = Math.ceil(data.length / width);
    const amp = height / 2;
    
    ctx.fillStyle = '#00d4ff';
    ctx.globalAlpha = 0.6;
    
    for (let i = 0; i < width; i++) {
        let min = 1.0;
        let max = -1.0;
        
        for (let j = 0; j < step; j++) {
            const datum = data[(i * step) + j];
            if (datum < min) min = datum;
            if (datum > max) max = datum;
        }
        
        ctx.fillRect(i, (1 + min) * amp, 1, Math.max(1, (max - min) * amp));
    }
}

// Update status bar
function updateStatus(message) {
    statusBar.textContent = message;
}

// Display Professional Engineer Advice
function displayEngineerAdvice(vocal, reference, hasReference) {
    // Find or create advice container
    let adviceContainer = document.getElementById('engineerAdvice');
    
    if (!adviceContainer) {
        // Create it after plugin settings container
        adviceContainer = document.createElement('div');
        adviceContainer.id = 'engineerAdvice';
        adviceContainer.style.cssText = 'margin-top: 30px;';
        pluginSettingsContainer.parentElement.appendChild(adviceContainer);
    }
    
    const issues = analyzeVocalIssues(vocal, reference, hasReference);
    const recommendations = generateProRecommendations(vocal, reference, hasReference, issues);
    const quickWins = generateQuickWins(issues);
    const advancedTips = generateAdvancedTips(vocal, issues);
    
    adviceContainer.innerHTML = `
        <div style="background: linear-gradient(135deg, rgba(123, 47, 247, 0.15) 0%, rgba(0, 212, 255, 0.15) 100%); border: 2px solid rgba(123, 47, 247, 0.5); padding: 30px; border-radius: 15px; margin: 25px 0;">
            
            <!-- Header -->
            <div style="text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid rgba(255, 255, 255, 0.2);">
                <h2 style="color: #7b2ff7; margin: 0 0 10px 0; font-size: 2em;">🎧 PROFESSIONAL ENGINEER ANALYSIS</h2>
                <p style="color: #aaa; margin: 0; font-size: 1em;">${hasReference ? 'Comparison Analysis with Reference Track' : 'Standalone Professional Assessment'}</p>
            </div>
            
            <!-- Critical Issues -->
            ${issues.critical.length > 0 ? `
                <div style="background: rgba(255, 107, 107, 0.15); border-left: 4px solid #ff6b6b; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <h3 style="color: #ff6b6b; margin: 0 0 15px 0;">⚠️ CRITICAL ISSUES (Fix These First)</h3>
                    <ul style="margin: 0; padding-left: 20px; line-height: 1.8; color: #fff;">
                        ${issues.critical.map(issue => `<li><strong>${issue.title}:</strong> ${issue.description}</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
            
            <!-- Important Issues -->
            ${issues.important.length > 0 ? `
                <div style="background: rgba(255, 170, 0, 0.15); border-left: 4px solid #ffaa00; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <h3 style="color: #ffaa00; margin: 0 0 15px 0;">🔸 IMPORTANT ISSUES (Address These Next)</h3>
                    <ul style="margin: 0; padding-left: 20px; line-height: 1.8; color: #fff;">
                        ${issues.important.map(issue => `<li><strong>${issue.title}:</strong> ${issue.description}</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
            
            <!-- Quick Wins -->
            <div style="background: rgba(0, 255, 136, 0.15); border-left: 4px solid #00ff88; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h3 style="color: #00ff88; margin: 0 0 15px 0;">⚡ QUICK WINS (Instant Improvements)</h3>
                <ul style="margin: 0; padding-left: 20px; line-height: 1.8; color: #fff;">
                    ${quickWins.map(win => `<li>${win}</li>`).join('')}
                </ul>
            </div>
            
            <!-- Professional Recommendations -->
            <div style="background: rgba(0, 212, 255, 0.15); border-left: 4px solid #00d4ff; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h3 style="color: #00d4ff; margin: 0 0 15px 0;">🎯 PROFESSIONAL RECOMMENDATIONS</h3>
                ${recommendations.map((rec, index) => `
                    <div style="margin-bottom: 20px; padding: 15px; background: rgba(0, 0, 0, 0.3); border-radius: 8px;">
                        <h4 style="color: #00ff88; margin: 0 0 10px 0;">${index + 1}. ${rec.title}</h4>
                        <p style="color: #ccc; margin: 0 0 10px 0; line-height: 1.6;">${rec.explanation}</p>
                        <div style="background: rgba(123, 47, 247, 0.2); padding: 10px; border-radius: 6px;">
                            <strong style="color: #7b2ff7;">Action:</strong> <span style="color: #fff;">${rec.action}</span>
                        </div>
                        ${rec.settings ? `
                            <div style="margin-top: 10px; padding: 10px; background: rgba(0, 212, 255, 0.1); border-radius: 6px; font-family: monospace; font-size: 0.9em; color: #00d4ff;">
                                ${rec.settings}
                            </div>
                        ` : ''}
                    </div>
                `).join('')}
            </div>
            
            <!-- Advanced Tips -->
            <div style="background: rgba(123, 47, 247, 0.15); border-left: 4px solid #7b2ff7; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h3 style="color: #7b2ff7; margin: 0 0 15px 0;">🔬 ADVANCED TECHNIQUES (For Experienced Engineers)</h3>
                <ul style="margin: 0; padding-left: 20px; line-height: 1.8; color: #fff;">
                    ${advancedTips.map(tip => `<li>${tip}</li>`).join('')}
                </ul>
            </div>
            
            <!-- Overall Assessment -->
            <div style="background: linear-gradient(135deg, rgba(0, 255, 136, 0.2) 0%, rgba(0, 212, 255, 0.2) 100%); padding: 20px; border-radius: 8px; border: 2px solid rgba(0, 255, 136, 0.3);">
                <h3 style="color: #00ff88; margin: 0 0 15px 0;">📊 OVERALL ASSESSMENT</h3>
                <p style="color: #fff; line-height: 1.8; margin: 0 0 15px 0;">
                    ${generateOverallAssessment(vocal, reference, hasReference, issues)}
                </p>
                <div style="padding: 15px; background: rgba(0, 0, 0, 0.4); border-radius: 6px;">
                    <strong style="color: #00d4ff;">Next Steps:</strong>
                    <ol style="margin: 10px 0 0 20px; padding: 0; line-height: 1.8; color: #fff;">
                        <li>Apply the plugin settings from the tabs above</li>
                        <li>Start with critical issues first, then move to important ones</li>
                        <li>Use your ears - trust the numbers, but A/B test everything</li>
                        <li>${hasReference ? 'Reference check regularly against your loaded track(s)' : 'Consider loading a reference track for more targeted results'}</li>
                        <li>Take breaks every 30-45 minutes to maintain fresh ears</li>
                    </ol>
                </div>
            </div>
            
        </div>
    `;
}

// Analyze Vocal Issues
function analyzeVocalIssues(vocal, reference, hasReference) {
    const issues = {
        critical: [],
        important: [],
        minor: []
    };
    
    // Check for critical issues
    if (vocal.peak > 0.95) {
        issues.critical.push({
            title: 'Clipping Detected',
            description: `Peak level at ${(vocal.peak * 100).toFixed(1)}% - Your vocal is clipping! Re-record with lower input gain or use clip restoration before processing.`
        });
    }
    
    if (vocal.pitchVariation > 60) {
        issues.critical.push({
            title: 'Severe Pitch Instability',
            description: `${vocal.pitchVariation.toFixed(1)}Hz variation - Extremely inconsistent pitch. Consider re-recording or heavy Melodyne editing.`
        });
    }
    
    if (vocal.crestFactor > 15) {
        issues.critical.push({
            title: 'Uncontrolled Dynamics',
            description: `${vocal.crestFactor.toFixed(1)}dB crest factor - Volume fluctuates wildly. Need aggressive compression or vocal riding.`
        });
    }
    
    if (vocal.rms < 0.02) {
        issues.critical.push({
            title: 'Recording Too Quiet',
            description: `RMS level at ${(vocal.rms * 100).toFixed(1)}% - Recording is very quiet. May need to re-record with proper gain staging.`
        });
    }
    
    // Check for important issues
    if (vocal.pitchVariation > 30 && vocal.pitchVariation <= 60) {
        issues.important.push({
            title: 'Moderate Pitch Issues',
            description: `${vocal.pitchVariation.toFixed(1)}Hz variation - Noticeable pitch inconsistency. Auto-Tune or Melodyne recommended.`
        });
    }
    
    if (vocal.sibilance > 0.015) {
        issues.important.push({
            title: 'Excessive Sibilance',
            description: `Sibilance at ${(vocal.sibilance * 1000).toFixed(2)} - Harsh "S" sounds. Needs de-essing (target 5-8kHz).`
        });
    }
    
    if (vocal.crestFactor > 10 && vocal.crestFactor <= 15) {
        issues.important.push({
            title: 'Dynamic Range Too Wide',
            description: `${vocal.crestFactor.toFixed(1)}dB crest factor - Inconsistent volume. Need multi-stage compression.`
        });
    }
    
    if (vocal.bass < 0.008) {
        issues.important.push({
            title: 'Thin/Weak Low End',
            description: 'Vocal lacks body and warmth. Boost 150-250Hz and consider tube/tape saturation.'
        });
    }
    
    if (vocal.brilliance + vocal.air < 0.012) {
        issues.important.push({
            title: 'Dull/Dark Vocal',
            description: 'Lacks presence and air. Boost 8-12kHz with a high shelf, and add 4-6kHz for presence.'
        });
    }
    
    if (vocal.subBass > 0.015) {
        issues.important.push({
            title: 'Excessive Low-End Rumble',
            description: 'Too much sub-bass energy. High-pass filter at 80-100Hz to clean up the low end.'
        });
    }
    
    // Reference-based issues
    if (hasReference && reference) {
        const bassDiff = Math.abs(vocal.bass - reference.bass);
        const midsDiff = Math.abs(vocal.mids - reference.mids);
        const presenceDiff = Math.abs(vocal.presence - reference.presence);
        
        if (bassDiff > 0.008) {
            issues.important.push({
                title: 'Bass Mismatch with Reference',
                description: `Your vocal has ${vocal.bass > reference.bass ? 'too much' : 'not enough'} low-end compared to reference. ${vocal.bass > reference.bass ? 'Cut' : 'Boost'} around 150-200Hz.`
            });
        }
        
        if (presenceDiff > 0.005) {
            issues.important.push({
                title: 'Presence Mismatch',
                description: `Reference has ${reference.presence > vocal.presence ? 'more' : 'less'} presence/clarity. ${reference.presence > vocal.presence ? 'Boost' : 'Cut'} 4-6kHz.`
            });
        }
    }
    
    return issues;
}

// Generate Professional Recommendations
function generateProRecommendations(vocal, reference, hasReference, issues) {
    const recommendations = [];
    
    // Pitch Correction Recommendation
    if (vocal.pitchVariation > 15) {
        const severity = vocal.pitchVariation > 40 ? 'heavy' : 'moderate';
        recommendations.push({
            title: `Pitch Correction (${severity})`,
            explanation: `Your vocal has ${vocal.pitchVariation.toFixed(1)}Hz of pitch variation, which ${vocal.pitchVariation > 40 ? 'significantly impacts' : 'noticeably affects'} the professional quality. Modern rap/hip-hop demands tight pitch control.`,
            action: `Use ${vocal.pitchVariation > 40 ? 'Melodyne for surgical correction first, then' : ''} Auto-Tune Pro or Waves Tune Real-Time with ${vocal.pitchVariation > 30 ? 'fast' : 'medium'} retune speed (${Math.round(15 + vocal.pitchVariation / 2)}ms).`,
            settings: `Retune: ${Math.round(15 + vocal.pitchVariation / 2)}ms | Humanize: ${Math.round(40 - vocal.pitchVariation / 3)} | Natural Vibrato: ${Math.round(50 - vocal.pitchVariation / 2)}`
        });
    }
    
    // EQ Recommendation
    const needsEQ = vocal.bass < 0.012 || vocal.brilliance + vocal.air < 0.015 || vocal.subBass > 0.015;
    if (needsEQ) {
        const eqMoves = [];
        if (vocal.subBass > 0.015) eqMoves.push('HPF @ 80Hz (36dB/oct)');
        if (vocal.bass < 0.012) eqMoves.push('Boost 150-200Hz (+2 to +4dB)');
        if (vocal.mids < 0.015) eqMoves.push('Boost 1-2kHz (+2 to +3dB) for clarity');
        if (vocal.presence < 0.010) eqMoves.push('Boost 4-6kHz (+3 to +5dB) for presence');
        if (vocal.brilliance + vocal.air < 0.015) eqMoves.push('High shelf @ 10kHz (+2 to +4dB) for air');
        
        recommendations.push({
            title: 'Frequency Sculpting (EQ)',
            explanation: `Your vocal's frequency balance needs adjustment. ${hasReference ? 'Comparing to your reference track,' : 'For professional standards,'} we need to reshape the tonal character to sit properly in a mix.`,
            action: `Use FabFilter Pro-Q 3 or similar surgical EQ. Apply changes in this order: subtractive cuts first, then additive boosts.`,
            settings: eqMoves.join(' | ')
        });
    }
    
    // Compression Recommendation
    if (vocal.crestFactor > 6) {
        const compressionLevel = vocal.crestFactor > 10 ? 'aggressive' : 'moderate';
        recommendations.push({
            title: `Dynamic Control (${compressionLevel} compression needed)`,
            explanation: `Your vocal has a ${vocal.crestFactor.toFixed(1)}dB crest factor, meaning the difference between loud and quiet parts is ${vocal.crestFactor > 10 ? 'way too large' : 'larger than ideal'}. Professional vocals are tightly controlled.`,
            action: `Use 2-stage compression: CLA-76 for color and aggression, then FabFilter Pro-C 2 for transparent control. ${vocal.crestFactor > 10 ? 'Consider using a vocal rider plugin first.' : ''}`,
            settings: `CLA-76: Fastest attack/release, ${vocal.crestFactor > 10 ? '8:1' : '4:1'} ratio | Pro-C 2: ${Math.round(-20 + vocal.crestFactor * 1.5)}dB threshold, ${Math.round(3 + vocal.crestFactor / 3)}:1 ratio, 10ms attack`
        });
    }
    
    // De-essing Recommendation
    if (vocal.sibilance > 0.012) {
        recommendations.push({
            title: 'Sibilance Control (De-essing)',
            explanation: `You have ${vocal.sibilance > 0.015 ? 'significant' : 'noticeable'} sibilance (${(vocal.sibilance * 1000).toFixed(2)}). Those harsh "S", "T", and "CH" sounds will jump out in the mix and cause ear fatigue.`,
            action: `Use Waves Renaissance DeEsser or FabFilter Pro-DS. Target the specific frequency where sibilance lives (usually 5-8kHz for vocals).`,
            settings: `Frequency: ${vocal.brilliance > 0.012 ? '6500-7500Hz' : '5500-6500Hz'} | Threshold: -30dB | Attenuation: ${Math.round(4 + (vocal.sibilance - 0.010) * 500)}dB`
        });
    }
    
    // Saturation Recommendation
    if (vocal.bass < 0.012 || vocal.transientStrength < 0.006) {
        recommendations.push({
            title: 'Harmonic Enhancement (Saturation)',
            explanation: `Your vocal ${vocal.bass < 0.012 ? 'lacks warmth and body' : 'could use more presence and punch'}. Saturation adds harmonics that make vocals feel "expensive" and helps them cut through dense instrumentals.`,
            action: `Use tape saturation (Waves J37) for warmth, or tube saturation (Decapitator) for midrange punch. Keep it subtle - 20-40% mix.`,
            settings: vocal.bass < 0.012 ? `J37 Tape: 15 IPS, Formula 900, 50-60% saturation` : `Decapitator: Drive 3-5, Style ${vocal.transientStrength < 0.006 ? 'A (Ampex)' : 'E'}, Mix 30%`
        });
    }
    
    // Reverb/Space Recommendation
    recommendations.push({
        title: 'Spatial Depth (Reverb & Delay)',
        explanation: `Even rap vocals need subtle space to feel "finished". Too much reverb muddies the clarity, too little sounds amateur and dry.`,
        action: `Use a short room reverb (0.8-1.5s decay) and a slap delay. Keep both VERY subtle - rap is about clarity and upfront presence.`,
        settings: `Valhalla Room: 1.2s decay, 25ms predelay, 12-15% mix | H-Delay: 1/4 note, 20% feedback, 18% mix, HPF @ 250Hz`
        });
    
    // Reference-specific advice
    if (hasReference && reference) {
        const pitchDiff = Math.abs(vocal.pitchVariation - reference.pitchVariation);
        const dynamicDiff = Math.abs(vocal.crestFactor - reference.crestFactor);
        
        if (pitchDiff > 10 || dynamicDiff > 3) {
            recommendations.push({
                title: 'Matching Your Reference',
                explanation: `Your reference track ${pitchDiff > 10 ? `has ${reference.pitchVariation.toFixed(1)}Hz pitch variation vs your ${vocal.pitchVariation.toFixed(1)}Hz` : ''}${pitchDiff > 10 && dynamicDiff > 3 ? ' and ' : ''}${dynamicDiff > 3 ? `${reference.crestFactor.toFixed(1)}dB crest factor vs your ${vocal.crestFactor.toFixed(1)}dB` : ''}. This difference is what's keeping you from matching that professional sound.`,
                action: `Focus on these specific values when applying the plugin chain. The goal is to match the reference's control and consistency, not its exact tone (that's mixing).`,
                settings: null
            });
        }
    }
    
    return recommendations;
}

// Generate Quick Wins
function generateQuickWins(issues) {
    const wins = [
        'High-pass filter at 80Hz - instantly cleans up muddy low end (5 seconds to apply)',
        'Set your Auto-Tune retune speed to 20-40ms - instantly tightens pitch (2 seconds to adjust)',
        'Apply a single CLA-76 compressor with fastest settings - instantly adds punch (10 seconds to insert)',
        'Add 3-5dB boost at 4-5kHz - instantly brings vocal forward in mix (5 seconds to adjust)',
        'Cut 2-3dB at 250-350Hz if vocal sounds "boxy" - instant clarity improvement'
    ];
    
    // Add issue-specific quick wins
    if (issues.critical.some(i => i.title.includes('Clipping'))) {
        wins.unshift('🚨 FIRST: Apply iZotope RX De-clip or re-record - clipping cannot be fixed with mixing');
    }
    
    if (issues.important.some(i => i.title.includes('Sibilance'))) {
        wins.push('Insert Waves Renaissance DeEsser at 6500Hz, -30dB threshold - tames harsh S sounds in seconds');
    }
    
    return wins;
}

// Generate Advanced Tips
function generateAdvancedTips(vocal, issues) {
    const tips = [
        '<strong>Parallel compression:</strong> Duplicate your vocal track, crush it with 10:1 compression, then blend at 20-30%. Adds density without destroying dynamics.',
        '<strong>Multiband compression:</strong> Use Waves C6 to control 200-500Hz (boxiness), 2-4kHz (harshness), and 6-9kHz (sibilance) independently.',
        '<strong>Saturation staging:</strong> Use tape saturation (J37) BEFORE compression for warmth, then tube saturation (Decapitator) AFTER for presence.',
        '<strong>Dynamic EQ:</strong> Use FabFilter Pro-Q 3 in dynamic mode to only cut harsh frequencies when they spike, not all the time.',
        '<strong>Vocal doubling:</strong> Record a second take, pan them 30% L/R, slightly detune (-8 cents / +8 cents) for natural width.',
        '<strong>Automation is key:</strong> Automate reverb and delay sends - less on verses, more on hooks. Automate EQ boosts on emphasized words.',
        '<strong>Reference with A/B plugin:</strong> Use Metric AB or Reference to instantly compare your vocal to professional tracks in real-time.',
        '<strong>Mid/Side processing:</strong> Boost highs on the sides, compress the mids more - creates width while keeping center focused.'
    ];
    
    // Add vocal-specific advanced tips
    if (vocal.pitchVariation > 30) {
        tips.push('<strong>Pitch drift correction:</strong> In Melodyne, use "Correct Pitch Drift" on long notes that sag flat. Keep vibrato natural with "Pitch Modulation" tool.');
    }
    
    if (vocal.crestFactor > 10) {
        tips.push('<strong>Vocal rider technique:</strong> Use Waves Vocal Rider BEFORE compressors to even out volume, then compress for tone. This prevents over-compression.');
    }
    
    return tips;
}

// Generate Overall Assessment
function generateOverallAssessment(vocal, reference, hasReference, issues) {
    let assessment = '';
    
    const criticalCount = issues.critical.length;
    const importantCount = issues.important.length;
    
    if (criticalCount > 0) {
        assessment += `Your vocal has <strong style="color: #ff6b6b;">${criticalCount} critical issue${criticalCount > 1 ? 's' : ''}</strong> that must be addressed before mixing. `;
        assessment += 'These are deal-breakers that will prevent a professional result. ';
    } else {
        assessment += '<strong style="color: #00ff88;">Good news - no critical issues detected!</strong> Your source recording is solid. ';
    }
    
    if (importantCount > 0) {
        assessment += `There are <strong style="color: #ffaa00;">${importantCount} important issue${importantCount > 1 ? 's' : ''}</strong> to address for a polished, professional sound. `;
    } else {
        assessment += 'No major issues found. ';
    }
    
    // Quality assessment
    const qualityScore = Math.max(0, 100 - (criticalCount * 30) - (importantCount * 10));
    let qualityText = '';
    
    if (qualityScore >= 90) qualityText = 'This is a professional-grade recording';
    else if (qualityScore >= 75) qualityText = 'This is a very good recording with minor tweaks needed';
    else if (qualityScore >= 60) qualityText = 'This is a decent recording that needs some work';
    else if (qualityScore >= 40) qualityText = 'This recording needs significant processing';
    else qualityText = 'This recording has major issues that may require re-recording';
    
    assessment += `<br><br><strong>Overall Quality:</strong> ${qualityText} (${qualityScore}/100). `;
    
    // Comparison to reference
    if (hasReference && reference) {
        const pitchDiff = Math.abs(vocal.pitchVariation - reference.pitchVariation);
        const dynamicDiff = Math.abs(vocal.crestFactor - reference.crestFactor);
        const tonalDiff = Math.abs((vocal.bass + vocal.mids + vocal.presence) - (reference.bass + reference.mids + reference.presence)) * 100;
        
        const matchScore = Math.max(0, 100 - (pitchDiff * 2) - (dynamicDiff * 5) - tonalDiff);
        
        assessment += `<br><br><strong>Match to Reference:</strong> ${matchScore.toFixed(0)}% similar. `;
        
        if (matchScore >= 80) {
            assessment += "You're very close to matching your reference! Focus on the fine details.";
        } else if (matchScore >= 60) {
            assessment += "Getting there, but you need to address the key differences highlighted above.";
        } else {
            assessment += "Significant work needed to match your reference. Follow the recommendations in order.";
        }
    } else {
        assessment += '<br><br><strong>Pro Tip:</strong> Loading a reference track from a similar artist will give you more targeted, specific advice tailored to your desired sound.';
    }
    
    return assessment;
}

// Update status bar
function updateStatus(message) {
    statusBar.textContent = message;
}

// Initialize
updateStatus('Ready - Load your vocal and reference tracks to begin analysis');

// ============================================
// AI SMART FEATURES (No Reference Needed!)
// ============================================

// smartAnalyzeBtn and applyToLogicBtn already declared at top of file
const genreSelect = document.getElementById('genreSelect');
const aiAnalysisPreview = document.getElementById('aiAnalysisPreview');

let currentAnalysis = null;

// Enable smart analyze when vocal is loaded - handled in main loadVocalBtn listener above

// Smart Analyze Button
if (!smartAnalyzeBtn._listenerAttached) {
    smartAnalyzeBtn._listenerAttached = true;
    
smartAnalyzeBtn.addEventListener('click', async () => {
    console.log('🧠 AI Smart Analyze clicked!');
    
    if (!vocalBuffer) {
        alert('Please load a vocal track first!');
        return;
    }
    
    try {
        smartAnalyzeBtn.disabled = true;
        smartAnalyzeBtn.innerHTML = '<span class="btn-icon">⏳</span><span class="btn-content"><strong>Analyzing...</strong><small>This may take 30-60 seconds</small></span>';
        
        updateStatus('🧠 AI analyzing your vocal...');
        
        // Get selected genre
        const selectedGenre = genreSelect.value === 'auto' ? null : genreSelect.value;
        
        // Send to main process for analysis
        const result = await ipcRenderer.invoke('smart-analyze-vocal', {
            vocalPath: vocalFilePath,
            genre: selectedGenre
        });
        
        console.log('Analysis result:', result);
        currentAnalysis = result;
        
        // Display results
        displaySmartAnalysis(result);
        
        // Show preview and apply button
        aiAnalysisPreview.style.display = 'block';
        applyToLogicBtn.style.display = 'block';
        applyToLogicBtn.disabled = false;
        
        smartAnalyzeBtn.innerHTML = '<span class="btn-icon">✅</span><span class="btn-content"><strong>Analysis Complete!</strong><small>Ready to apply to Logic Pro</small></span>';
        updateStatus('✅ AI analysis complete!');
        
    } catch (error) {
        console.error('Smart analysis error:', error);
        updateStatus('❌ Analysis failed');
        smartAnalyzeBtn.disabled = false;
        smartAnalyzeBtn.innerHTML = '<span class="btn-icon">🧠</span><span class="btn-content"><strong>AI Analyze My Vocal</strong><small>Repair • Character • Dynamics • Genre • Pro Preset</small></span>';
        alert('Analysis failed: ' + error.message);
    }
});

}

// Apply to Logic Pro Button
applyToLogicBtn.addEventListener('click', async () => {
    console.log('🚀 Applying to Logic Pro!');
    
    if (!currentAnalysis) {
        alert('Please run analysis first!');
        return;
    }
    
    try {
        applyToLogicBtn.disabled = true;
        applyToLogicBtn.innerHTML = '<span class="btn-icon">⏳</span><span class="btn-content"><strong>Automating Logic Pro...</strong><small>Do not touch your Mac!</small></span>';
        
        updateStatus('🤖 Controlling Logic Pro...');
        
        // Send to Logic automation
        const success = await ipcRenderer.invoke('automate-smart-chain', {
            chain: currentAnalysis.logic_chain,
            analysis: currentAnalysis.analysis
        });
        
        if (success) {
            applyToLogicBtn.innerHTML = '<span class="btn-icon">✅</span><span class="btn-content"><strong>Applied Successfully!</strong><small>Check Logic Pro</small></span>';
            updateStatus('✅ Chain applied to Logic Pro!');
            
            // Show success modal
            showSuccessModal('AI chain applied to Logic Pro!');
        } else {
            throw new Error('Automation failed');
        }
        
    } catch (error) {
        console.error('Logic automation error:', error);
        updateStatus('❌ Automation failed');
        applyToLogicBtn.disabled = false;
        applyToLogicBtn.innerHTML = '<span class="btn-icon">🚀</span><span class="btn-content"><strong>Apply to Logic Pro</strong><small>AI will control your Mac automatically</small></span>';
        alert('Logic automation failed: ' + error.message);
    }
});

function displaySmartAnalysis(result) {
    const { analysis, summary } = result;
    
    // 1. Vocal Repair Issues
    const repairIssues = document.getElementById('repairIssues');
    repairIssues.innerHTML = '';
    
    if (analysis.vocal_repair.issues.length === 0) {
        repairIssues.innerHTML = '<div class="character-item">✅ No issues detected - clean recording!</div>';
    } else {
        analysis.vocal_repair.issues.forEach(issue => {
            const div = document.createElement('div');
            div.className = 'issue-item';
            div.textContent = issue;
            repairIssues.appendChild(div);
        });
    }
    
    // Add health score
    const healthDiv = document.createElement('div');
    healthDiv.className = 'character-item';
    healthDiv.style.marginTop = '8px';
    healthDiv.innerHTML = `<strong>Health Score:</strong> ${analysis.vocal_repair.health_score}/100`;
    repairIssues.appendChild(healthDiv);
    
    // 2. Voice Character
    const characterAnalysis = document.getElementById('characterAnalysis');
    characterAnalysis.innerHTML = '';
    
    const charDiv = document.createElement('div');
    charDiv.className = 'character-item';
    charDiv.innerHTML = `
        <strong>Voice Type:</strong> ${analysis.vocal_character.brightness}, ${analysis.vocal_character.thickness}<br>
        <strong>Nasality:</strong> ${analysis.vocal_character.nasality}
    `;
    characterAnalysis.appendChild(charDiv);
    
    // Add pitch correction info if available
    if (analysis.pitch_correction) {
        const pitchDiv = document.createElement('div');
        pitchDiv.className = 'character-item';
        pitchDiv.style.marginTop = '8px';
        const needsMelodyne = analysis.pitch_correction.needs_correction ? '✅ Yes' : '❌ No';
        pitchDiv.innerHTML = `
            <strong>🎵 Melodyne:</strong> ${needsMelodyne}<br>
            <strong>Pitch Stability:</strong> ${analysis.pitch_correction.stability_score.toFixed(0)}/100<br>
            <strong>Correction:</strong> ${analysis.pitch_correction.correction_intensity}
        `;
        characterAnalysis.appendChild(pitchDiv);
    }
    
    // Add recommendations
    if (analysis.vocal_character.recommendations.length > 0) {
        const recsTitle = document.createElement('div');
        recsTitle.style.marginTop = '12px';
        recsTitle.style.fontWeight = '600';
        recsTitle.textContent = 'Recommendations:';
        characterAnalysis.appendChild(recsTitle);
        
        analysis.vocal_character.recommendations.forEach(rec => {
            const recDiv = document.createElement('div');
            recDiv.className = 'character-item';
            recDiv.style.marginTop = '4px';
            recDiv.textContent = '• ' + rec;
            characterAnalysis.appendChild(recDiv);
        });
    }
    
    // 3. Dynamics Info
    const dynamicsInfo = document.getElementById('dynamicsInfo');
    dynamicsInfo.innerHTML = '';
    
    const dynDiv = document.createElement('div');
    dynDiv.className = 'dynamics-item';
    dynDiv.innerHTML = `
        <strong>Dynamic Range:</strong> ${analysis.dynamic_consistency.dynamic_range_db.toFixed(1)} dB<br>
        <strong>Consistency Score:</strong> ${analysis.dynamic_consistency.consistency_score.toFixed(0)}/100<br>
        <strong>Suggested Compression:</strong> ${analysis.dynamic_consistency.compression_settings.ratio}:1 @ ${analysis.dynamic_consistency.compression_settings.threshold} dB
    `;
    dynamicsInfo.appendChild(dynDiv);
    
    // 4. Plugin Count
    document.getElementById('pluginCount').textContent = summary.total_plugins;
    
    // 5. Display Plugin Chain in second tab
    displayPluginChainFromAnalysis(result.logic_chain);
}

function displayPluginChainFromAnalysis(chain) {
    // Display in the Plugin Chain tab
    const chainPreview = document.getElementById('pluginChainPreview');
    const settingsDetail = document.getElementById('pluginSettingsDetail');
    
    if (!chainPreview || !settingsDetail) return;
    
    // Clear previous content
    chainPreview.innerHTML = '';
    settingsDetail.innerHTML = '';
    
    // Build chain preview
    let chainHTML = '<div class="plugin-chain-list">';
    chain.forEach((plugin, idx) => {
        chainHTML += `
            <div class="chain-plugin-item" data-plugin-index="${idx}">
                <div class="chain-plugin-number">${idx + 1}</div>
                <div class="chain-plugin-info">
                    <div class="chain-plugin-name">${plugin.name}</div>
                    <div class="chain-plugin-purpose">${plugin.purpose}</div>
                </div>
            </div>
        `;
    });
    chainHTML += '</div>';
    chainPreview.innerHTML = chainHTML;
    
    // Build settings detail
    let settingsHTML = '<div class="plugin-settings-list">';
    chain.forEach((plugin, idx) => {
        settingsHTML += `
            <div class="plugin-settings-card">
                <div class="plugin-settings-header">
                    <span class="plugin-number">${idx + 1}</span>
                    <span class="plugin-name">${plugin.name}</span>
                </div>
                <div class="plugin-settings-purpose">${plugin.purpose}</div>
        `;
        
        if (plugin.settings && Object.keys(plugin.settings).length > 0) {
            settingsHTML += '<div class="plugin-settings-params">';
            for (const [key, value] of Object.entries(plugin.settings)) {
                if (typeof value === 'object' && value !== null) {
                    settingsHTML += `<div class="setting-row"><strong>${key}:</strong></div>`;
                    for (const [subkey, subvalue] of Object.entries(value)) {
                        settingsHTML += `<div class="setting-row sub-setting">• ${subkey}: ${subvalue}</div>`;
                    }
                } else {
                    settingsHTML += `<div class="setting-row"><strong>${key}:</strong> ${value}</div>`;
                }
            }
            settingsHTML += '</div>';
        }
        
        settingsHTML += '</div>';
    });
    settingsHTML += '</div>';
    settingsDetail.innerHTML = settingsHTML;
}

function showSuccessModal(message) {
    // Simple success notification
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
        padding: 32px 48px;
        border-radius: 16px;
        font-size: 18px;
        font-weight: 600;
        z-index: 10000;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        animation: modalPop 0.3s ease;
    `;
    modal.textContent = '✅ ' + message;
    document.body.appendChild(modal);
    
    setTimeout(() => {
        modal.style.animation = 'modalFadeOut 0.3s ease';
        setTimeout(() => modal.remove(), 300);
    }, 3000);
}

// Duplicate event listener removed - handled above with guard to prevent double execution

function displayEnhancedAnalysis(result) {
    const { analysis, summary } = result;
    
    // 1. Vocal Repair Issues
    const repairIssues = document.getElementById('repairIssues');
    repairIssues.innerHTML = '';
    
    if (analysis.vocal_repair.issues.length === 0) {
        repairIssues.innerHTML = '<div class="character-item">✅ No issues detected - clean recording!</div>';
    } else {
        analysis.vocal_repair.issues.forEach(issue => {
            const div = document.createElement('div');
            div.className = 'issue-item';
            div.textContent = issue;
            repairIssues.appendChild(div);
        });
    }
    
    // Add health score
    const healthDiv = document.createElement('div');
    healthDiv.className = 'character-item';
    healthDiv.style.marginTop = '8px';
    healthDiv.innerHTML = `<strong>Health Score:</strong> ${analysis.vocal_repair.health_score}/100`;
    repairIssues.appendChild(healthDiv);
    
    // 2. Voice Character with enhanced info
    const characterAnalysis = document.getElementById('characterAnalysis');
    characterAnalysis.innerHTML = '';
    
    const charDiv = document.createElement('div');
    charDiv.className = 'character-item';
    let charHTML = `
        <strong>Voice Type:</strong> ${analysis.vocal_character.brightness}, ${analysis.vocal_character.thickness}<br>
        <strong>Analysis:</strong> ${analysis.vocal_character.analysis_depth}<br>
    `;
    
    // Add pitch info if available
    if (analysis.pitch_analysis && analysis.pitch_analysis.detected) {
        charHTML += `<strong>Key:</strong> ${analysis.pitch_analysis.key} ${analysis.pitch_analysis.scale}<br>`;
        charHTML += `<strong>Pitch Stability:</strong> ${analysis.pitch_analysis.needs_strong_tuning ? 'Needs correction' : 'Good'}`;
    }
    
    // Add formant info if available
    if (analysis.formant_analysis && analysis.formant_analysis.detected) {
        charHTML += `<br><strong>Formants:</strong> F1=${analysis.formant_analysis.F1.toFixed(0)}Hz, F2=${analysis.formant_analysis.F2.toFixed(0)}Hz`;
        charHTML += `<br><strong>Vocal Character:</strong> ${analysis.formant_analysis.vocal_character}`;
    }
    
    // Add emotion if available
    if (analysis.emotion) {
        charHTML += `<br><strong>Emotion/Vibe:</strong> ${analysis.emotion.emotion} (${analysis.emotion.brightness})`;
    }
    
    charDiv.innerHTML = charHTML;
    characterAnalysis.appendChild(charDiv);
    
    // Add recommendations
    if (analysis.vocal_character.recommendations.length > 0) {
        const recsTitle = document.createElement('div');
        recsTitle.style.marginTop = '12px';
        recsTitle.style.fontWeight = '600';
        recsTitle.textContent = 'Recommendations:';
        characterAnalysis.appendChild(recsTitle);
        
        analysis.vocal_character.recommendations.forEach(rec => {
            const recDiv = document.createElement('div');
            recDiv.className = 'character-item';
            recDiv.style.marginTop = '4px';
            recDiv.textContent = '• ' + rec;
            characterAnalysis.appendChild(recDiv);
        });
    }
    
    // 3. Dynamics Info with timing if available
    const dynamicsInfo = document.getElementById('dynamicsInfo');
    dynamicsInfo.innerHTML = '';
    
    const dynDiv = document.createElement('div');
    dynDiv.className = 'dynamics-item';
    let dynHTML = `
        <strong>Dynamic Range:</strong> ${analysis.dynamic_consistency.dynamic_range_db.toFixed(1)} dB<br>
        <strong>Consistency Score:</strong> ${analysis.dynamic_consistency.consistency_score.toFixed(0)}/100<br>
        <strong>Compression:</strong> ${analysis.dynamic_consistency.compression_settings.ratio}:1 @ ${analysis.dynamic_consistency.compression_settings.threshold} dB
    `;
    
    // Add timing info if available
    if (analysis.timing_analysis) {
        dynHTML += `<br><strong>Tempo:</strong> ${analysis.timing_analysis.tempo.toFixed(1)} BPM`;
        dynHTML += `<br><strong>Timing:</strong> ${analysis.timing_analysis.timing_quality}`;
        dynHTML += `<br><strong>Delay Sync:</strong> ${analysis.timing_analysis.recommended_delay} note`;
    }
    
    dynDiv.innerHTML = dynHTML;
    dynamicsInfo.appendChild(dynDiv);
    
    // 4. Plugin Count with breakdown
    const pluginCount = document.getElementById('pluginCount');
    const wavesCount = result.logic_chain.filter(p => p.type === 'waves').length;
    const melodyneCount = result.logic_chain.filter(p => p.type === 'melodyne').length;
    const logicCount = result.logic_chain.filter(p => p.type === 'logic').length;
    
    pluginCount.innerHTML = `${result.logic_chain.length} 
        <small style="font-size: 12px; font-weight: 400; color: rgba(255,255,255,0.7);">
            (${wavesCount} Waves, ${melodyneCount} Melodyne, ${logicCount} Logic)
        </small>`;
}

// ============================================
// SETTINGS BUTTON - API KEY MANAGEMENT
// ============================================

const settingsBtn = document.getElementById('settingsBtn');
if (settingsBtn) {
    settingsBtn.addEventListener('click', () => {
        showApiKeySetup(true); // true = show even if key exists
    });
}

// Enhanced showApiKeySetup to support viewing existing status
async function showApiKeySetupEnhanced(forceShow = false) {
    const hasApiKey = await ipcRenderer.invoke('check-api-key');
    
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        backdrop-filter: blur(10px);
    `;
    
    const statusText = hasApiKey 
        ? '<div style="color: #00ff88; margin-bottom: 20px; font-size: 16px;">✅ API Key is configured</div>'
        : '<div style="color: #ff6b6b; margin-bottom: 20px; font-size: 16px;">❌ No API Key found</div>';
    
    modal.innerHTML = `
        <div style="
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            border: 2px solid #667eea;
            border-radius: 20px;
            padding: 40px;
            max-width: 600px;
            box-shadow: 0 20px 60px rgba(102, 126, 234, 0.3);
        ">
            <h2 style="color: #fff; margin-bottom: 10px;">⚙️ Settings & API Configuration</h2>
            ${statusText}
            <p style="color: #a0a0a0; margin-bottom: 25px;">
                To use AI-powered Logic Pro automation, you need a Claude API key from Anthropic.
            </p>
            
            <div style="
                background: rgba(102, 126, 234, 0.1);
                border: 1px solid rgba(102, 126, 234, 0.3);
                border-radius: 12px;
                padding: 20px;
                margin-bottom: 25px;
            ">
                <h3 style="margin-top: 0; color: #667eea; font-size: 16px;">📝 Get Your API Key:</h3>
                <ol style="color: #c0c0c0; line-height: 1.8; margin: 10px 0;">
                    <li>Visit <a href="https://console.anthropic.com/" target="_blank" style="color: #667eea; text-decoration: none;">console.anthropic.com</a></li>
                    <li>Sign up or log in to your account</li>
                    <li>Navigate to <strong>API Keys</strong> section</li>
                    <li>Click <strong>Create Key</strong></li>
                    <li>Copy your key (starts with "sk-ant-")</li>
                </ol>
            </div>
            
            <div style="margin-bottom: 25px;">
                <label style="
                    display: block;
                    color: #fff;
                    margin-bottom: 10px;
                    font-weight: 600;
                ">
                    ${hasApiKey ? 'Update Your' : 'Paste Your'} API Key:
                </label>
                <input 
                    type="password" 
                    id="apiKeyInputSettings" 
                    placeholder="sk-ant-api03-..." 
                    style="
                        width: 100%;
                        padding: 15px;
                        background: rgba(0, 0, 0, 0.3);
                        border: 2px solid rgba(102, 126, 234, 0.3);
                        border-radius: 10px;
                        color: #fff;
                        font-size: 14px;
                        font-family: 'Courier New', monospace;
                    "
                />
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button id="closeSettingsModal" 
                    style="
                        padding: 12px 24px;
                        background: rgba(255, 255, 255, 0.1);
                        border: 1px solid rgba(255, 255, 255, 0.2);
                        border-radius: 10px;
                        color: #fff;
                        cursor: pointer;
                        font-weight: 600;
                        transition: all 0.3s ease;
                    "
                >
                    ${hasApiKey ? 'Close' : 'Skip for Now'}
                </button>
                <button id="saveApiKeySettings" 
                    style="
                        padding: 12px 24px;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        border: none;
                        border-radius: 10px;
                        color: #fff;
                        cursor: pointer;
                        font-weight: 600;
                        transition: all 0.3s ease;
                    "
                >
                    💾 Save API Key
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    setTimeout(() => document.getElementById('apiKeyInputSettings').focus(), 100);
    
    document.getElementById('closeSettingsModal').addEventListener('click', () => {
        document.body.removeChild(modal);
    });
    
    document.getElementById('saveApiKeySettings').addEventListener('click', async () => {
        const apiKey = document.getElementById('apiKeyInputSettings').value.trim();
        
        if (!apiKey) {
            if (hasApiKey) {
                // Just close if they don't want to update
                document.body.removeChild(modal);
                return;
            } else {
                alert('❌ Please enter an API key');
                return;
            }
        }
        
        if (!apiKey.startsWith('sk-ant-')) {
            alert('❌ Invalid API key format. Should start with "sk-ant-"');
            return;
        }
        
        const saved = await ipcRenderer.invoke('save-api-key', apiKey);
        
        if (saved) {
            document.body.removeChild(modal);
            updateStatus('✅ API key saved successfully!');
        } else {
            alert('❌ Error saving API key');
        }
    });
}

// ============================================
// IMPROVED ERROR HANDLING FOR AUDIO LOADING
// ============================================


