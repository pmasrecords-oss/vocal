#!/usr/bin/env python3
"""
AI Vocal Analyzer + Logic Pro Controller
Analyzes vocals and controls Logic Pro with Waves & Melodyne plugins
Built specifically for YOUR voice - no reference needed!
"""

import json
import numpy as np
import librosa
import sys
import os
from pathlib import Path

class VocalAnalyzer:
    """Analyze vocal tracks and generate Logic Pro automation commands using Waves & Melodyne"""
    
    def __init__(self):
        self.sample_rate = 44100
        self.analysis = {}
        
    def analyze_vocal(self, audio_path, genre=None):
        """
        Complete vocal analysis - no reference needed!
        Returns automation commands for Logic Pro with Waves & Melodyne
        """
        print(f"🎤 Analyzing: {Path(audio_path).name}", file=sys.stderr)
        print(f"🎼 Genre: {genre or 'Auto-detect'}", file=sys.stderr)
        
        # Load audio
        y, sr = librosa.load(audio_path, sr=self.sample_rate)
        self.sample_rate = sr
        
        # Run all analyses
        self.analysis = {
            'vocal_repair': self._analyze_vocal_repair(y, sr),
            'vocal_character': self._analyze_vocal_character(y, sr),
            'dynamic_consistency': self._analyze_dynamics(y, sr),
            'genre_processing': self._get_genre_settings(genre, y, sr),
            'one_click_pro': self._generate_pro_preset(y, sr),
            'pitch_correction': self._analyze_pitch(y, sr)  # For Melodyne
        }
        
        # Generate Logic Pro commands with Waves & Melodyne
        logic_chain = self._build_waves_melodyne_chain()
        
        return {
            'analysis': self.analysis,
            'logic_chain': logic_chain,
            'summary': self._generate_summary()
        }
    
    def _analyze_vocal_repair(self, y, sr):
        """Detect and fix common vocal issues"""
        issues = []
        fixes = []
        
        # 1. Detect Clipping
        clipping_threshold = 0.99
        clipped_samples = np.sum(np.abs(y) > clipping_threshold)
        if clipped_samples > 0:
            issues.append(f"⚠️  Clipping detected ({clipped_samples} samples)")
            fixes.append({
                'issue': 'clipping',
                'plugin': 'Limiter',
                'settings': {'ceiling': -0.3, 'release': 50}
            })
        
        # 2. Detect Plosives (low freq bumps)
        stft = librosa.stft(y)
        low_freq_energy = np.abs(stft[:20, :])  # Below ~200Hz
        plosive_frames = np.where(np.max(low_freq_energy, axis=0) > np.median(low_freq_energy) * 5)[0]
        
        if len(plosive_frames) > 10:
            issues.append(f"⚠️  Plosives detected ({len(plosive_frames)} instances)")
            fixes.append({
                'issue': 'plosives',
                'plugin': 'Channel EQ',
                'settings': {
                    'type': 'high_pass',
                    'frequency': 80,
                    'slope': 24
                }
            })
        
        # 3. Detect Harsh Sibilance
        high_freq_energy = np.abs(stft[-100:, :])  # Above ~5kHz
        sibilant_frames = np.where(np.max(high_freq_energy, axis=0) > np.median(high_freq_energy) * 4)[0]
        
        if len(sibilant_frames) > 20:
            # Find exact sibilance frequency
            sibilance_freq = self._detect_sibilance_frequency(y, sr)
            issues.append(f"⚠️  Harsh sibilance at {sibilance_freq}Hz")
            fixes.append({
                'issue': 'sibilance',
                'plugin': 'DeEsser',
                'settings': {
                    'frequency': sibilance_freq,
                    'amount': 6.0
                }
            })
        
        # 4. Detect Background Noise
        noise_floor = np.percentile(np.abs(y), 5)
        if noise_floor > 0.01:
            issues.append(f"⚠️  Background noise detected (floor: {noise_floor:.4f})")
            fixes.append({
                'issue': 'noise',
                'plugin': 'Noise Gate',
                'settings': {
                    'threshold': -45,
                    'attack': 5,
                    'release': 150
                }
            })
        
        # 5. Detect Breaths
        rms = librosa.feature.rms(y=y)[0]
        breath_threshold = np.median(rms) * 0.3
        breath_frames = np.where((rms > 0) & (rms < breath_threshold))[0]
        
        if len(breath_frames) > 50:
            issues.append(f"⚠️  Loud breaths detected")
            # Handled by noise gate above
        
        return {
            'issues': issues,
            'fixes': fixes,
            'health_score': max(0, 100 - len(issues) * 15)
        }
    
    def _analyze_vocal_character(self, y, sr):
        """Analyze the unique characteristics of this voice"""
        
        # 1. Brightness Analysis
        spectral_centroid = np.mean(librosa.feature.spectral_centroid(y=y, sr=sr))
        brightness = 'bright' if spectral_centroid > 2000 else 'dark' if spectral_centroid < 1500 else 'balanced'
        
        # 2. Thinness/Thickness
        low_energy = np.mean(np.abs(librosa.stft(y)[:50, :]))
        mid_energy = np.mean(np.abs(librosa.stft(y)[50:200, :]))
        thickness = 'thin' if low_energy < mid_energy * 0.5 else 'thick' if low_energy > mid_energy * 1.5 else 'balanced'
        
        # 3. Nasality Detection (mid frequencies)
        nasal_freq_range = librosa.note_to_hz(['E4', 'A4'])  # 330-440Hz
        nasal_bins = librosa.hz_to_mel(nasal_freq_range)
        mel_spec = librosa.feature.melspectrogram(y=y, sr=sr)
        nasal_energy = np.mean(mel_spec[int(nasal_bins[0]):int(nasal_bins[1]), :])
        nasality = 'nasal' if nasal_energy > np.median(mel_spec) * 1.5 else 'clear'
        
        # 4. Problem Frequencies
        problem_freqs = []
        fft = np.abs(librosa.stft(y))
        freq_bins = librosa.fft_frequencies(sr=sr)
        
        # Check common problem areas
        problem_ranges = [
            (200, 400, 'muddy low-mids'),
            (2000, 3500, 'harsh mids'),
            (8000, 12000, 'excessive air/brightness')
        ]
        
        for low, high, desc in problem_ranges:
            low_bin = np.argmin(np.abs(freq_bins - low))
            high_bin = np.argmin(np.abs(freq_bins - high))
            energy = np.mean(fft[low_bin:high_bin, :])
            median_energy = np.median(fft)
            
            if energy > median_energy * 2:
                peak_bin = low_bin + np.argmax(np.mean(fft[low_bin:high_bin, :], axis=1))
                peak_freq = int(freq_bins[peak_bin])
                problem_freqs.append({
                    'frequency': peak_freq,
                    'description': desc,
                    'severity': 'high'
                })
        
        # 5. Sweet Spot (resonant frequencies)
        sweet_spots = []
        for i in range(50, len(freq_bins) - 50, 10):
            if i < len(fft):
                local_energy = np.mean(fft[i-5:i+5, :])
                if local_energy > np.median(fft) * 2.5:
                    sweet_spots.append(int(freq_bins[i]))
        
        # Generate recommendations
        recommendations = []
        eq_settings = []
        
        if brightness == 'bright':
            recommendations.append("Your voice is bright - reduce 3-5kHz harshness")
            eq_settings.append({'freq': 3500, 'gain': -2.5, 'q': 1.5, 'type': 'bell'})
        elif brightness == 'dark':
            recommendations.append("Your voice is dark - add air around 10kHz")
            eq_settings.append({'freq': 10000, 'gain': 2.0, 'q': 1.0, 'type': 'high_shelf'})
        
        if thickness == 'thin':
            recommendations.append("Your voice is thin - boost low-mids at 200-300Hz")
            eq_settings.append({'freq': 250, 'gain': 3.0, 'q': 1.2, 'type': 'bell'})
        elif thickness == 'thick':
            recommendations.append("Your voice is thick - reduce muddiness at 300Hz")
            eq_settings.append({'freq': 300, 'gain': -3.0, 'q': 1.0, 'type': 'bell'})
        
        if nasality == 'nasal':
            recommendations.append("Nasal tone detected - cut 400-600Hz")
            eq_settings.append({'freq': 500, 'gain': -2.0, 'q': 2.0, 'type': 'bell'})
        
        for prob in problem_freqs:
            recommendations.append(f"Problem at {prob['frequency']}Hz - {prob['description']}")
            eq_settings.append({'freq': prob['frequency'], 'gain': -3.5, 'q': 2.5, 'type': 'bell'})
        
        for sweet in sweet_spots[:2]:  # Top 2 sweet spots
            recommendations.append(f"Sweet spot at {sweet}Hz - boost for presence")
            eq_settings.append({'freq': sweet, 'gain': 2.5, 'q': 1.8, 'type': 'bell'})
        
        return {
            'brightness': brightness,
            'thickness': thickness,
            'nasality': nasality,
            'problem_frequencies': problem_freqs,
            'sweet_spots': sweet_spots[:3],
            'recommendations': recommendations,
            'eq_settings': eq_settings
        }
    
    def _analyze_dynamics(self, y, sr):
        """Analyze dynamic range and consistency"""
        
        # RMS energy over time
        rms = librosa.feature.rms(y=y, frame_length=2048, hop_length=512)[0]
        rms_db = librosa.amplitude_to_db(rms, ref=np.max)
        
        # Dynamic range
        dynamic_range = np.max(rms_db) - np.min(rms_db[rms_db > -60])
        
        # Consistency (standard deviation)
        consistency = np.std(rms_db[rms_db > -60])
        
        # Find problem areas
        quiet_sections = np.where(rms_db < np.median(rms_db) - 12)[0]
        loud_sections = np.where(rms_db > np.median(rms_db) + 12)[0]
        
        # Compression recommendations
        if dynamic_range > 30:
            severity = 'high'
            ratio = 6.0
            threshold = -18
        elif dynamic_range > 20:
            severity = 'medium'
            ratio = 4.0
            threshold = -15
        else:
            severity = 'low'
            ratio = 2.5
            threshold = -12
        
        # Attack/Release based on consistency
        if consistency > 8:
            attack = 5  # Fast attack for inconsistent vocals
            release = 50
        else:
            attack = 15  # Slower for consistent vocals
            release = 100
        
        return {
            'dynamic_range_db': float(dynamic_range),
            'consistency_score': float(100 - consistency * 5),
            'quiet_sections': len(quiet_sections),
            'loud_sections': len(loud_sections),
            'compression_settings': {
                'ratio': ratio,
                'threshold': threshold,
                'attack': attack,
                'release': release,
                'knee': 3.0,
                'makeup_gain': 3.0
            },
            'needs_automation': dynamic_range > 25 or consistency > 10
        }
    
    def _get_genre_settings(self, genre, y, sr):
        """Genre-specific processing chains"""
        
        # Auto-detect if not provided
        if not genre:
            genre = self._detect_genre(y, sr)
        
        genre_presets = {
            'trap': {
                'description': 'Modern trap vocals - punchy and compressed',
                'chain': [
                    {'plugin': 'Noise Gate', 'threshold': -45, 'attack': 3, 'release': 100},
                    {'plugin': 'Channel EQ', 'cuts': [
                        {'freq': 80, 'type': 'high_pass', 'slope': 24},
                        {'freq': 350, 'gain': -3, 'q': 1.5}
                    ], 'boosts': [
                        {'freq': 3000, 'gain': 3, 'q': 1.2},
                        {'freq': 8000, 'gain': 2, 'q': 0.8}
                    ]},
                    {'plugin': 'Compressor', 'ratio': 6, 'threshold': -20, 'attack': 3, 'release': 50},
                    {'plugin': 'DeEsser', 'frequency': 7000, 'amount': 6},
                    {'plugin': 'Limiter', 'ceiling': -0.3}
                ],
                'reverb': {'type': 'small_room', 'decay': 0.8, 'mix': 12},
                'delay': {'time': '1/8', 'feedback': 20, 'mix': 15}
            },
            'drill': {
                'description': 'UK Drill - dark, aggressive, compressed',
                'chain': [
                    {'plugin': 'Noise Gate', 'threshold': -40, 'attack': 2, 'release': 80},
                    {'plugin': 'Channel EQ', 'cuts': [
                        {'freq': 100, 'type': 'high_pass', 'slope': 24},
                        {'freq': 250, 'gain': -4, 'q': 1.8},
                        {'freq': 3500, 'gain': -2, 'q': 2.0}
                    ], 'boosts': [
                        {'freq': 150, 'gain': 2, 'q': 1.5},
                        {'freq': 5000, 'gain': 4, 'q': 1.0}
                    ]},
                    {'plugin': 'Compressor', 'ratio': 8, 'threshold': -22, 'attack': 1, 'release': 40},
                    {'plugin': 'DeEsser', 'frequency': 6500, 'amount': 8},
                    {'plugin': 'Limiter', 'ceiling': -0.1}
                ],
                'reverb': {'type': 'dark_hall', 'decay': 1.5, 'mix': 8},
                'delay': {'time': '1/16', 'feedback': 15, 'mix': 10}
            },
            'rnb': {
                'description': 'R&B/Soul - smooth, warm, airy',
                'chain': [
                    {'plugin': 'Noise Gate', 'threshold': -50, 'attack': 8, 'release': 150},
                    {'plugin': 'Channel EQ', 'cuts': [
                        {'freq': 70, 'type': 'high_pass', 'slope': 18},
                        {'freq': 400, 'gain': -2, 'q': 1.2}
                    ], 'boosts': [
                        {'freq': 200, 'gain': 2, 'q': 1.5},
                        {'freq': 4000, 'gain': 2.5, 'q': 1.0},
                        {'freq': 12000, 'gain': 3, 'q': 0.7}
                    ]},
                    {'plugin': 'Compressor', 'ratio': 3, 'threshold': -15, 'attack': 12, 'release': 120},
                    {'plugin': 'DeEsser', 'frequency': 7500, 'amount': 4},
                    {'plugin': 'Exciter', 'harmonics': 'warm'}
                ],
                'reverb': {'type': 'large_hall', 'decay': 2.2, 'mix': 25},
                'delay': {'time': '1/4', 'feedback': 30, 'mix': 20}
            },
            'pop': {
                'description': 'Modern pop - bright, present, polished',
                'chain': [
                    {'plugin': 'Noise Gate', 'threshold': -48, 'attack': 5, 'release': 120},
                    {'plugin': 'Channel EQ', 'cuts': [
                        {'freq': 80, 'type': 'high_pass', 'slope': 24},
                        {'freq': 300, 'gain': -2.5, 'q': 1.3}
                    ], 'boosts': [
                        {'freq': 2500, 'gain': 2.5, 'q': 1.2},
                        {'freq': 6000, 'gain': 2, 'q': 1.0},
                        {'freq': 10000, 'gain': 2.5, 'q': 0.8}
                    ]},
                    {'plugin': 'Compressor', 'ratio': 4, 'threshold': -18, 'attack': 8, 'release': 80},
                    {'plugin': 'DeEsser', 'frequency': 7200, 'amount': 5},
                    {'plugin': 'Limiter', 'ceiling': -0.3}
                ],
                'reverb': {'type': 'bright_plate', 'decay': 1.5, 'mix': 18},
                'delay': {'time': '1/8', 'feedback': 25, 'mix': 18}
            },
            'rock': {
                'description': 'Rock vocals - raw, powerful, present',
                'chain': [
                    {'plugin': 'Channel EQ', 'cuts': [
                        {'freq': 100, 'type': 'high_pass', 'slope': 18},
                        {'freq': 500, 'gain': -2, 'q': 1.0}
                    ], 'boosts': [
                        {'freq': 1500, 'gain': 2, 'q': 1.5},
                        {'freq': 4000, 'gain': 3, 'q': 1.2}
                    ]},
                    {'plugin': 'Compressor', 'ratio': 3, 'threshold': -12, 'attack': 15, 'release': 150},
                    {'plugin': 'DeEsser', 'frequency': 6000, 'amount': 3},
                    {'plugin': 'Exciter', 'harmonics': 'aggressive'}
                ],
                'reverb': {'type': 'medium_hall', 'decay': 1.8, 'mix': 22},
                'delay': {'time': 'dotted_8th', 'feedback': 35, 'mix': 25}
            }
        }
        
        return genre_presets.get(genre.lower(), genre_presets['pop'])
    
    def _generate_pro_preset(self, y, sr):
        """One-click professional preset - works on 80% of vocals"""
        
        return {
            'description': 'Professional vocal chain - universal starting point',
            'chain': [
                {
                    'name': 'High Pass Filter',
                    'plugin': 'Channel EQ',
                    'type': 'high_pass',
                    'frequency': 80,
                    'slope': 24,
                    'reason': 'Remove sub-bass rumble and mud'
                },
                {
                    'name': 'Problem Frequency Cut',
                    'plugin': 'Channel EQ',
                    'type': 'bell',
                    'frequency': 300,
                    'gain': -3,
                    'q': 1.5,
                    'reason': 'Reduce common muddiness'
                },
                {
                    'name': 'Presence Boost',
                    'plugin': 'Channel EQ',
                    'type': 'bell',
                    'frequency': 3000,
                    'gain': 2.5,
                    'q': 1.2,
                    'reason': 'Add clarity and presence'
                },
                {
                    'name': 'Air Boost',
                    'plugin': 'Channel EQ',
                    'type': 'high_shelf',
                    'frequency': 10000,
                    'gain': 2,
                    'reason': 'Add air and sparkle'
                },
                {
                    'name': 'Main Compression',
                    'plugin': 'Compressor',
                    'ratio': 4,
                    'threshold': -18,
                    'attack': 10,
                    'release': 80,
                    'knee': 3,
                    'makeup_gain': 3,
                    'reason': 'Even out dynamics'
                },
                {
                    'name': 'De-Essing',
                    'plugin': 'DeEsser',
                    'frequency': 7000,
                    'amount': 5,
                    'reason': 'Tame harsh sibilance'
                },
                {
                    'name': 'Subtle Saturation',
                    'plugin': 'Exciter',
                    'harmonics': 'warm',
                    'amount': 15,
                    'reason': 'Add warmth and character'
                },
                {
                    'name': 'Final Limiting',
                    'plugin': 'Limiter',
                    'ceiling': -0.3,
                    'release': 50,
                    'reason': 'Prevent clipping'
                }
            ],
            'effects': {
                'reverb': {
                    'type': 'medium_plate',
                    'decay': 1.5,
                    'pre_delay': 20,
                    'mix': 15
                },
                'delay': {
                    'time': '1/8',
                    'feedback': 20,
                    'filter': 'high_pass',
                    'mix': 12
                }
            }
        }
    
    def _detect_sibilance_frequency(self, y, sr):
        """Find the exact frequency of sibilance (usually 5-9kHz)"""
        stft = np.abs(librosa.stft(y))
        freq_bins = librosa.fft_frequencies(sr=sr)
        
        # Look in sibilance range
        sibilance_range = (5000, 9000)
        low_bin = np.argmin(np.abs(freq_bins - sibilance_range[0]))
        high_bin = np.argmin(np.abs(freq_bins - sibilance_range[1]))
        
        # Find peak energy in this range
        sibilance_spectrum = stft[low_bin:high_bin, :]
        peak_bin = low_bin + np.argmax(np.mean(sibilance_spectrum, axis=1))
        
        return int(freq_bins[peak_bin])
    
    def _detect_genre(self, y, sr):
        """Simple genre detection based on characteristics"""
        # This is simplified - in production you'd use ML
        
        # Analyze tempo - use feature.tempo for librosa 0.10.0+
        try:
            tempo = librosa.feature.tempo(y=y, sr=sr)[0]
        except AttributeError:
            tempo = librosa.beat.tempo(y=y, sr=sr)[0]
        
        # Analyze brightness
        spectral_centroid = np.mean(librosa.feature.spectral_centroid(y=y, sr=sr))
        
        # Simple heuristics
        if tempo > 140 and spectral_centroid > 2500:
            return 'trap'
        elif tempo > 130 and spectral_centroid < 2000:
            return 'drill'
        elif tempo < 100 and spectral_centroid > 2000:
            return 'rnb'
        elif tempo > 100 and tempo < 130:
            return 'pop'
        else:
            return 'pop'  # Default
    
    def _analyze_pitch(self, y, sr):
        """Analyze pitch for Melodyne settings"""
        # Extract pitch contour
        pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
        
        # Get pitch stability (how much it wanders)
        pitch_values = []
        for t in range(pitches.shape[1]):
            index = magnitudes[:, t].argmax()
            pitch = pitches[index, t]
            if pitch > 0:
                pitch_values.append(pitch)
        
        if len(pitch_values) < 10:
            pitch_stability = 100  # No pitch detected, likely instrumental
        else:
            pitch_std = np.std(pitch_values)
            pitch_stability = max(0, 100 - (pitch_std / 10))
        
        # Determine correction intensity
        if pitch_stability > 85:
            correction_intensity = 'subtle'
            melodyne_amount = 20
        elif pitch_stability > 70:
            correction_intensity = 'moderate'
            melodyne_amount = 50
        else:
            correction_intensity = 'heavy'
            melodyne_amount = 80
        
        return {
            'stability_score': float(pitch_stability),
            'correction_intensity': correction_intensity,
            'melodyne_amount': melodyne_amount,
            'needs_correction': pitch_stability < 90
        }
    
    def _build_waves_melodyne_chain(self):
        """Build complete Logic Pro automation chain using Waves & Melodyne plugins"""
        chain = []
        
        # STEP 1: Melodyne for pitch correction (if needed)
        pitch = self.analysis['pitch_correction']
        if pitch['needs_correction']:
            chain.append({
                'order': 1,
                'category': 'pitch',
                'plugin': 'Melodyne',
                'plugin_full_name': 'Celemony Melodyne',
                'settings': {
                    'correction_amount': pitch['melodyne_amount'],
                    'formant_correction': True,
                    'intensity': pitch['correction_intensity']
                },
                'reason': f"Pitch correction ({pitch['correction_intensity']}) - Stability: {pitch['stability_score']:.0f}/100"
            })
        
        # STEP 2: Waves Renaissance Channel (replaces Logic Channel EQ)
        character = self.analysis['vocal_character']
        eq_bands = character['eq_settings'] if character['eq_settings'] else []
        
        chain.append({
            'order': 2,
            'category': 'eq',
            'plugin': 'Waves Renaissance Channel',
            'plugin_full_name': 'Waves Renaissance Channel',
            'settings': {
                'high_pass': 80,
                'high_pass_slope': 24,
                'eq_bands': eq_bands,
                'phase': 'linear'
            },
            'reason': f"Personalized EQ for {character['brightness']}, {character['thickness']} voice"
        })
        
        # STEP 3: Waves CLA-76 Compressor (for character)
        dynamics = self.analysis['dynamic_consistency']
        comp = dynamics['compression_settings']
        
        # Choose compressor based on genre
        genre = self.analysis['genre_processing']
        genre_name = genre.get('description', '').lower()
        
        if 'trap' in genre_name or 'drill' in genre_name:
            # Aggressive compression for rap
            chain.append({
                'order': 3,
                'category': 'compression',
                'plugin': 'Waves CLA-76',
                'plugin_full_name': 'Waves CLA-76 Compressor',
                'settings': {
                    'ratio': 'All Buttons' if comp['ratio'] >= 8 else '8:1' if comp['ratio'] >= 8 else '4:1',
                    'attack': 'fast',
                    'release': 'fast',
                    'input': comp['threshold'] + 20,  # Drive it harder
                    'output': comp['makeup_gain']
                },
                'reason': 'Aggressive rap compression (CLA-76 All Buttons mode)'
            })
        else:
            # Smooth compression for singing
            chain.append({
                'order': 3,
                'category': 'compression',
                'plugin': 'Waves CLA-2A',
                'plugin_full_name': 'Waves CLA-2A Compressor/Limiter',
                'settings': {
                    'peak_reduction': abs(comp['threshold']) - 10,
                    'gain': comp['makeup_gain'] + 5,
                    'mode': 'compress'
                },
                'reason': 'Smooth optical compression (CLA-2A)'
            })
        
        # STEP 4: Waves Renaissance DeEsser
        repair = self.analysis['vocal_repair']
        sibilance_fix = next((fix for fix in repair['fixes'] if fix['issue'] == 'sibilance'), None)
        
        if sibilance_fix:
            chain.append({
                'order': 4,
                'category': 'deess',
                'plugin': 'Waves Renaissance DeEsser',
                'plugin_full_name': 'Waves Renaissance DeEsser',
                'settings': {
                    'frequency': sibilance_fix['settings']['frequency'],
                    'threshold': -20,
                    'attenuation': sibilance_fix['settings']['amount']
                },
                'reason': f"Remove harsh sibilance at {sibilance_fix['settings']['frequency']}Hz"
            })
        
        # STEP 5: Waves Vitamin (Harmonic Enhancement)
        # Adds color and character
        chain.append({
            'order': 5,
            'category': 'saturation',
            'plugin': 'Waves Vitamin',
            'plugin_full_name': 'Waves Vitamin Sonic Enhancer',
            'settings': {
                'bass': 0,  # Don't add low end
                'mid': 2,   # Slight mid presence
                'high': 3,  # Add air and sparkle
                'punch': 4  # Character
            },
            'reason': 'Add harmonic richness and character (Waves Vitamin)'
        })
        
        # STEP 6: Waves F6 Floating-Band Dynamic EQ (for problem frequencies)
        problem_freqs = character['problem_frequencies']
        if problem_freqs:
            chain.append({
                'order': 6,
                'category': 'dynamic_eq',
                'plugin': 'Waves F6',
                'plugin_full_name': 'Waves F6 Floating-Band Dynamic EQ',
                'settings': {
                    'bands': [
                        {
                            'frequency': prob['frequency'],
                            'threshold': -15,
                            'range': -6,
                            'attack': 10,
                            'release': 100
                        } for prob in problem_freqs[:3]  # Top 3 problem areas
                    ]
                },
                'reason': 'Dynamic control of problem frequencies (Waves F6)'
            })
        
        # STEP 7: Waves H-Delay (for depth and width)
        genre_settings = self.analysis['genre_processing']
        delay_settings = genre_settings.get('delay', {})
        
        chain.append({
            'order': 7,
            'category': 'delay',
            'plugin': 'Waves H-Delay',
            'plugin_full_name': 'Waves H-Delay Hybrid Delay',
            'settings': {
                'time': delay_settings.get('time', '1/8'),
                'feedback': delay_settings.get('feedback', 20),
                'mix': delay_settings.get('mix', 15),
                'filter_type': 'high_pass',
                'filter_frequency': 500,
                'analog_mode': True
            },
            'reason': 'Add depth and width (Waves H-Delay)'
        })
        
        # STEP 8: Waves Abbey Road Reverb Plates
        reverb_settings = genre_settings.get('reverb', {})
        
        chain.append({
            'order': 8,
            'category': 'reverb',
            'plugin': 'Waves Abbey Road Reverb Plates',
            'plugin_full_name': 'Waves Abbey Road Reverb Plates',
            'settings': {
                'plate_type': 'Plate 2',  # Bright plate
                'decay': reverb_settings.get('decay', 1.5),
                'pre_delay': reverb_settings.get('pre_delay', 20),
                'mix': reverb_settings.get('mix', 18),
                'filter': 'high_pass',
                'filter_frequency': 300
            },
            'reason': f"Professional reverb ({reverb_settings.get('type', 'plate')})"
        })
        
        # STEP 9: Waves L2 Ultramaximizer (Final Limiting)
        chain.append({
            'order': 9,
            'category': 'limiting',
            'plugin': 'Waves L2',
            'plugin_full_name': 'Waves L2 Ultramaximizer',
            'settings': {
                'threshold': -0.3,
                'release': 'Auto Release Control (ARC)',
                'out_ceiling': -0.1,
                'quantize': 24
            },
            'reason': 'Final limiting - prevent clipping (Waves L2)'
        })
        
        return chain
    
    def _generate_summary(self):
        """Generate human-readable summary"""
        repair = self.analysis['vocal_repair']
        character = self.analysis['vocal_character']
        dynamics = self.analysis['dynamic_consistency']
        pitch = self.analysis['pitch_correction']
        
        summary = {
            'overall_health': repair['health_score'],
            'issues_found': len(repair['issues']),
            'voice_type': f"{character['brightness']}, {character['thickness']}",
            'dynamic_range': dynamics['dynamic_range_db'],
            'pitch_stability': pitch['stability_score'],
            'recommendations_count': len(character['recommendations']),
            'total_plugins': len(self._build_waves_melodyne_chain())
        }
        
        return summary


def main():
    """Main entry point"""
    if len(sys.argv) < 2:
        print("Usage: python vocal_analyzer.py <audio_file> [genre]")
        sys.exit(1)
    
    audio_path = sys.argv[1]
    genre = sys.argv[2] if len(sys.argv) > 2 else None
    
    if not os.path.exists(audio_path):
        print(f"Error: File not found: {audio_path}")
        sys.exit(1)
    
    # Run analysis
    analyzer = VocalAnalyzer()
    result = analyzer.analyze_vocal(audio_path, genre)
    
    # Convert numpy types to native Python types for JSON serialization
    def convert_numpy_types(obj):
        if isinstance(obj, np.bool_):
            return bool(obj)
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {key: convert_numpy_types(value) for key, value in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [convert_numpy_types(item) for item in obj]
        else:
            return obj
    
    result = convert_numpy_types(result)
    
    # Output as JSON for the app to read - ensure only JSON is printed to stdout
    try:
        json_output = json.dumps(result, indent=2)
        print(json_output, flush=True)
    except Exception as e:
        error_result = {
            "error": str(e),
            "type": "json_serialization_error"
        }
        print(json.dumps(error_result), flush=True)
        sys.exit(1)




if __name__ == '__main__':
    main()
