#!/usr/bin/env python3
"""
Logic Pro Plugin Chain Automation with AI Vision
Uses AI vision + mouse/keyboard control to automatically load plugins AND set parameters
"""

import json
import time
import sys
import subprocess
import os
import base64
from io import BytesIO

try:
    import pyautogui
    import pyperclip
    from PIL import Image
    import anthropic
except ImportError:
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyautogui", "pyperclip", "pillow", "anthropic"])
    import pyautogui
    import pyperclip
    from PIL import Image
    import anthropic

# Configuration
CLICK_DELAY = 0.3  # Delay between clicks
TYPE_DELAY = 0.05   # Delay between keystrokes
WAIT_FOR_PLUGIN = 2.5  # Wait for plugin to load
WAIT_FOR_UI = 1.0  # Wait for UI to update
AI_VISION_ENABLED = True  # Use Claude AI vision to find controls

class AIVision:
    """AI-powered vision system to find plugin controls on screen"""
    
    def __init__(self, api_key=None):
        """Initialize Claude AI client"""
        self.api_key = api_key or os.environ.get('ANTHROPIC_API_KEY')
        if self.api_key:
            self.client = anthropic.Anthropic(api_key=self.api_key)
            self.vision_enabled = True
            print("✅ AI Vision enabled")
        else:
            self.vision_enabled = False
            print("⚠️  AI Vision disabled (no API key)")
    
    def screenshot_to_base64(self, region=None):
        """Take screenshot and convert to base64"""
        screenshot = pyautogui.screenshot(region=region)
        buffered = BytesIO()
        screenshot.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode()
        return img_str
    
    def find_control(self, control_name, control_type="knob"):
        """
        Use Claude AI vision to find a control on screen
        Returns: (x, y, confidence) or None
        """
        if not self.vision_enabled:
            return None
        
        print(f"   🔍 AI searching for {control_type}: {control_name}")
        
        # Take screenshot
        screenshot_b64 = self.screenshot_to_base64()
        
        # Ask Claude to find the control
        prompt = f"""You are analyzing a screenshot of an audio plugin interface.

Task: Find the {control_type} labeled "{control_name}" on screen.

Instructions:
1. Look carefully at the plugin interface
2. Find the {control_type} with the label "{control_name}"
3. Estimate the X,Y pixel coordinates of the CENTER of that control
4. Respond ONLY with JSON format:

{{
  "found": true/false,
  "x": pixel_x,
  "y": pixel_y,
  "confidence": 0.0-1.0,
  "reasoning": "brief explanation"
}}

If you cannot find it, set found=false."""

        try:
            message = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=500,
                messages=[{
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": screenshot_b64
                            }
                        },
                        {
                            "type": "text",
                            "text": prompt
                        }
                    ]
                }]
            )
            
            response_text = message.content[0].text
            
            # Parse JSON response
            # Remove markdown code blocks if present
            response_text = response_text.replace('```json', '').replace('```', '').strip()
            result = json.loads(response_text)
            
            if result.get('found'):
                print(f"   ✅ Found at ({result['x']}, {result['y']}) - confidence: {result['confidence']}")
                print(f"   💭 {result.get('reasoning', '')}")
                return (result['x'], result['y'], result['confidence'])
            else:
                print(f"   ❌ Not found: {result.get('reasoning', '')}")
                return None
                
        except Exception as e:
            print(f"   ⚠️  AI vision error: {e}")
            return None
    
    def get_knob_value_strategy(self, current_value, target_value):
        """
        Ask AI how to set a knob to target value
        Returns: click/drag instructions
        """
        if not self.vision_enabled:
            return None
        
        prompt = f"""A plugin knob is currently at value: {current_value}
Target value: {target_value}

Determine the best way to set this knob:
1. Click and drag (for continuous knobs)
2. Double-click and type (for text entry)
3. Click multiple times (for stepped controls)

Respond with JSON:
{{
  "method": "drag" / "type" / "click",
  "instructions": "specific steps"
}}"""

        try:
            message = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=300,
                messages=[{"role": "user", "content": prompt}]
            )
            
            response_text = message.content[0].text
            response_text = response_text.replace('```json', '').replace('```', '').strip()
            return json.loads(response_text)
            
        except Exception as e:
            print(f"   ⚠️  Strategy error: {e}")
            return {"method": "drag", "instructions": "default drag"}

class LogicAutomation:
    def __init__(self, chain_file, api_key=None):
        """Initialize automation with chain JSON file"""
        with open(chain_file, 'r') as f:
            self.chain = json.load(f)
        
        # Initialize AI vision
        self.ai_vision = AIVision(api_key)
        
        # Safety: set fail-safe to allow user to move mouse to corner to stop
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = CLICK_DELAY
        
    def activate_logic(self):
        """Bring Logic Pro to front"""
        print("🎹 Activating Logic Pro...")
        script = '''
        tell application "Logic Pro"
            activate
        end tell
        '''
        subprocess.run(['osascript', '-e', script])
        time.sleep(1)
        
    def press_keys(self, *keys):
        """Press keyboard shortcuts"""
        pyautogui.hotkey(*keys)
        time.sleep(CLICK_DELAY)
        
    def click_at(self, x, y):
        """Click at specific coordinates"""
        pyautogui.click(x, y)
        time.sleep(CLICK_DELAY)
        
    def double_click_at(self, x, y):
        """Double-click at specific coordinates"""
        pyautogui.doubleClick(x, y)
        time.sleep(CLICK_DELAY)
        
    def drag_to(self, start_x, start_y, end_x, end_y, duration=0.5):
        """Drag from start to end position"""
        pyautogui.moveTo(start_x, start_y)
        time.sleep(0.1)
        pyautogui.drag(end_x - start_x, end_y - start_y, duration=duration)
        time.sleep(CLICK_DELAY)
        
    def type_text(self, text, interval=None):
        """Type text with optional interval"""
        if interval is None:
            interval = TYPE_DELAY
        pyautogui.write(str(text), interval=interval)
        time.sleep(CLICK_DELAY)
        
    def find_plugin_insert_slot(self):
        """
        Find the plugin insert slot in Logic's mixer/inspector
        """
        print("\n📍 Looking for plugin insert slot...")
        print("👆 Click on the FIRST EMPTY SLOT (dark grey box next to 'Audio FX')")
        print("   NOT the 'Audio FX' text - click the empty grey box to its right")
        print("\n   Waiting 10 seconds for you to click...")
        
        time.sleep(10)
        
        # Get current mouse position (where user clicked)
        x, y = pyautogui.position()
        print(f"✅ Recorded position: ({x}, {y})")
        
        return x, y
        
    def load_plugin(self, plugin_name, slot_x, slot_y):
        """Load a plugin at the given slot position"""
        print(f"\n🔌 Loading: {plugin_name}")
        
        # Click the empty slot
        pyautogui.click(slot_x, slot_y)
        time.sleep(1.5)
        
        # Type plugin name
        pyautogui.write(plugin_name, interval=0.05)
        time.sleep(1.0)
        
        # Select from results
        pyautogui.press('down')
        time.sleep(0.3)
        pyautogui.press('return')
        
        # Wait for plugin to load
        time.sleep(3.0)
        
    def set_knob_parameter(self, param_name, target_value):
        """Set a knob parameter using AI vision"""
        if not self.ai_vision.vision_enabled:
            print(f"   ⚠️  Skipping {param_name} (AI vision disabled)")
            return False
        
        # Use AI to find the knob
        result = self.ai_vision.find_control(param_name, "knob")
        
        if not result:
            print(f"   ⚠️  Could not find {param_name}, skipping...")
            return False
        
        x, y, confidence = result
        
        if confidence < 0.5:
            print(f"   ⚠️  Low confidence ({confidence}), skipping...")
            return False
        
        # Try double-click and type (works for many plugins)
        try:
            print(f"   ⚙️  Setting {param_name} = {target_value}")
            self.double_click_at(x, y)
            time.sleep(0.3)
            
            # Select all and type new value
            pyautogui.hotkey('command', 'a')
            time.sleep(0.1)
            self.type_text(target_value, interval=0.05)
            pyautogui.press('return')
            time.sleep(0.3)
            
            print(f"   ✅ Set {param_name} = {target_value}")
            return True
            
        except Exception as e:
            print(f"   ❌ Error setting parameter: {e}")
            return False
    
    def set_dropdown_parameter(self, param_name, target_value):
        """Set a dropdown/menu parameter using AI vision"""
        if not self.ai_vision.vision_enabled:
            return False
        
        # Use AI to find the dropdown
        result = self.ai_vision.find_control(param_name, "dropdown menu")
        
        if not result:
            return False
        
        x, y, confidence = result
        
        try:
            print(f"   ⚙️  Setting {param_name} = {target_value}")
            self.click_at(x, y)
            time.sleep(0.5)
            
            # Type to search in menu
            self.type_text(str(target_value), interval=0.05)
            time.sleep(0.3)
            pyautogui.press('return')
            
            print(f"   ✅ Set {param_name} = {target_value}")
            return True
            
        except Exception as e:
            print(f"   ❌ Error: {e}")
            return False
    
    def set_plugin_parameters(self, plugin_name, parameters):
        """Set all parameters for a plugin using AI vision"""
        if not parameters or not self.ai_vision.vision_enabled:
            return
        
        print(f"   🤖 AI Setting parameters...")
        
        # Give plugin UI time to fully load
        time.sleep(1.0)
        
        success_count = 0
        total_count = 0
        
        for param_name, param_value in parameters.items():
            # Skip complex nested structures for now
            if isinstance(param_value, (dict, list)):
                continue
            
            total_count += 1
            
            # Try to set the parameter
            if self.set_knob_parameter(param_name, param_value):
                success_count += 1
            else:
                # Try as dropdown if knob failed
                if self.set_dropdown_parameter(param_name, param_value):
                    success_count += 1
        
        if total_count > 0:
            print(f"   📊 Parameters set: {success_count}/{total_count}")
        
    def open_plugin_window(self):
        """Double-click to open plugin window (makes parameters visible)"""
        # Get current mouse position (over plugin slot)
        x, y = pyautogui.position()
        self.double_click_at(x, y)
        time.sleep(1.0)
        print("   🪟 Opened plugin window")
        
    def close_plugin_window(self):
        """Close plugin window"""
        pyautogui.press('escape')
        time.sleep(0.5)
        
    def set_plugin_parameter(self, param_name, value):
        """Set a plugin parameter (legacy method, shows the challenge)"""
        print(f"   ⚙️  {param_name}: {value}")
        # This is replaced by AI vision methods above
    def automate_chain(self, auto_mode=False):
        """Main automation loop with AI vision parameter setting"""
        print("=" * 60)
        print("🤖 AI VOCAL CHAIN AUTOMATION")
        print("   WITH AI VISION PARAMETER SETTING")
        print("=" * 60)
        print(f"\n📋 Chain: {self.chain.get('name', 'Unnamed')}")
        print(f"📦 Total Plugins: {len(self.chain.get('plugins', []))}")
        
        if self.ai_vision.vision_enabled:
            print("✅ AI Vision: ENABLED - Will set parameters automatically!")
        else:
            print("⚠️  AI Vision: DISABLED - Will only load plugins")
            print("   Set ANTHROPIC_API_KEY environment variable to enable")
        
        print("\n⚠️  IMPORTANT:")
        print("   • Don't touch mouse/keyboard during automation")
        print("   • Move mouse to top-left corner to emergency stop")
        print("   • Make sure Logic Pro is visible on screen")
        print("   • Plugin windows will open/close automatically")
        
        if not auto_mode:
            input("\n▶️  Press ENTER to start automation...")
        else:
            print("\n▶️  Auto mode - starting in 3 seconds...")
            time.sleep(3)
        
        # Activate Logic Pro
        self.activate_logic()
        
        # Find the first plugin slot (user helps us)
        slot_x, slot_y = self.find_plugin_insert_slot()
        
        print("\n" + "=" * 60)
        print("🚀 STARTING AUTOMATED CHAIN BUILD...")
        print("=" * 60)
        
        # Load each plugin
        plugins = self.chain.get('plugins', [])
        total_params_set = 0
        total_params_attempted = 0
        
        for idx, plugin in enumerate(plugins, 1):
            print(f"\n{'='*60}")
            print(f"[{idx}/{len(plugins)}] {plugin.get('name', 'Unknown')}")
            print(f"{'='*60}")
            
            try:
                plugin_name = plugin.get('name', 'Unknown')
                
                # Load the plugin
                self.load_plugin(plugin_name, slot_x, slot_y)
                
                # Set parameters with AI vision
                params = plugin.get('parameters', {})
                if params and self.ai_vision.vision_enabled:
                    # Open plugin window to see parameters
                    self.open_plugin_window()
                    
                    # Set parameters using AI vision
                    before_count = total_params_set
                    self.set_plugin_parameters(plugin_name, params)
                    
                    # Calculate how many we set
                    params_count = sum(1 for v in params.values() if not isinstance(v, (dict, list)))
                    total_params_attempted += params_count
                    
                    # Close plugin window
                    self.close_plugin_window()
                    
                elif params:
                    # AI vision disabled, just show what to set
                    print(f"   📊 Parameters to set manually:")
                    for key, value in list(params.items())[:5]:
                        if not isinstance(value, (dict, list)):
                            print(f"      • {key}: {value}")
                
                # Move to next slot below
                slot_y += 30
                
                time.sleep(0.5)
                
            except KeyboardInterrupt:
                raise
            except Exception as e:
                print(f"   ❌ Error: {e}")
                print(f"   ⏭️  Skipping to next plugin...")
                slot_y += 30
                continue
        
        print("\n" + "=" * 60)
        print("✅ AUTOMATION COMPLETE!")
        print("=" * 60)
        
        if self.ai_vision.vision_enabled and total_params_attempted > 0:
            success_rate = (total_params_set / total_params_attempted * 100) if total_params_attempted > 0 else 0
            print(f"\n📊 AI Vision Results:")
            print(f"   • Plugins loaded: {len(plugins)}")
            print(f"   • Parameters attempted: {total_params_attempted}")
            print(f"   • Parameters set: {total_params_set}")
            print(f"   • Success rate: {success_rate:.1f}%")
        
        print("\n📝 Next steps:")
        print("   1. Check that all plugins loaded correctly")
        if self.ai_vision.vision_enabled:
            print("   2. Verify AI-set parameters (spot check)")
            print("   3. Manually adjust any missed parameters")
        else:
            print("   2. Manually set parameters from HTML report")
        print("   4. Fine-tune by ear")
        print("   5. Save as preset in Logic Pro")

def main():
    if len(sys.argv) < 2:
        print("╔══════════════════════════════════════════════════════════╗")
        print("║   Logic Pro AI Automation with Vision")
        print("║   Automatically loads plugins AND sets parameters!")
        print("╚══════════════════════════════════════════════════════════╝")
        print("\nUsage: python3 logic_automation.py <chain.json> [--auto] [api_key]")
        print("\nOptions:")
        print("  chain.json  - Exported plugin chain from app")
        print("  --auto      - Skip prompts for app automation")
        print("  api_key     - Anthropic API key (or set ANTHROPIC_API_KEY env var)")
        print("\nWith API key: Sets parameters automatically using AI vision")
        print("Without API key: Only loads plugins")
        print("\nExample:")
        print("  python3 logic_automation.py AI-Vocal-Chain.json")
        print("  python3 logic_automation.py AI-Vocal-Chain.json --auto sk-ant-...")
        sys.exit(1)
    
    chain_file = sys.argv[1]
    api_key = None
    auto_mode = False
    
    # Parse remaining arguments
    for arg in sys.argv[2:]:
        if arg == '--auto':
            auto_mode = True
        elif arg.startswith('sk-ant-'):
            api_key = arg
        else:
            api_key = arg
    
    if not os.path.exists(chain_file):
        print(f"❌ Error: File not found: {chain_file}")
        sys.exit(1)
    
    try:
        automation = LogicAutomation(chain_file, api_key)
        automation.automate_chain(auto_mode=auto_mode)
    except KeyboardInterrupt:
        print("\n\n⚠️  Automation stopped by user")
    except Exception as e:
        print(f"\n\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
