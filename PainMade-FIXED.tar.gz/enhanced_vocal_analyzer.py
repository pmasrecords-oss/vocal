#!/usr/bin/env python3
"""
ENHANCED AI Vocal Analyzer + Logic Pro Controller
Now with Waves plugins, Melodyne, and advanced analysis!
Personalized for YOUR voice - no reference needed!
"""

import json
import numpy as np
import librosa
import sys
import os
from pathlib import Path
from scipy import signal
from scipy.stats import mode

# Try to import ultra analyzer for even more detailed analysis
try:
    from ultra_vocal_analyzer import enhance_existing_analysis
    ULTRA_AVAILABLE = True
except ImportError:
    ULTRA_AVAILABLE = False
    print("Note: Ultra analysis not available")

class EnhancedVocalAnalyzer:
    """Advanced vocal analysis with Waves/Melodyne support"""
    
    def __init__(self):
        self.sample_rate = 44100
        self.analysis = {}
        
    def analyze_vocal(self, audio_path, genre=None, options=None):
        """
        Complete enhanced vocal analysis
        Returns automation commands for Logic Pro with Waves/Melodyne
        """
        if options is None:
            options = {
                'use_waves': True,
                'use_melodyne': True,
                'use_logic': True,
                'deep_analysis': True,
                'pitch_correction': False,
                'timing_analysis': False,
                'formant_analysis': False,
                'emotion_detection': False
            }
        
        print(f"🎤 Analyzing: {Path(audio_path).name}")
        print(f"🎼 Genre: {genre or 'Auto-detect'}")
        print(f"🔬 Deep Analysis: {options.get('deep_analysis', False)}")
        
        # Load audio
        y, sr = librosa.load(audio_path, sr=self.sample_rate)
        self.sample_rate = sr
        
        # Run all analyses
        self.analysis = {
            'vocal_repair': self._analyze_vocal_repair(y, sr),
            'vocal_character': self._analyze_vocal_character(y, sr, options.get('deep_analysis', False)),
            'dynamic_consistency': self._analyze_dynamics(y, sr),
            'genre_processing': self._get_genre_settings(genre, y, sr),
            'plugin_preferences': options
        }
        
        # Advanced analyses if enabled
        if options.get('pitch_correction'):
            self.analysis['pitch_analysis'] = self._analyze_pitch(y, sr)
            
        if options.get('timing_analysis'):
            self.analysis['timing_analysis'] = self._analyze_timing(y, sr)
            
        if options.get('formant_analysis'):
            self.analysis['formant_analysis'] = self._analyze_formants(y, sr)
            
        if options.get('emotion_detection'):
            self.analysis['emotion'] = self._detect_emotion(y, sr)
        
        # ULTRA ANALYSIS - Add even more detailed insights!
        # This runs automatically to give you the BEST vocal analysis possible
        if ULTRA_AVAILABLE and options.get('deep_analysis', False):
            print("\n🚀 Running ULTRA ANALYSIS for maximum vocal quality...")
            try:
                full_analysis = {
                    'analysis': self.analysis,
                    'logic_chain': [],
                    'summary': {}
                }
                enhanced_result = enhance_existing_analysis(full_analysis, y, sr)
                self.analysis = enhanced_result['analysis']
                print("✅ Ultra analysis complete! Your vocals will be EVEN BETTER!")
            except Exception as e:
                print(f"⚠️ Ultra analysis skipped: {e}")
        
        # Generate plugin chain based on preferences
        logic_chain = self._build_enhanced_chain(options)
        
        return {
            'analysis': self.analysis,
            'logic_chain': logic_chain,
            'summary': self._generate_summary()
        }
    
    def _analyze_pitch(self, y, sr):
        """Detect pitch, key, and scale for Melodyne"""
        print("🎵 Analyzing pitch & key...")
        
        # Extract pitch using piptrack (more accurate for vocals)
        pitches, magnitudes = librosa.piptrack(y=y, sr=sr, fmin=80, fmax=400)
        
        # Get the pitch with highest magnitude at each frame
        pitch_values = []
        for t in range(pitches.shape[1]):
            index = magnitudes[:, t].argmax()
            pitch = pitches[index, t]
            if pitch > 0:
                pitch_values.append(pitch)
        
        if len(pitch_values) == 0:
            return {
                'detected': False,
                'key': 'C',
                'scale': 'major',
                'average_pitch': 0
            }
        
        # Calculate average pitch
        avg_pitch = np.median(pitch_values)
        
        # Convert to MIDI note
        midi_note = librosa.hz_to_midi(avg_pitch)
        
        # Detect key (simplified - look at histogram of pitches)
        pitch_classes = [librosa.hz_to_note(p, cents=False) for p in pitch_values]
        most_common = mode([p[:-1] if len(p) > 1 else p for p in pitch_classes])[0]
        
        # Detect if major or minor (simplified based on intervals)
        chroma = librosa.feature.chroma_cqt(y=y, sr=sr)
        chroma_mean = np.mean(chroma, axis=1)
        
        # Major has strong I, III, V (0, 4, 7)
        # Minor has strong I, bIII, V (0, 3, 7)
        major_strength = chroma_mean[0] + chroma_mean[4] + chroma_mean[7]
        minor_strength = chroma_mean[0] + chroma_mean[3] + chroma_mean[7]
        
        scale = 'major' if major_strength > minor_strength else 'minor'
        
        # Detect pitch stability (for tuning amount)
        pitch_variance = np.std(pitch_values)
        needs_strong_tuning = pitch_variance > 30  # Hz
        
        return {
            'detected': True,
            'key': str(most_common),
            'scale': scale,
            'average_pitch': float(avg_pitch),
            'average_midi': float(midi_note),
            'pitch_variance': float(pitch_variance),
            'needs_strong_tuning': needs_strong_tuning,
            'tuning_amount': 75 if needs_strong_tuning else 40  # Melodyne correction amount
        }
    
    def _analyze_timing(self, y, sr):
        """Detect tempo and rhythm for delay sync"""
        print("⏱️ Analyzing timing & tempo...")
        
        # Detect tempo
        tempo, beats = librosa.beat.beat_track(y=y, sr=sr)
        tempo = float(tempo)
        
        # Calculate note values for delay
        quarter_note_ms = (60 / tempo) * 1000
        eighth_note_ms = quarter_note_ms / 2
        sixteenth_note_ms = quarter_note_ms / 4
        dotted_eighth_ms = eighth_note_ms * 1.5
        
        # Detect if performance is on-grid or loose
        onset_env = librosa.onset.onset_strength(y=y, sr=sr)
        onset_frames = librosa.onset.onset_detect(onset_envelope=onset_env, sr=sr)
        
        # Check timing consistency
        if len(onset_frames) > 3:
            onset_times = librosa.frames_to_time(onset_frames, sr=sr)
            onset_diffs = np.diff(onset_times)
            timing_consistency = 1.0 - (np.std(onset_diffs) / np.mean(onset_diffs) if np.mean(onset_diffs) > 0 else 1.0)
            timing_consistency = max(0, min(1, timing_consistency))
        else:
            timing_consistency = 0.5
        
        # Recommend delay settings
        if tempo < 80:
            delay_time = 'quarter'
            feedback = 35
        elif tempo < 120:
            delay_time = 'eighth'
            feedback = 25
        elif tempo < 150:
            delay_time = 'sixteenth'
            feedback = 20
        else:
            delay_time = 'dotted_eighth'
            feedback = 15
        
        return {
            'tempo': tempo,
            'timing_consistency': float(timing_consistency),
            'timing_quality': 'tight' if timing_consistency > 0.7 else 'loose' if timing_consistency < 0.4 else 'moderate',
            'quarter_note_ms': quarter_note_ms,
            'eighth_note_ms': eighth_note_ms,
            'sixteenth_note_ms': sixteenth_note_ms,
            'dotted_eighth_ms': dotted_eighth_ms,
            'recommended_delay': delay_time,
            'recommended_feedback': feedback
        }
    
    def _analyze_formants(self, y, sr):
        """Analyze vocal formants for character and texture"""
        print("🎙️ Analyzing formants...")
        
        # Get formants using LPC (Linear Predictive Coding)
        # Formants are resonant frequencies of the vocal tract
        frame_length = 2048
        hop_length = 512
        
        formants = {'F1': [], 'F2': [], 'F3': []}
        
        # Process in frames
        for i in range(0, len(y) - frame_length, hop_length):
            frame = y[i:i + frame_length]
            if len(frame) < frame_length:
                break
            
            # Apply window
            windowed = frame * np.hamming(len(frame))
            
            # LPC analysis (order 12 for vocal formants)
            try:
                lpc_coeffs = librosa.lpc(windowed, order=12)
                
                # Find formant frequencies from LPC roots
                roots = np.roots(lpc_coeffs)
                roots = roots[np.imag(roots) >= 0]  # Keep positive frequencies
                
                # Convert to Hz
                angles = np.arctan2(np.imag(roots), np.real(roots))
                freqs = angles * (sr / (2 * np.pi))
                
                # Sort and get first 3 formants (F1, F2, F3)
                freqs = np.sort(freqs[freqs > 0])
                if len(freqs) >= 3:
                    formants['F1'].append(freqs[0])
                    formants['F2'].append(freqs[1])
                    formants['F3'].append(freqs[2])
            except:
                continue
        
        # Calculate average formants
        if len(formants['F1']) > 0:
            f1_avg = np.median(formants['F1'])
            f2_avg = np.median(formants['F2'])
            f3_avg = np.median(formants['F3'])
            
            # Determine vocal character from formants
            # F1 relates to openness, F2 relates to frontness
            if f1_avg < 500:
                openness = 'closed'
            elif f1_avg > 700:
                openness = 'open'
            else:
                openness = 'moderate'
            
            if f2_avg > 1800:
                frontness = 'front'
            elif f2_avg < 1200:
                frontness = 'back'
            else:
                frontness = 'central'
            
            return {
                'detected': True,
                'F1': float(f1_avg),
                'F2': float(f2_avg),
                'F3': float(f3_avg),
                'openness': openness,
                'frontness': frontness,
                'vocal_character': f"{openness}-{frontness}",
                'formant_boost': {
                    'F1': float(f1_avg),
                    'F2': float(f2_avg),
                    'amount': 2.0
                }
            }
        else:
            return {
                'detected': False,
                'message': 'Could not detect formants'
            }
    
    def _detect_emotion(self, y, sr):
        """Detect emotional character for processing adjustments"""
        print("😊 Detecting emotion/vibe...")
        
        # Features for emotion detection
        
        # 1. Energy (loud/aggressive vs soft/intimate)
        rms = librosa.feature.rms(y=y)[0]
        energy_level = np.mean(rms)
        energy_variance = np.std(rms)
        
        # 2. Spectral rolloff (brightness/aggression)
        rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr)[0]
        rolloff_mean = np.mean(rolloff)
        
        # 3. Zero crossing rate (noisiness/breathiness)
        zcr = librosa.feature.zero_crossing_rate(y)[0]
        zcr_mean = np.mean(zcr)
        
        # 4. Spectral flux (dynamic variation)
        spec_cent = librosa.feature.spectral_centroid(y=y, sr=sr)[0]
        flux = np.std(spec_cent)
        
        # Determine emotion
        if energy_level > 0.15 and rolloff_mean > 3000:
            emotion = 'aggressive'
            reverb_decay = 0.8
            compression_ratio = 8.0
        elif energy_level < 0.08 and zcr_mean > 0.1:
            emotion = 'intimate'
            reverb_decay = 2.5
            compression_ratio = 2.5
        elif flux > 1000:
            emotion = 'dynamic'
            reverb_decay = 1.5
            compression_ratio = 4.0
        elif energy_level > 0.12:
            emotion = 'energetic'
            reverb_decay = 1.2
            compression_ratio = 6.0
        else:
            emotion = 'balanced'
            reverb_decay = 1.5
            compression_ratio = 4.0
        
        return {
            'emotion': emotion,
            'energy_level': float(energy_level),
            'brightness': 'bright' if rolloff_mean > 3000 else 'dark',
            'dynamic_character': 'dynamic' if flux > 1000 else 'consistent',
            'processing_adjustments': {
                'reverb_decay': reverb_decay,
                'compression_ratio': compression_ratio,
                'saturation': 'high' if emotion == 'aggressive' else 'low'
            }
        }
    
    def _analyze_vocal_character(self, y, sr, deep=False):
        """Enhanced character analysis with deep mode"""
        print(f"🎤 Analyzing voice character (deep={deep})...")
        
        # Use more frequency bins for deep analysis
        n_fft = 4096 if deep else 2048
        
        # Standard analysis
        spectral_centroid = np.mean(librosa.feature.spectral_centroid(y=y, sr=sr, n_fft=n_fft))
        brightness = 'bright' if spectral_centroid > 2000 else 'dark' if spectral_centroid < 1500 else 'balanced'
        
        # Thickness analysis
        stft = librosa.stft(y, n_fft=n_fft)
        low_energy = np.mean(np.abs(stft[:50, :]))
        mid_energy = np.mean(np.abs(stft[50:200, :]))
        thickness = 'thin' if low_energy < mid_energy * 0.5 else 'thick' if low_energy > mid_energy * 1.5 else 'balanced'
        
        # Deep frequency analysis
        if deep:
            # Use 512 mel bands instead of standard 128
            mel_spec = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=512, n_fft=n_fft)
            mel_db = librosa.power_to_db(mel_spec, ref=np.max)
            
            # Find ALL problem frequencies
            freq_bins = librosa.mel_frequencies(n_mels=512, fmin=0, fmax=sr/2)
            
            problem_freqs = []
            sweet_spots = []
            
            # Scan all frequencies
            for i in range(10, len(freq_bins) - 10):
                local_energy = np.mean(mel_db[i-5:i+5, :])
                median_energy = np.median(mel_db)
                
                if local_energy > median_energy + 10:  # 10dB above median
                    freq = int(freq_bins[i])
                    if freq < 500:
                        desc = 'muddy low-mids'
                    elif freq < 1000:
                        desc = 'boxiness'
                    elif freq < 2000:
                        desc = 'nasal/honky'
                    elif freq < 4000:
                        desc = 'harsh/aggressive'
                    elif freq < 8000:
                        desc = 'sibilance/presence'
                    else:
                        desc = 'excessive air'
                    
                    problem_freqs.append({
                        'frequency': freq,
                        'description': desc,
                        'severity': 'high' if local_energy > median_energy + 15 else 'medium'
                    })
                
                elif local_energy > median_energy + 5:  # 5dB above = sweet spot
                    freq = int(freq_bins[i])
                    if 1000 < freq < 6000:  # Presence range
                        sweet_spots.append(freq)
        else:
            # Standard analysis
            fft = np.abs(librosa.stft(y, n_fft=n_fft))
            freq_bins = librosa.fft_frequencies(sr=sr, n_fft=n_fft)
            
            problem_freqs = []
            sweet_spots = []
            
            # Check common problem areas
            problem_ranges = [
                (200, 400, 'muddy low-mids'),
                (2000, 3500, 'harsh mids'),
                (8000, 12000, 'excessive air')
            ]
            
            for low, high, desc in problem_ranges:
                low_bin = np.argmin(np.abs(freq_bins - low))
                high_bin = np.argmin(np.abs(freq_bins - high))
                energy = np.mean(fft[low_bin:high_bin, :])
                median_energy = np.median(fft)
                
                if energy > median_energy * 2:
                    peak_bin = low_bin + np.argmax(np.mean(fft[low_bin:high_bin, :], axis=1))
                    peak_freq = int(freq_bins[peak_bin])
                    problem_freqs.append({
                        'frequency': peak_freq,
                        'description': desc,
                        'severity': 'high'
                    })
            
            # Find sweet spots
            for i in range(50, len(freq_bins) - 50, 10):
                if i < len(fft):
                    local_energy = np.mean(fft[i-5:i+5, :])
                    if local_energy > np.median(fft) * 2.5:
                        sweet_spots.append(int(freq_bins[i]))
        
        # Generate EQ settings
        eq_settings = []
        
        # Apply character-based EQ
        if brightness == 'bright':
            eq_settings.append({'freq': 3500, 'gain': -2.5, 'q': 1.5, 'type': 'bell'})
        elif brightness == 'dark':
            eq_settings.append({'freq': 10000, 'gain': 2.0, 'q': 1.0, 'type': 'high_shelf'})
        
        if thickness == 'thin':
            eq_settings.append({'freq': 250, 'gain': 3.0, 'q': 1.2, 'type': 'bell'})
        elif thickness == 'thick':
            eq_settings.append({'freq': 300, 'gain': -3.0, 'q': 1.0, 'type': 'bell'})
        
        # Apply problem frequency cuts
        for prob in problem_freqs[:5]:  # Top 5 problems
            eq_settings.append({
                'freq': prob['frequency'],
                'gain': -4.0 if prob['severity'] == 'high' else -2.5,
                'q': 3.0 if prob['severity'] == 'high' else 2.0,
                'type': 'bell'
            })
        
        # Apply sweet spot boosts
        for sweet in sweet_spots[:3]:  # Top 3 sweet spots
            eq_settings.append({
                'freq': sweet,
                'gain': 2.5,
                'q': 1.8,
                'type': 'bell'
            })
        
        recommendations = [
            f"Brightness: {brightness} - {'Reduce harshness' if brightness == 'bright' else 'Add air' if brightness == 'dark' else 'Well balanced'}",
            f"Thickness: {thickness} - {'Boost low-mids' if thickness == 'thin' else 'Cut mud' if thickness == 'thick' else 'Well balanced'}",
            f"Found {len(problem_freqs)} problem frequencies",
            f"Found {len(sweet_spots)} sweet spots to boost"
        ]
        
        return {
            'brightness': brightness,
            'thickness': thickness,
            'problem_frequencies': problem_freqs,
            'sweet_spots': sweet_spots[:5],
            'recommendations': recommendations,
            'eq_settings': eq_settings,
            'analysis_depth': 'deep (512 bands)' if deep else 'standard (64 bands)'
        }
    
    def _analyze_vocal_repair(self, y, sr):
        """Detect issues - same as before"""
        issues = []
        fixes = []
        
        # Clipping
        clipping_threshold = 0.99
        clipped_samples = np.sum(np.abs(y) > clipping_threshold)
        if clipped_samples > 0:
            issues.append(f"⚠️  Clipping detected ({clipped_samples} samples)")
            fixes.append({
                'issue': 'clipping',
                'plugin': 'Limiter',
                'settings': {'ceiling': -0.3, 'release': 50}
            })
        
        # Plosives
        stft = librosa.stft(y)
        low_freq_energy = np.abs(stft[:20, :])
        plosive_frames = np.where(np.max(low_freq_energy, axis=0) > np.median(low_freq_energy) * 5)[0]
        
        if len(plosive_frames) > 10:
            issues.append(f"⚠️  Plosives detected ({len(plosive_frames)} instances)")
            fixes.append({
                'issue': 'plosives',
                'plugin': 'Channel EQ',
                'settings': {'type': 'high_pass', 'frequency': 80, 'slope': 24}
            })
        
        # Sibilance
        high_freq_energy = np.abs(stft[-100:, :])
        sibilant_frames = np.where(np.max(high_freq_energy, axis=0) > np.median(high_freq_energy) * 4)[0]
        
        if len(sibilant_frames) > 20:
            sibilance_freq = self._detect_sibilance_frequency(y, sr)
            issues.append(f"⚠️  Harsh sibilance at {sibilance_freq}Hz")
            fixes.append({
                'issue': 'sibilance',
                'plugin': 'DeEsser',
                'settings': {'frequency': sibilance_freq, 'amount': 6.0}
            })
        
        # Noise
        noise_floor = np.percentile(np.abs(y), 5)
        if noise_floor > 0.01:
            issues.append(f"⚠️  Background noise detected")
            fixes.append({
                'issue': 'noise',
                'plugin': 'Noise Gate',
                'settings': {'threshold': -45, 'attack': 5, 'release': 150}
            })
        
        return {
            'issues': issues,
            'fixes': fixes,
            'health_score': max(0, 100 - len(issues) * 15)
        }
    
    def _analyze_dynamics(self, y, sr):
        """Dynamics analysis - same as before"""
        rms = librosa.feature.rms(y=y, frame_length=2048, hop_length=512)[0]
        rms_db = librosa.amplitude_to_db(rms, ref=np.max)
        
        dynamic_range = np.max(rms_db) - np.min(rms_db[rms_db > -60])
        consistency = np.std(rms_db[rms_db > -60])
        
        if dynamic_range > 30:
            ratio, threshold = 6.0, -18
        elif dynamic_range > 20:
            ratio, threshold = 4.0, -15
        else:
            ratio, threshold = 2.5, -12
        
        attack = 5 if consistency > 8 else 15
        release = 50 if consistency > 8 else 100
        
        return {
            'dynamic_range_db': float(dynamic_range),
            'consistency_score': float(100 - consistency * 5),
            'compression_settings': {
                'ratio': ratio,
                'threshold': threshold,
                'attack': attack,
                'release': release,
                'knee': 3.0,
                'makeup_gain': 3.0
            }
        }
    
    def _get_genre_settings(self, genre, y, sr):
        """Genre processing - same as before"""
        if not genre or genre == 'auto':
            genre = self._detect_genre(y, sr)
        
        genre_presets = {
            'trap': {'description': 'Modern trap vocals', 'chain': []},
            'drill': {'description': 'UK Drill vocals', 'chain': []},
            'rnb': {'description': 'R&B/Soul vocals', 'chain': []},
            'pop': {'description': 'Modern pop vocals', 'chain': []},
            'rock': {'description': 'Rock vocals', 'chain': []}
        }
        
        return genre_presets.get(genre.lower(), genre_presets['pop'])
    
    def _detect_genre(self, y, sr):
        """Simple genre detection"""
        tempo = librosa.beat.tempo(y=y, sr=sr)[0]
        spectral_centroid = np.mean(librosa.feature.spectral_centroid(y=y, sr=sr))
        
        if tempo > 140 and spectral_centroid > 2500:
            return 'trap'
        elif tempo > 130 and spectral_centroid < 2000:
            return 'drill'
        elif tempo < 100 and spectral_centroid > 2000:
            return 'rnb'
        else:
            return 'pop'
    
    def _detect_sibilance_frequency(self, y, sr):
        """Find exact sibilance frequency"""
        stft = np.abs(librosa.stft(y))
        freq_bins = librosa.fft_frequencies(sr=sr)
        
        low_bin = np.argmin(np.abs(freq_bins - 5000))
        high_bin = np.argmin(np.abs(freq_bins - 9000))
        
        sibilance_spectrum = stft[low_bin:high_bin, :]
        peak_bin = low_bin + np.argmax(np.mean(sibilance_spectrum, axis=1))
        
        return int(freq_bins[peak_bin])
    
    def _build_enhanced_chain(self, options):
        """Build plugin chain with Waves/Melodyne based on preferences + ULTRA ANALYSIS"""
        chain = []
        
        use_waves = options.get('use_waves', True)
        use_melodyne = options.get('use_melodyne', True)
        use_logic = options.get('use_logic', True)
        
        # Check if ultra analysis is available
        has_ultra = 'ultra_analysis' in self.analysis
        
        # 0. ULTRA: Advanced Noise Gate (if breath control analysis available)
        if has_ultra and 'breath_control' in self.analysis['ultra_analysis']:
            breath_data = self.analysis['ultra_analysis']['breath_control']
            if breath_data['breath_count'] > 5:  # Multiple breaths detected
                chain.append({
                    'category': 'cleanup',
                    'plugin': 'Noise Gate',
                    'type': 'logic',
                    'settings': {
                        'threshold': breath_data['recommended_gate_threshold'],
                        'attack': 1,
                        'hold': 50,
                        'release': 100
                    },
                    'reason': f"Clean up {breath_data['breath_count']} breath sounds (ULTRA)"
                })
        
        # 1. Melodyne (if enabled and pitch correction needed)
        if use_melodyne and options.get('pitch_correction') and 'pitch_analysis' in self.analysis:
            pitch_data = self.analysis['pitch_analysis']
            if pitch_data['detected']:
                chain.append({
                    'category': 'pitch',
                    'plugin': 'Melodyne',
                    'type': 'melodyne',
                    'settings': {
                        'correction_amount': pitch_data.get('tuning_amount', 50),
                        'key': pitch_data.get('key', 'C'),
                        'scale': pitch_data.get('scale', 'major')
                    },
                    'reason': f"Auto-tune to {pitch_data['key']} {pitch_data['scale']}"
                })
        
        # 1.5 ULTRA: Precise De-Esser (if sibilance mapping available)
        if has_ultra and 'sibilance_detail' in self.analysis['ultra_analysis']:
            sib_data = self.analysis['ultra_analysis']['sibilance_detail']
            if sib_data['severity'] != 'minimal':
                if use_waves:
                    chain.append({
                        'category': 'repair',
                        'plugin': 'Waves Renaissance DeEsser',
                        'type': 'waves',
                        'settings': {
                            'frequency': sib_data['frequency_center'],
                            'bandwidth': sib_data['bandwidth'],
                            'threshold': sib_data['recommended_reduction_db'],
                            'mode': 'split'
                        },
                        'reason': f"Precise de-ess: {sib_data['sibilant_count']} harsh spots (ULTRA)"
                    })
        
        # 2. Vocal Repair
        repair = self.analysis['vocal_repair']
        for fix in repair['fixes']:
            if fix['plugin'] == 'Channel EQ' and use_logic:
                # ULTRA: Enhance EQ with resonance data
                eq_settings = fix['settings'].copy()
                if has_ultra and 'vocal_resonance' in self.analysis['ultra_analysis']:
                    res_data = self.analysis['ultra_analysis']['vocal_resonance']
                    if res_data['top_resonances']:
                        sweet_freq = res_data['sweet_spot_frequency']
                        eq_settings['sweet_spot_boost'] = {
                            'freq': sweet_freq,
                            'gain': res_data['boost_recommendation'],
                            'q': 2.0
                        }
                
                chain.append({
                    'category': 'repair',
                    'plugin': fix['plugin'],
                    'type': 'logic',
                    'settings': eq_settings,
                    'reason': f"Fix: {fix['issue']}" + (" + Boost resonance" if has_ultra else "")
                })
            elif fix['plugin'] in ['DeEsser', 'Noise Gate', 'Limiter']:
                if use_waves and fix['plugin'] == 'DeEsser':
                    chain.append({
                        'category': 'repair',
                        'plugin': 'Waves Renaissance DeEsser',
                        'type': 'waves',
                        'settings': fix['settings'],
                        'reason': f"Fix: {fix['issue']}"
                    })
                elif use_logic:
                    chain.append({
                        'category': 'repair',
                        'plugin': fix['plugin'],
                        'type': 'logic',
                        'settings': fix['settings'],
                        'reason': f"Fix: {fix['issue']}"
                    })
        
        # 3. EQ (prefer Waves SSL or Renaissance)
        character = self.analysis['vocal_character']
        if character['eq_settings']:
            # ULTRA: Add harmonic distortion fixes
            eq_settings_enhanced = {'bands': character['eq_settings']}
            if has_ultra and 'harmonic_distortion' in self.analysis['ultra_analysis']:
                dist_data = self.analysis['ultra_analysis']['harmonic_distortion']
                if dist_data['recommended_mud_cut'] > 0:
                    eq_settings_enhanced['mud_cut'] = {
                        'freq': dist_data['recommended_mud_cut'],
                        'gain': dist_data['recommended_cut_amount'],
                        'q': 2.0
                    }
            
            if use_waves:
                chain.append({
                    'category': 'character',
                    'plugin': 'Waves SSL E-Channel',
                    'type': 'waves',
                    'settings': eq_settings_enhanced,
                    'reason': 'Personalized EQ for your voice' + (' + Clarity boost (ULTRA)' if has_ultra else '')
                })
            elif use_logic:
                chain.append({
                    'category': 'character',
                    'plugin': 'Channel EQ',
                    'type': 'logic',
                    'settings': eq_settings_enhanced,
                    'reason': 'Personalized EQ for your voice'
                })
        
        # 3.5 ULTRA: Transient Shaper (if punch analysis available)
        if has_ultra and 'transient_punch' in self.analysis['ultra_analysis']:
            punch_data = self.analysis['ultra_analysis']['transient_punch']
            if punch_data['enhancement_needed'] != 'minimal' and use_waves:
                chain.append({
                    'category': 'dynamics',
                    'plugin': 'Waves Trans-X',
                    'type': 'waves',
                    'settings': {
                        'attack': punch_data['recommended_transient_boost_db'],
                        'sustain': 0,
                        'ratio': 100
                    },
                    'reason': f"Punch boost: Make words hit harder (ULTRA punch score: {punch_data['punch_score']:.0f})"
                })
        
        # 4. Compression (prefer Waves CLA-76 or Renaissance)
        dynamics = self.analysis['dynamic_consistency']
        
        # ULTRA: Adjust compression based on vocal strain
        compression_settings = dynamics['compression_settings'].copy()
        if has_ultra and 'vocal_strain' in self.analysis['ultra_analysis']:
            strain_data = self.analysis['ultra_analysis']['vocal_strain']
            compression_settings['ratio'] = strain_data['suggested_compression_ratio']
            if strain_data['strain_level'] == 'high_strain':
                compression_settings['attack'] = 15  # Gentler
                compression_settings['release'] = 150  # Slower
        
        if use_waves:
            ratio_setting = 'All Buttons In' if compression_settings.get('ratio', 4) >= 6 else '4:1'
            if has_ultra and compression_settings.get('ratio', 4) < 3:
                ratio_setting = '2:1'  # Gentler for strained vocals
            
            chain.append({
                'category': 'dynamics',
                'plugin': 'Waves CLA-76',
                'type': 'waves',
                'settings': {
                    'ratio': ratio_setting,
                    'attack': 'fast',
                    'release': 'fast' if compression_settings.get('release', 80) < 80 else 'slow'
                },
                'reason': 'Even out dynamics (CLA-76 compression)' + (' - Gentle (strain detected)' if has_ultra else '')
            })
        elif use_logic:
            chain.append({
                'category': 'dynamics',
                'plugin': 'Compressor',
                'type': 'logic',
                'settings': compression_settings,
                'reason': 'Even out dynamics'
            })
        
        # 5. Additional Waves processing
        if use_waves:
            # Renaissance Vox for additional color
            chain.append({
                'category': 'color',
                'plugin': 'Waves Renaissance Vox',
                'type': 'waves',
                'settings': {
                    'gate': -40,
                    'comp': 5.0,
                    'leveler': 3.0
                },
                'reason': 'Add vocal character and presence'
            })
        
        # 6. Reverb & Delay (prefer Waves H-Reverb and H-Delay)
        genre = self.analysis['genre_processing']
        if use_waves:
            chain.append({
                'category': 'space',
                'plugin': 'Waves H-Reverb',
                'type': 'waves',
                'settings': {
                    'type': 'Vocal Hall',
                    'decay': 1.5,
                    'mix': 18
                },
                'reason': 'Add space and depth'
            })
            
            chain.append({
                'category': 'space',
                'plugin': 'Waves H-Delay',
                'type': 'waves',
                'settings': {
                    'time': 'eighth' if 'timing_analysis' not in self.analysis else self.analysis['timing_analysis']['recommended_delay'],
                    'feedback': 25,
                    'mix': 15
                },
                'reason': 'Add width and interest'
            })
        elif use_logic:
            chain.append({
                'category': 'space',
                'plugin': 'Space Designer',
                'type': 'logic',
                'settings': {'preset': 'Vocal Hall', 'mix': 18},
                'reason': 'Add space'
            })
        
        return chain
    
    def _generate_summary(self):
        """Generate summary"""
        repair = self.analysis['vocal_repair']
        character = self.analysis['vocal_character']
        dynamics = self.analysis['dynamic_consistency']
        
        summary = {
            'overall_health': repair['health_score'],
            'issues_found': len(repair['issues']),
            'voice_type': f"{character['brightness']}, {character['thickness']}",
            'dynamic_range': dynamics['dynamic_range_db'],
            'analysis_depth': character.get('analysis_depth', 'standard'),
            'has_pitch_correction': 'pitch_analysis' in self.analysis,
            'has_timing_sync': 'timing_analysis' in self.analysis,
            'has_formant_data': 'formant_analysis' in self.analysis,
            'has_emotion_data': 'emotion' in self.analysis
        }
        
        return summary


def main():
    """Main entry point"""
    if len(sys.argv) < 2:
        print("Usage: python enhanced_vocal_analyzer.py <audio_file> [genre] [options_json]")
        sys.exit(1)
    
    audio_path = sys.argv[1]
    genre = sys.argv[2] if len(sys.argv) > 2 else None
    
    # Parse options if provided
    options = {}
    if len(sys.argv) > 3:
        try:
            options = json.loads(sys.argv[3])
        except:
            pass
    
    if not os.path.exists(audio_path):
        print(f"Error: File not found: {audio_path}")
        sys.exit(1)
    
    # Run analysis
    analyzer = EnhancedVocalAnalyzer()
    result = analyzer.analyze_vocal(audio_path, genre, options)
    
    # Output as JSON
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
