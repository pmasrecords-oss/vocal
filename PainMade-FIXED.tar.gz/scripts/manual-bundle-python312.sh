#!/bin/bash

# Manual Python 3.12 Setup for PainMade
# Use this if the automatic script doesn't work

set -e

echo "🔧 Manual Python 3.12 Setup"
echo "============================"
echo ""

GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

# Check if Python 3.12 is installed
if ! command -v python3.12 &> /dev/null; then
    echo -e "${RED}❌ Python 3.12 not found!${NC}"
    echo ""
    echo "Installing Python 3.12..."
    
    # Install with Homebrew
    if command -v brew &> /dev/null; then
        echo "Using Homebrew..."
        brew install python@3.12
    else
        echo ""
        echo "Homebrew not found. Please install manually:"
        echo "1. Go to: https://www.python.org/downloads/release/python-3120/"
        echo "2. Download macOS installer"
        echo "3. Install it"
        echo "4. Run this script again"
        echo ""
        exit 1
    fi
fi

echo -e "${GREEN}✅ Python 3.12 found!${NC}"
echo ""

# Verify version
PYTHON_VERSION=$(python3.12 --version)
echo "Version: $PYTHON_VERSION"
echo ""

# Clean old bundle
if [ -d "python-bundle" ]; then
    echo "🧹 Cleaning old python-bundle..."
    rm -rf python-bundle
fi

# Create bundle with Python 3.12 explicitly
echo -e "${BLUE}📦 Creating Python 3.12 virtual environment...${NC}"
python3.12 -m venv python-bundle/env

# Activate
source python-bundle/env/bin/activate

# Verify we're using 3.12
VENV_VERSION=$(python --version)
echo "Virtual env Python: $VENV_VERSION"
echo ""

# Upgrade pip
echo -e "${BLUE}⬆️  Upgrading pip...${NC}"
pip install --upgrade pip setuptools wheel --quiet

# Install dependencies
echo -e "${BLUE}📥 Installing dependencies...${NC}"
echo "   ⏳ pyautogui..."
pip install pyautogui==0.9.54 --quiet

echo "   ⏳ pillow..."
pip install pillow==10.1.0 --quiet

echo "   ⏳ anthropic..."
pip install anthropic==0.25.1 --quiet

echo "   ⏳ pyperclip..."
pip install pyperclip==1.8.2 --quiet

echo "   ⏳ pyobjc (this may take a few minutes)..."
pip install pyobjc-core==10.1 pyobjc-framework-Quartz==10.1 --quiet

echo ""
echo -e "${GREEN}✅ All dependencies installed!${NC}"

# Create launcher
cat > python-bundle/run-automation.sh << 'EOF'
#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "$SCRIPT_DIR/env/bin/activate"
python3 "$@"
EOF
chmod +x python-bundle/run-automation.sh

# Create test script
cat > python-bundle/install-dependencies.sh << 'EOF'
#!/bin/bash
set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "$SCRIPT_DIR/env/bin/activate"

echo "Verifying dependencies..."
python3 -c "import pyautogui; print('✅ pyautogui')"
python3 -c "import PIL; print('✅ pillow')"
python3 -c "import anthropic; print('✅ anthropic')"
python3 -c "import pyperclip; print('✅ pyperclip')"
echo ""
echo "✅ All dependencies verified!"
echo "PainMade is ready to use."
EOF
chmod +x python-bundle/install-dependencies.sh

# Optimize
echo -e "${BLUE}🗜️  Optimizing...${NC}"
find python-bundle -name "*.pyc" -delete 2>/dev/null || true
find python-bundle -name "*.pyo" -delete 2>/dev/null || true
find python-bundle -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true

# Save requirements
pip freeze > python-bundle/requirements.txt

BUNDLE_SIZE=$(du -sh python-bundle | cut -f1)
echo ""
echo -e "${GREEN}✅ Python bundle created: $BUNDLE_SIZE${NC}"
echo ""

deactivate

echo -e "${GREEN}🎉 Done!${NC}"
echo ""
echo "Python 3.12 bundle ready."
echo "Now run: npm run build-mac"
echo ""
