#!/bin/bash

# Bundle Python with dependencies for PainMade

set -e

echo "🎹 PainMade - Python Bundling"
echo "=============================="
echo ""

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Find compatible Python version (3.11 or 3.12 preferred, NOT 3.13)
PYTHON_CMD=""

# Check specific versions first
if command -v python3.12 &> /dev/null; then
    PYTHON_CMD="python3.12"
    echo -e "${GREEN}✅ Found Python 3.12${NC}"
elif command -v python3.11 &> /dev/null; then
    PYTHON_CMD="python3.11"
    echo -e "${GREEN}✅ Found Python 3.11${NC}"
elif command -v python3.10 &> /dev/null; then
    PYTHON_CMD="python3.10"
    echo -e "${GREEN}✅ Found Python 3.10${NC}"
else
    # No specific version found, check default python3
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version 2>&1 | grep -oE '[0-9]+\.[0-9]+' | head -1)
        MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
        MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)
        
        echo "Found python3 version: $PYTHON_VERSION"
        
        if [ "$MAJOR" -eq 3 ] && [ "$MINOR" -eq 13 ]; then
            echo ""
            echo -e "${RED}❌ Python 3.13 detected - NOT COMPATIBLE!${NC}"
            echo ""
            echo "Python 3.13 is too new for required packages (pyobjc, etc)."
            echo ""
            echo "Please install Python 3.12:"
            echo ""
            echo "  ${GREEN}brew install python@3.12${NC}"
            echo ""
            echo "Then run this script again."
            echo ""
            exit 1
        elif [ "$MAJOR" -eq 3 ] && [ "$MINOR" -ge 10 ] && [ "$MINOR" -le 12 ]; then
            PYTHON_CMD="python3"
            echo -e "${GREEN}✅ Using Python $PYTHON_VERSION${NC}"
        else
            echo ""
            echo -e "${RED}❌ Python version $PYTHON_VERSION not supported!${NC}"
            echo ""
            echo "Please install Python 3.10, 3.11, or 3.12"
            echo ""
            echo "  ${GREEN}brew install python@3.12${NC}"
            echo ""
            exit 1
        fi
    else
        echo ""
        echo -e "${RED}❌ Python 3 not found!${NC}"
        echo ""
        echo "Install Python 3.12:"
        echo ""
        echo "  ${GREEN}brew install python@3.12${NC}"
        echo ""
        echo "Or download from: https://www.python.org/downloads/"
        echo ""
        exit 1
    fi
fi

echo -e "${GREEN}✅ Using: $($PYTHON_CMD --version)${NC}"
echo ""

# Clean old bundle
if [ -d "python-bundle" ]; then
    echo -e "${YELLOW}🧹 Cleaning old bundle...${NC}"
    rm -rf python-bundle
fi

# Create bundle
echo -e "${BLUE}📦 Creating Python bundle...${NC}"
mkdir -p python-bundle

# Create virtual environment with compatible Python
echo -e "${BLUE}🔨 Creating virtual environment...${NC}"
$PYTHON_CMD -m venv python-bundle/env

# Activate
source python-bundle/env/bin/activate

# Upgrade pip
echo -e "${BLUE}⬆️  Upgrading pip...${NC}"
pip install --upgrade pip setuptools wheel --quiet

# Install dependencies
echo -e "${BLUE}📥 Installing dependencies...${NC}"
echo "   ⏳ pyautogui..."
pip install pyautogui==0.9.54 --quiet
echo "   ⏳ pillow..."
pip install pillow==10.1.0 --quiet
echo "   ⏳ anthropic..."
pip install anthropic==0.25.1 --quiet
echo "   ⏳ pyperclip..."
pip install pyperclip==1.8.2 --quiet
echo "   ⏳ pyobjc..."
pip install pyobjc-core==10.1 pyobjc-framework-Quartz==10.1 --quiet

echo -e "${GREEN}✅ All dependencies installed${NC}"
echo ""

# Create launcher
echo -e "${BLUE}🚀 Creating launcher...${NC}"
cat > python-bundle/run-automation.sh << 'EOF'
#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "$SCRIPT_DIR/env/bin/activate"
python3 "$@"
EOF
chmod +x python-bundle/run-automation.sh

# Create installer check
cat > python-bundle/install-dependencies.sh << 'EOF'
#!/bin/bash
set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "$SCRIPT_DIR/env/bin/activate"

echo "Verifying dependencies..."
python3 -c "import pyautogui; print('✅ pyautogui')"
python3 -c "import PIL; print('✅ pillow')"
python3 -c "import anthropic; print('✅ anthropic')"
python3 -c "import pyperclip; print('✅ pyperclip')"
echo ""
echo "✅ All dependencies verified!"
echo "PainMade is ready to use."
EOF
chmod +x python-bundle/install-dependencies.sh

# Optimize
echo -e "${BLUE}🗜️  Optimizing bundle...${NC}"
find python-bundle -name "*.pyc" -delete 2>/dev/null || true
find python-bundle -name "*.pyo" -delete 2>/dev/null || true
find python-bundle -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
find python-bundle -name "test" -type d -exec rm -rf {} + 2>/dev/null || true
find python-bundle -name "tests" -type d -exec rm -rf {} + 2>/dev/null || true

# Save requirements
pip freeze > python-bundle/requirements.txt

BUNDLE_SIZE=$(du -sh python-bundle | cut -f1)
echo -e "${GREEN}✅ Bundle created: $BUNDLE_SIZE${NC}"
echo ""

deactivate

echo -e "${GREEN}🎉 Python bundling complete!${NC}"
echo ""
echo "Bundle location: ./python-bundle"
echo "This will be included in your DMG."
echo ""
