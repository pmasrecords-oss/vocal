const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 700,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    titleBarStyle: 'hiddenInset',
    backgroundColor: '#0f0f1e',
    show: false,
    icon: path.join(__dirname, 'build/icon.png')
  });

  mainWindow.loadFile('index.html');
  
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Open DevTools in development
  if (!app.isPackaged) {
    mainWindow.webContents.openDevTools();
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Get bundled Python path
function getBundledPythonPath() {
  if (app.isPackaged) {
    // In production - use bundled Python
    return path.join(process.resourcesPath, 'python-bundle', 'run-automation.sh');
  } else {
    // In development - use system Python
    return 'python3';
  }
}

// Get automation script path
function getAutomationScriptPath() {
  if (app.isPackaged) {
    return path.join(process.resourcesPath, 'logic_automation.py');
  } else {
    return path.join(__dirname, 'logic_automation.py');
  }
}

// Handle file loading
// File selection handler
ipcMain.handle('select-file', async (event, type) => {
  const filters = [
    { name: 'Audio Files', extensions: ['wav', 'mp3', 'm4a', 'aiff', 'flac'] }
  ];
  
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: filters,
    title: `Select ${type} audio file`
  });
  
  if (!result.canceled && result.filePaths.length > 0) {
    return result.filePaths[0];
  }
  return null;
});

// File reading handler
ipcMain.handle('read-file', async (event, filePath) => {
  try {
    const buffer = fs.readFileSync(filePath);
    return buffer;
  } catch (error) {
    console.error('Error reading file:', error);
    throw error;
  }
});

// Handle file saving
ipcMain.handle('save-file', async (event, buffer) => {
  const result = await dialog.showSaveDialog({
    defaultPath: 'plugin-settings.txt',
    filters: [
      { name: 'Text File', extensions: ['txt'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  
  if (!result.canceled && result.filePath) {
    fs.writeFileSync(result.filePath, Buffer.from(buffer));
    return result.filePath;
  }
  return null;
});

// Handle Plugin Chain export
ipcMain.handle('save-studioverse-file', async (event, buffer) => {
  const result = await dialog.showSaveDialog({
    defaultPath: 'PainMade-AI-Vocal-Chain.html',
    filters: [
      { name: 'HTML Report', extensions: ['html'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  
  if (!result.canceled && result.filePath) {
    fs.writeFileSync(result.filePath, Buffer.from(buffer));
    return result.filePath;
  }
  return null;
});

// Handle JSON chain save
ipcMain.handle('save-json-chain', async (event, buffer) => {
  return true;
});

// Handle Melodyne automation export
ipcMain.handle('save-melodyne-file', async (event, buffer) => {
  const result = await dialog.showSaveDialog({
    defaultPath: 'PainMade-Melodyne-Auto.json',
    filters: [
      { name: 'Melodyne Automation', extensions: ['json'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  
  if (!result.canceled && result.filePath) {
    fs.writeFileSync(result.filePath, Buffer.from(buffer));
    return result.filePath;
  }
  return null;
});

// Check if API key exists
ipcMain.handle('check-api-key', async () => {
  const apiKeyPath = path.join(app.getPath('userData'), 'anthropic-api-key.txt');
  return fs.existsSync(apiKeyPath);
});

// Save API key
ipcMain.handle('save-api-key', async (event, apiKey) => {
  try {
    const apiKeyPath = path.join(app.getPath('userData'), 'anthropic-api-key.txt');
    fs.writeFileSync(apiKeyPath, apiKey, { mode: 0o600 });
    return true;
  } catch (error) {
    console.error('Error saving API key:', error);
    return false;
  }
});

// Save temp chain for automation
ipcMain.handle('save-temp-chain', async (event, chainJSON) => {
  try {
    const tempPath = path.join(app.getPath('temp'), 'painmade-vocal-chain.json');
    fs.writeFileSync(tempPath, chainJSON);
    return tempPath;
  } catch (error) {
    console.error('Error saving temp chain:', error);
    return null;
  }
});

// Run Logic Pro automation
let automationProcess = null;

ipcMain.handle('run-logic-automation', async (event, chainPath) => {
  try {
    const { spawn } = require('child_process');
    
    const apiKeyPath = path.join(app.getPath('userData'), 'anthropic-api-key.txt');
    if (!fs.existsSync(apiKeyPath)) {
      return { success: false, error: 'API key not found' };
    }
    
    const apiKey = fs.readFileSync(apiKeyPath, 'utf8').trim();
    const pythonPath = getBundledPythonPath();
    const scriptPath = getAutomationScriptPath();
    
    console.log('Starting automation...');
    console.log('Python:', pythonPath);
    console.log('Script:', scriptPath);
    
    if (app.isPackaged) {
      automationProcess = spawn(pythonPath, [scriptPath, chainPath, apiKey], {
        env: { ...process.env, ANTHROPIC_API_KEY: apiKey }
      });
    } else {
      automationProcess = spawn(pythonPath, [scriptPath, chainPath, apiKey], {
        env: { ...process.env, ANTHROPIC_API_KEY: apiKey }
      });
    }
    
    automationProcess.stdout.on('data', (data) => {
      const message = data.toString().trim();
      if (message) {
        mainWindow.webContents.send('automation-progress', {
          type: 'info',
          message: message
        });
      }
    });
    
    automationProcess.stderr.on('data', (data) => {
      const message = data.toString().trim();
      if (message) {
        mainWindow.webContents.send('automation-progress', {
          type: 'error',
          message: message
        });
      }
    });
    
    return new Promise((resolve) => {
      automationProcess.on('close', (code) => {
        if (code === 0) {
          resolve({ success: true, message: 'Automation completed!' });
        } else {
          resolve({ success: false, error: `Exited with code ${code}` });
        }
        automationProcess = null;
      });
    });
    
  } catch (error) {
    console.error('Automation error:', error);
    return { success: false, error: error.message };
  }
});

// Stop automation
ipcMain.handle('stop-automation', async () => {
  if (automationProcess) {
    automationProcess.kill();
    automationProcess = null;
    return true;
  }
  return false;
});

// ============================================
// AI SMART FEATURES HANDLERS
// ============================================

// Smart vocal analysis (no reference needed)
ipcMain.handle('smart-analyze-vocal', async (event, { vocalPath, genre }) => {
  try {
    console.log('Running smart vocal analysis...');
    console.log('Vocal:', vocalPath);
    console.log('Genre:', genre || 'auto-detect');
    
    // Get paths
    const pythonPath = getBundledPythonPath();
    const analyzerScript = path.join(__dirname, 'vocal_analyzer.py');
    
    // For development, check if script exists
    if (!fs.existsSync(analyzerScript)) {
      console.error('Analyzer script not found:', analyzerScript);
      throw new Error('Analyzer script not found');
    }
    
    // Convert blob URL to actual file path if needed
    let actualVocalPath = vocalPath;
    if (vocalPath.startsWith('blob:')) {
      // This shouldn't happen as we should have the actual file path
      // But handle it just in case
      throw new Error('Cannot analyze blob URL. Please use actual file path.');
    }
    
    // Run Python analyzer
    const { spawn } = require('child_process');
    const args = genre ? [analyzerScript, actualVocalPath, genre] : [analyzerScript, actualVocalPath];
    
    return new Promise((resolve, reject) => {
      const analyzerProcess = spawn(pythonPath, args);
      
      let output = '';
      let errorOutput = '';
      
      analyzerProcess.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      analyzerProcess.stderr.on('data', (data) => {
        errorOutput += data.toString();
        console.error('Analyzer stderr:', data.toString());
      });
      
      analyzerProcess.on('close', (code) => {
        if (code !== 0) {
          console.error('Analyzer failed with code:', code);
          console.error('Error output:', errorOutput);
          reject(new Error(`Analysis failed: ${errorOutput}`));
          return;
        }
        
        try {
          // Log raw output for debugging
          console.log('Raw analyzer output length:', output.length);
          console.log('First 500 chars:', output.substring(0, 500));
          
          // Parse JSON output from analyzer
          const result = JSON.parse(output);
          resolve(result);
        } catch (error) {
          console.error('Failed to parse analyzer output');
          console.error('Parse error:', error.message);
          console.error('Output length:', output.length);
          console.error('First 1000 chars of output:', output.substring(0, 1000));
          console.error('Last 500 chars of output:', output.substring(Math.max(0, output.length - 500)));
          reject(new Error('Failed to parse analysis results: ' + error.message));
        }
      });
    });
    
  } catch (error) {
    console.error('Smart analysis error:', error);
    throw error;
  }
});

// Apply smart chain to Logic Pro
ipcMain.handle('automate-smart-chain', async (event, { chain, analysis }) => {
  try {
    console.log('Applying smart chain to Logic Pro...');
    console.log('Chain length:', chain.length);
    
    // Save chain to temp file
    const tempChainPath = path.join(app.getPath('temp'), 'smart_chain.json');
    const chainData = { 
      name: 'AI Smart Vocal Chain',
      plugins: chain 
    };
    
    console.log('Chain data structure:', JSON.stringify(chainData, null, 2).substring(0, 500));
    console.log('First plugin:', chain[0]);
    
    fs.writeFileSync(tempChainPath, JSON.stringify(chainData, null, 2));
    
    console.log('Chain saved to:', tempChainPath);
    
    // Get Python path
    const pythonPath = getBundledPythonPath();
    const automationScript = path.join(__dirname, 'logic_automation.py');
    
    if (!fs.existsSync(automationScript)) {
      console.error('Automation script not found:', automationScript);
      throw new Error('Logic automation script not found');
    }
    
    console.log('Running automation script...');
    
    // Get API key if available
    const apiKeyPath = path.join(app.getPath('userData'), 'anthropic-api-key.txt');
    let apiKey = null;
    if (fs.existsSync(apiKeyPath)) {
      apiKey = fs.readFileSync(apiKeyPath, 'utf8').trim();
      console.log('API key loaded');
    }
    
    // Run the automation
    const { spawn } = require('child_process');
    
    return new Promise((resolve, reject) => {
      const args = [automationScript, tempChainPath, '--auto'];
      if (apiKey) {
        args.push(apiKey);
      }
      
      const automationProcess = spawn(pythonPath, args, {
        env: apiKey ? { ...process.env, ANTHROPIC_API_KEY: apiKey } : process.env
      });
      
      let output = '';
      let errorOutput = '';
      
      automationProcess.stdout.on('data', (data) => {
        output += data.toString();
        console.log('Automation:', data.toString());
      });
      
      automationProcess.stderr.on('data', (data) => {
        errorOutput += data.toString();
        console.error('Automation stderr:', data.toString());
      });
      
      automationProcess.on('close', (code) => {
        if (code !== 0) {
          console.error('Automation failed with code:', code);
          console.error('Error output:', errorOutput);
          reject(new Error(`Automation failed: ${errorOutput || 'Unknown error'}`));
          return;
        }
        
        console.log('Automation completed successfully');
        resolve(true);
      });
    });
    
  } catch (error) {
    console.error('Smart chain automation error:', error);
    throw error;
  }
});


// Enhanced vocal analysis with Waves/Melodyne support
ipcMain.handle('enhanced-analyze-vocal', async (event, { vocalPath, genre, options }) => {
  try {
    console.log('Running enhanced vocal analysis...');
    console.log('Vocal:', vocalPath);
    console.log('Genre:', genre || 'auto-detect');
    console.log('Options:', options);
    
    const pythonPath = getBundledPythonPath();
    const analyzerScript = path.join(__dirname, 'enhanced_vocal_analyzer.py');
    
    if (!fs.existsSync(analyzerScript)) {
      console.error('Enhanced analyzer script not found:', analyzerScript);
      throw new Error('Enhanced analyzer script not found');
    }
    
    // Run Python enhanced analyzer
    const { spawn } = require('child_process');
    const args = [
      analyzerScript,
      vocalPath,
      genre || 'auto',
      JSON.stringify(options)
    ];
    
    return new Promise((resolve, reject) => {
      const analyzerProcess = spawn(pythonPath, args);
      
      let output = '';
      let errorOutput = '';
      
      analyzerProcess.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      analyzerProcess.stderr.on('data', (data) => {
        errorOutput += data.toString();
        console.error('Enhanced analyzer stderr:', data.toString());
      });
      
      analyzerProcess.on('close', (code) => {
        if (code !== 0) {
          console.error('Enhanced analyzer failed with code:', code);
          console.error('Error output:', errorOutput);
          reject(new Error(`Enhanced analysis failed: ${errorOutput}`));
          return;
        }
        
        try {
          const result = JSON.parse(output);
          resolve(result);
        } catch (error) {
          console.error('Failed to parse enhanced analyzer output:', output);
          reject(new Error('Failed to parse enhanced analysis results'));
        }
      });
    });
    
  } catch (error) {
    console.error('Enhanced analysis error:', error);
    throw error;
  }
});
